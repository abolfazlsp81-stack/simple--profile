(function(){
  'use strict';
  const months=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
  const weekdays=['ش','ی','د','س','چ','پ','ج'];
  const fa=value=>String(value).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
  const pad=value=>String(value).padStart(2,'0');
  const div=(a,b)=>Math.floor(a/b),mod=(a,b)=>a-Math.floor(a/b)*b;
  function g2j(gy,gm,gd){let gdm=[0,31,59,90,120,151,181,212,243,273,304,334],gy2=gm>2?gy+1:gy,days=355666+365*gy+div(gy2+3,4)-div(gy2+99,100)+div(gy2+399,400)+gd+gdm[gm-1],jy=-1595+33*div(days,12053);days=mod(days,12053);jy+=4*div(days,1461);days=mod(days,1461);if(days>365){jy+=div(days-1,365);days=mod(days-1,365);}return days<186?[jy,1+div(days,31),1+mod(days,31)]:[jy,7+div(days-186,30),1+mod(days-186,30)];}
  function j2g(jy,jm,jd){jy+=1595;let days=-355668+365*jy+div(jy,33)*8+div(mod(jy,33)+3,4)+jd+(jm<7?(jm-1)*31:(jm-7)*30+186),gy=400*div(days,146097);days=mod(days,146097);if(days>36524){gy+=100*div(--days,36524);days=mod(days,36524);if(days>=365)days++;}gy+=4*div(days,1461);days=mod(days,1461);if(days>365){gy+=div(days-1,365);days=mod(days-1,365);}let gd=days+1,sal=[0,31,((gy%4===0&&gy%100!==0)||gy%400===0)?29:28,31,30,31,30,31,31,30,31,30,31],gm=1;while(gm<=12&&gd>sal[gm])gd-=sal[gm++];return[gy,gm,gd];}
  const isLeap=y=>{const a=j2g(y,1,1),b=j2g(y+1,1,1);return(Date.UTC(b[0],b[1]-1,b[2])-Date.UTC(a[0],a[1]-1,a[2]))/86400000===366;};
  const daysInMonth=(y,m)=>m<=6?31:(m<=11?30:(isLeap(y)?30:29));
  const todayDate=new Date(),today=g2j(todayDate.getFullYear(),todayDate.getMonth()+1,todayDate.getDate());
  let activeInput=null,year=today[0]-25,month=today[1],selected='';

  function overlay(){
    let modal=document.querySelector('[data-mph-date-modal]');
    if(modal)return modal;
    modal=document.createElement('div');modal.className='mph-date-modal';modal.dataset.mphDateModal='1';modal.dir='rtl';modal.hidden=true;
    modal.innerHTML='<div class="mph-date-backdrop" data-date-close></div><section class="mph-date-dialog" role="dialog" aria-modal="true" aria-label="انتخاب تاریخ تولد"><div data-date-calendar></div></section>';
    document.body.appendChild(modal);
    modal.addEventListener('click',event=>{if(event.target.closest('[data-date-close]'))close();});
    return modal;
  }
  function close(){const modal=overlay();modal.hidden=true;document.documentElement.classList.remove('mph-date-open');activeInput=null;}
  function choose(value){if(activeInput){activeInput.value=value;activeInput.dispatchEvent(new Event('change',{bubbles:true}));}close();}
  function render(){
    const modal=overlay(),calendar=modal.querySelector('[data-date-calendar]'),start=j2g(year,month,1),offset=(new Date(start[0],start[1]-1,start[2]).getDay()+1)%7,total=daysInMonth(year,month);
    let days='';for(let i=0;i<offset;i++)days+='<span class="is-empty" aria-hidden="true"></span>';
    for(let day=1;day<=total;day++){const value=`${year}/${pad(month)}/${pad(day)}`,future=year>today[0]||(year===today[0]&&(month>today[1]||(month===today[1]&&day>today[2])));days+=`<button type="button" data-date-value="${value}" class="${selected===value?'is-selected ':''}${future?'is-future':''}" ${future?'disabled':''}>${fa(day)}</button>`;}
    let years='';for(let y=today[0];y>=1300;y--)years+=`<option value="${y}" ${y===year?'selected':''}>${fa(y)}</option>`;
    let monthOptions='';months.forEach((name,index)=>monthOptions+=`<option value="${index+1}" ${index+1===month?'selected':''}>${name}</option>`);
    calendar.innerHTML=`<header class="mph-date-title"><div><span class="dashicons dashicons-calendar-alt"></span><div><b>انتخاب تاریخ تولد</b><small>تقویم شمسی</small></div></div><button type="button" data-date-close aria-label="بستن">×</button></header><div class="mph-date-nav"><button type="button" data-date-prev aria-label="ماه قبل">‹</button><select data-date-month aria-label="ماه">${monthOptions}</select><select data-date-year aria-label="سال">${years}</select><button type="button" data-date-next aria-label="ماه بعد">›</button></div><div class="mph-date-week">${weekdays.map(x=>`<b>${x}</b>`).join('')}</div><div class="mph-date-days">${days}</div><footer class="mph-date-actions"><button type="button" data-date-today>انتخاب امروز</button><button type="button" data-date-clear>پاک کردن تاریخ</button></footer>`;
    calendar.querySelectorAll('[data-date-close]').forEach(button=>button.onclick=close);
    calendar.querySelector('[data-date-prev]').onclick=()=>{month--;if(month<1){month=12;year=Math.max(1300,year-1);}render();};
    calendar.querySelector('[data-date-next]').onclick=()=>{month++;if(month>12){month=1;year=Math.min(today[0],year+1);}if(year===today[0]&&month>today[1])month=today[1];render();};
    calendar.querySelector('[data-date-month]').onchange=event=>{month=Number(event.target.value);if(year===today[0]&&month>today[1])month=today[1];render();};
    calendar.querySelector('[data-date-year]').onchange=event=>{year=Number(event.target.value);render();};
    calendar.querySelectorAll('[data-date-value]').forEach(button=>button.onclick=()=>choose(button.dataset.dateValue));
    calendar.querySelector('[data-date-today]').onclick=()=>choose(`${today[0]}/${pad(today[1])}/${pad(today[2])}`);
    calendar.querySelector('[data-date-clear]').onclick=()=>choose('');
  }
  function open(input){activeInput=input;const stored=input.value.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);year=stored?Number(stored[1]):Math.max(1300,today[0]-25);month=stored?Number(stored[2]):today[1];selected=stored?input.value:'';render();const modal=overlay();modal.hidden=false;document.documentElement.classList.add('mph-date-open');window.setTimeout(()=>{const selectedButton=modal.querySelector('.mph-date-days .is-selected'),first=modal.querySelector('.mph-date-days button:not(:disabled)');(selectedButton||first)&& (selectedButton||first).focus();},30);}
  function bind(root){if(root.dataset.dateReady)return;root.dataset.dateReady='1';const input=root.querySelector('input[name="birth_date"]'),button=root.querySelector('[data-mph-date-toggle]');if(!input||!button)return;input.addEventListener('click',event=>{event.preventDefault();open(input);});button.addEventListener('click',event=>{event.preventDefault();open(input);});}
  function scan(context){if(!context||context.nodeType!==1&&context!==document)return;if(context.matches&&context.matches('[data-mph-date-picker]'))bind(context);context.querySelectorAll&&context.querySelectorAll('[data-mph-date-picker]').forEach(bind);}
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!overlay().hidden)close();});
  const start=()=>{scan(document);new MutationObserver(records=>records.forEach(record=>record.addedNodes.forEach(scan))).observe(document.body,{childList:true,subtree:true});};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
