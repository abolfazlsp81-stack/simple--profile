/* Presentation only: retain the theme's font with a local Persian fallback. */
(function () {
  'use strict';
  function syncFont() {
    if (!document.body) return;
    const defaults = /^(inherit|initial|unset|serif|sans-serif|system-ui|ui-sans-serif|arial|tahoma|times new roman|helvetica|verdana|mph persian)$/i;
    const family = window.getComputedStyle(document.body).fontFamily;
    const custom = family.split(',').map(function (name) { return name.trim(); }).filter(function (name) {
      return name && !defaults.test(name.replace(/^["']|["']$/g, ''));
    });
    document.documentElement.style.setProperty('--mph-resolved-font', custom.concat(['"MPH Persian"', 'Tahoma', 'Arial', 'sans-serif']).join(', '));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', syncFont, {once: true});
  else syncFont();
  window.addEventListener('load', syncFont, {once: true});
})();
