(function(){
  'use strict';
  if(typeof MPH_COURSE_PURCHASE==='undefined'||!MPH_COURSE_PURCHASE.target)return;
  const ids=(MPH_COURSE_PURCHASE.productIds||[]).map(Number),target=MPH_COURSE_PURCHASE.target;
  const purchaseContexts='.tutor-course-sidebar-card,.tutor-course-sidebar-card-body,.tutor-course-purchase-box,.tutor-course-enrollment-box,.tutor-single-course-sidebar,.tutor-course-single-sidebar-wrapper,.tutor-course-details-page [class*="purchase"],.tutor-course-details-page [class*="enroll"],[data-course-purchase],body.single-courses,body.single-tutor_course';
  const purchaseWords=/خرید|سفارش|ثبت\s*نام|افزودن|پرداخت|add\s*to\s*cart|buy\s*now|purchase|enroll\s*now/i;
  function productId(element){
    if(!element)return 0;
    const data=Number(element.dataset&&(element.dataset.product_id||element.dataset.productId)||0);if(data)return data;
    const href=element.getAttribute&&element.getAttribute('href')||'';
    try{const url=new URL(href,window.location.href),id=Number(url.searchParams.get('add-to-cart')||url.searchParams.get('product_id')||0);if(id)return id;}catch(e){}
    const form=element.closest&&element.closest('form');if(form){const field=form.querySelector('[name="add-to-cart"],[name="product_id"]');if(field)return Number(field.value||0);}
    return 0;
  }
  function isCoursePurchase(control){
    const id=productId(control);if(ids.includes(id))return true;
    const context=control.closest&&control.closest(purchaseContexts);if(!context)return false;
    const text=(control.textContent||control.value||control.getAttribute('aria-label')||'').trim();
    if(purchaseWords.test(text))return true;
    return control.matches('.tutor-btn-primary,.tutor-add-to-cart-button,[name="add-to-cart"],button[type="submit"]')&&!/ادامه|مشاهده|continue|start/i.test(text);
  }
  function go(event){event.preventDefault();event.stopPropagation();if(event.stopImmediatePropagation)event.stopImmediatePropagation();window.location.assign(target);}
  document.addEventListener('click',event=>{const control=event.target.closest&&event.target.closest('a,button,input[type="submit"],input[type="button"]');if(control&&isCoursePurchase(control))go(event);},true);
  document.addEventListener('submit',event=>{const form=event.target,submitter=event.submitter||form.querySelector('button[type="submit"],input[type="submit"]');if((submitter&&isCoursePurchase(submitter))||ids.includes(productId(form)))go(event);},true);
})();
