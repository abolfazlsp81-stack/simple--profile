(function(){
  'use strict';
  const one=(s,c)=>(c||document).querySelector(s), all=(s,c)=>Array.from((c||document).querySelectorAll(s));
  let loaderCount=0;
  const modalState={locked:false,lastFocus:null,scrollY:0,htmlOverflow:'',bodyOverflow:'',bodyPaddingRight:'',bodyPosition:'',bodyTop:'',bodyWidth:''};
  const focusableSelector='a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
  const escapeHtml=value=>String(value==null?'':value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));
  const portalParams=['mph_mode','mph_open','mph_choose_course','mph_auth','mph_profile_popup','mph_clean_auth','mph_stage','mph_reset','mph_help','mph_backup_notice','mph_backup_type','key','flow','login','phone','management_otp','one_time_code','course_id','order_id'];
  function cleanPortalUrl(state,replace){if(!window.history)return;const url=new URL(window.location.href);let changed=false;portalParams.forEach(key=>{if(url.searchParams.has(key)){url.searchParams.delete(key);changed=true;}});if(!changed&&!state)return;const method=replace===false?'pushState':'replaceState';window.history[method](Object.assign({},window.history.state||{},state||{}),'',url.pathname+(url.search||'')+url.hash);}
  function loaderNode(){let node=one('.mph-global-loader');if(node)return node;node=document.createElement('div');node.className='mph-global-loader';node.setAttribute('aria-live','polite');node.setAttribute('aria-hidden','true');const mark=MPH_DATA.logoUrl?'<img class="mph-loader-logo" src="'+escapeHtml(MPH_DATA.logoUrl)+'" alt="">':'<span class="dashicons dashicons-admin-site-alt3"></span>';node.innerHTML='<div class="mph-loader-brand"><i></i>'+mark+'</div><b data-mph-loader-label>در حال انجام…</b><small>لطفاً چند لحظه صبر کنید</small>';document.body.appendChild(node);return node;}
  function showLoader(label){loaderCount++;const node=loaderNode(),text=one('[data-mph-loader-label]',node);if(text)text.textContent=label||MPH_DATA.working;node.classList.add('is-active');node.setAttribute('aria-hidden','false');}
  function hideLoader(){loaderCount=Math.max(0,loaderCount-1);if(loaderCount)return;const node=one('.mph-global-loader');if(node){node.classList.remove('is-active');node.setAttribute('aria-hidden','true');}}
  function lockScroll(){
    if(modalState.locked)return;
    const html=document.documentElement,body=document.body;
    modalState.locked=true;
    modalState.scrollY=window.scrollY||window.pageYOffset||0;
    modalState.htmlOverflow=html.style.overflow;
    modalState.bodyOverflow=body?body.style.overflow:'';
    modalState.bodyPaddingRight=body?body.style.paddingRight:'';
    modalState.bodyPosition=body?body.style.position:'';
    modalState.bodyTop=body?body.style.top:'';
    modalState.bodyWidth=body?body.style.width:'';
    const gap=Math.max(0,window.innerWidth-html.clientWidth);
    html.classList.add('mph-modal-open');
    html.style.overflow='hidden';
    if(body){body.classList.add('mph-modal-open');body.style.overflow='hidden';body.style.position='fixed';body.style.top=(-modalState.scrollY)+'px';body.style.width='100%';if(gap)body.style.paddingRight=gap+'px';}
  }
  function unlockScroll(force){
    const open=one('.mph-auth-modal.is-open');
    if(open&&!force)return;
    const html=document.documentElement,body=document.body,wasLocked=modalState.locked;
    html.classList.remove('mph-modal-open','mph-date-open');
    html.style.overflow=wasLocked?modalState.htmlOverflow:'';
    if(body){body.classList.remove('mph-modal-open','mph-date-open');body.style.overflow=wasLocked?modalState.bodyOverflow:'';body.style.paddingRight=wasLocked?modalState.bodyPaddingRight:'';body.style.position=wasLocked?modalState.bodyPosition:'';body.style.top=wasLocked?modalState.bodyTop:'';body.style.width=wasLocked?modalState.bodyWidth:'';}
    modalState.locked=false;
    if(wasLocked&&typeof window.scrollTo==='function')window.requestAnimationFrame(()=>{try{window.scrollTo(0,modalState.scrollY);}catch(e){}});
  }
  function modalKeyboard(event){
    const modal=one('.mph-auth-modal.is-open');
    if(!modal)return;
    if(event.key==='Escape'){event.preventDefault();closeAuthModal(modal);return;}
    if(event.key!=='Tab')return;
    const nodes=all(focusableSelector,modal).filter(node=>node.offsetParent!==null||node===document.activeElement);
    if(!nodes.length){event.preventDefault();return;}
    const first=nodes[0],last=nodes[nodes.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  }
  function normalizeModal(modal){
    if(!modal||!document.body)return null;
    const root=modal.closest('.mph-global-popup-root')||modal.parentElement;
    if(!one('.mph-smart-auth',modal))return null;
    if(root&&root!==document.body&&root.parentElement!==document.body)document.body.appendChild(root);
    if(root){root.hidden=false;root.removeAttribute('hidden');root.removeAttribute('aria-hidden');root.classList.add('is-open');root.style.removeProperty('display');root.style.removeProperty('visibility');}
    modal.hidden=false;modal.removeAttribute('hidden');modal.style.setProperty('display','grid','important');modal.style.setProperty('visibility','visible','important');modal.style.setProperty('pointer-events','auto','important');
    return modal;
  }
  function openAuthModal(trigger,targetModal){
    let modal=targetModal||one('[data-mph-global-auth]')||one('.mph-auth-modal');
    modal=normalizeModal(modal);
    if(!modal){unlockScroll(true);return false;}
    unlockScroll(true);
    modalState.lastFocus=trigger||document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    lockScroll();
    document.removeEventListener('keydown',modalKeyboard);
    document.addEventListener('keydown',modalKeyboard);
    const phone=one('[data-auth-panel="phone"] input[name="phone"]',modal),fallback=one(focusableSelector,modal);
    window.setTimeout(()=>{const target=phone||fallback;if(target)target.focus();},120);
    return true;
  }
  function closeAuthModal(modal){
    modal=modal||one('.mph-auth-modal.is-open');
    if(modal){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');modal.style.removeProperty('display');modal.style.removeProperty('visibility');modal.style.removeProperty('pointer-events');const root=modal.closest('.mph-global-popup-root');if(root){root.classList.remove('is-open');root.hidden=true;root.setAttribute('aria-hidden','true');root.style.setProperty('display','none','important');}}
    document.removeEventListener('keydown',modalKeyboard);
    unlockScroll(true);
    const focus=modalState.lastFocus;
    modalState.lastFocus=null;
    if(focus&&document.contains(focus)&&typeof focus.focus==='function')window.setTimeout(()=>focus.focus(),40);
  }
  function rememberAuthOrigin(){try{const current=new URL(window.location.href),account=new URL(MPH_DATA.pageUrl||window.location.href,window.location.href);if(current.origin===account.origin&&current.pathname.replace(/\/$/,'')===account.pathname.replace(/\/$/,''))return;sessionStorage.setItem('mphAuthReturn',current.toString());}catch(e){}}
  function restoreAuthLocation(modal){const global=modal&&modal.closest('.mph-global-popup-root');const url=new URL(window.location.href);url.searchParams.delete('mph_auth');url.searchParams.delete('mph_profile_popup');if(global){window.history.replaceState(window.history.state,'',url.toString());return;}let target='';try{target=sessionStorage.getItem('mphAuthReturn')||'';sessionStorage.removeItem('mphAuthReturn');if(target){const parsed=new URL(target,window.location.href);if(parsed.origin!==window.location.origin)target='';}}catch(e){target='';}if(!target&&document.referrer){try{const previous=new URL(document.referrer);if(previous.origin===window.location.origin&&previous.href!==window.location.href)target=previous.href;}catch(e){}}if(target){window.location.replace(target);return;}if(window.history.length>1){window.history.back();return;}window.location.replace(MPH_DATA.homeUrl||url.toString());}
  let portalStylePromise=null;
  function ensurePortalStyles(){
    if(one('link[href*="frontend-release.css"],style[data-mph-portal-style]'))return Promise.resolve(true);
    if(portalStylePromise)return portalStylePromise;
    portalStylePromise=new Promise(resolve=>{const url=MPH_DATA.portalStyleUrl;if(!url){resolve(false);return;}const link=document.createElement('link');link.id='mph-frontend-release-lazy';link.rel='stylesheet';link.href=url;link.onload=()=>resolve(true);link.onerror=()=>resolve(false);document.head.appendChild(link);window.setTimeout(()=>resolve(false),8000);});
    return portalStylePromise;
  }
  let datePickerPromise=null;
  function ensureDatePickerScript(){
    if(one('script[src*="date-picker.js"]'))return Promise.resolve(true);
    if(datePickerPromise)return datePickerPromise;
    datePickerPromise=new Promise(resolve=>{const url=MPH_DATA.datePickerScriptUrl;if(!url){resolve(false);return;}const script=document.createElement('script');script.src=url;script.defer=true;script.onload=()=>resolve(true);script.onerror=()=>resolve(false);document.head.appendChild(script);window.setTimeout(()=>resolve(false),8000);});
    return datePickerPromise;
  }
  async function ensureAuthModal(trigger){
    rememberAuthOrigin();
    await Promise.all([ensurePortalStyles(),ensureDatePickerScript()]);
    let modal=one('[data-mph-global-auth]')||one('.mph-auth-modal');
    if(modal&&one('.mph-smart-auth',modal))return openAuthModal(trigger,modal);
    if(modal){const stale=modal.closest('.mph-global-popup-root')||modal;stale.remove();modal=null;}
    unlockScroll(true);
    const data=new FormData();data.append('action','mph_auth_shell');
    try{
      const result=await send(data);
      if(!result.success||!result.data||!result.data.html){unlockScroll(true);return false;}
      document.body.insertAdjacentHTML('beforeend',result.data.html);
      if(result.data.nonce)MPH_DATA.nonce=result.data.nonce;
      all('.mph-root').forEach(root=>{if(!root.dataset.mphRootBound)bindRoot(root);});
      modal=one('[data-mph-global-auth]');
      const opened=modal?openAuthModal(trigger,modal):false;if(!opened)unlockScroll(true);return opened;
    }catch(error){
      unlockScroll(true);
      all('.mph-root').forEach(root=>flash(root,error.message||MPH_DATA.connectionError,false));
      return false;
    }
  }
  function clearTicketAlert(){all('[data-panel="ticket_support"]').forEach(item=>{item.classList.remove('mph-ticket-alert');all('.mph-alert-dot',item).forEach(dot=>dot.remove());});}
  function clearAnnouncementAlert(){all('[data-panel="announcements"],[data-panel="teacher_notices"]').forEach(item=>{item.classList.remove('mph-announcement-alert');all('.mph-announcement-dot',item).forEach(dot=>dot.remove());});}
  window.MPHOpenAuth=openAuthModal;window.MPHEnsureAuth=ensureAuthModal;window.MPHCloseAuth=closeAuthModal;window.MPHClearTicketAlert=clearTicketAlert;window.MPHClearAnnouncementAlert=clearAnnouncementAlert;
  function installAjaxLoader(){if(window.fetch.__mphLoader)return;const nativeFetch=window.fetch.bind(window);const wrapped=function(input,options){const body=options&&options.body,action=body instanceof FormData?String(body.get('action')||''):'';if(!/^mph_/.test(action))return nativeFetch(input,options);let hasFile=false;if(body instanceof FormData)for(const value of body.values())if(value instanceof File&&value.size){hasFile=true;break;}showLoader(hasFile?'در حال بارگذاری فایل…':MPH_DATA.working);return nativeFetch(input,options).finally(hideLoader);};wrapped.__mphLoader=true;window.fetch=wrapped;window.MPHLoader={show:showLoader,hide:hideLoader};}
  async function send(data,options){
    options=options||{};
    const dashboard=one('.mph-dashboard');
    if(dashboard&&dashboard.dataset.mode&&!data.has('mode'))data.append('mode',dashboard.dataset.mode);
    data.set('nonce',MPH_DATA.nonce);
    const controller=new AbortController();
    let timedOut=false;
    const timeout=window.setTimeout(()=>{timedOut=true;controller.abort();},Number(MPH_DATA.requestTimeout||30000));
    const externalAbort=()=>controller.abort();
    if(options.signal){if(options.signal.aborted)externalAbort();else options.signal.addEventListener('abort',externalAbort,{once:true});}
    try{
      const response=await fetch(MPH_DATA.ajaxUrl,{method:'POST',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'},body:data,signal:controller.signal});
      const raw=(await response.text()).replace(/^\uFEFF/,'').trim();
      if(raw==='0')throw new Error('پاسخ عملیات از وردپرس دریافت نشد. افزونه را به نسخه جدید به‌روزرسانی و صفحه را تازه‌سازی کنید.');
      if(raw==='-1')throw new Error('اعتبار این صفحه منقضی شده است؛ صفحه را تازه‌سازی کنید.');
      let json;
      try{json=JSON.parse(raw);}catch(e){throw new Error(MPH_DATA.connectionError);}
      if(!json||typeof json.success==='undefined')throw new Error(MPH_DATA.connectionError);
      if(!response.ok&&json.success!==false)throw new Error('درخواست با خطای '+response.status+' روبه‌رو شد.');
      return json;
    }catch(error){
      if(error&&error.name==='AbortError'&&timedOut)throw new Error('زمان پاسخ سرور تمام شد؛ اتصال اینترنت را بررسی و دوباره تلاش کنید.');
      throw error;
    }finally{
      window.clearTimeout(timeout);
      if(options.signal)options.signal.removeEventListener('abort',externalAbort);
    }
  }
  function message(form,text,ok){const box=one('.mph-message',form);if(!box)return;box.textContent=text||'';box.className='mph-message '+(ok?'is-success':'is-error');}
  function flash(root,text,ok){if(!text)return;let box=one('.mph-toast',root);if(!box){box=document.createElement('div');box.className='mph-toast';root.appendChild(box);}box.textContent=text;box.className='mph-toast '+(ok?'is-success':'is-error')+' is-show';window.clearTimeout(box._timer);box._timer=window.setTimeout(()=>box.classList.remove('is-show'),3500);}
  function fileSize(bytes){if(bytes<1024)return bytes+' بایت';if(bytes<1048576)return(Math.round(bytes/102.4)/10)+' کیلوبایت';return(Math.round(bytes/104857.6)/10)+' مگابایت';}
  function bindFiles(root){all('input[type="file"]',root).forEach(input=>{if(input.matches('[data-ticket-file]')||input.dataset.fileBound)return;input.dataset.fileBound='1';input.addEventListener('change',()=>{let state=input._mphFileState;if(state){state.remove();input._mphFileState=null;}const file=input.files&&input.files[0],max=Number(input.dataset.mphMaxFile||0);if(file&&max&&file.size>max){input.value='';message(input.closest('form'),'حجم فایل بیشتر از حد مجاز است.',false);return;}if(!file)return;state=document.createElement('span');state.className='mph-file-state';state.innerHTML='<i aria-hidden="true"></i><b>'+escapeHtml(file.name)+'</b><small>'+escapeHtml(fileSize(file.size))+'</small>';const host=input.closest('.mph-file-upload,.mph-receipt-drop,label')||input.parentElement;host&&host.appendChild(state);input._mphFileState=state;});});}
  function bindNoticeControls(root){all('[data-mph-notice-toolbar]',root).forEach(toolbar=>{if(toolbar.dataset.mphBound)return;toolbar.dataset.mphBound='1';const section=toolbar.closest('[data-announcement-feed]'),list=section&&one('.mph-announcement-list',section),sort=one('[data-mph-notice-sort]',toolbar),filter=one('[data-mph-notice-filter]',toolbar),result=one('[data-mph-notice-result]',toolbar);if(!list||!sort||!filter)return;const apply=()=>{const items=all('[data-mph-notice-item]',list),mode=sort.value;items.sort((a,b)=>{const aid=Number(a.dataset.id||0),bid=Number(b.dataset.id||0),ad=Number(a.dataset.date||0),bd=Number(b.dataset.date||0),ar=Number(a.dataset.read||0),br=Number(b.dataset.read||0);if(mode==='date-asc')return ad-bd||aid-bid;if(mode==='id-asc')return aid-bid;if(mode==='id-desc')return bid-aid;if(mode==='unread-first')return ar-br||bd-ad;if(mode==='read-first')return br-ar||bd-ad;return bd-ad||bid-aid;});let shown=0;items.forEach(item=>{const read=item.dataset.read==='1',visible=filter.value==='all'||(filter.value==='read'&&read)||(filter.value==='unread'&&!read);item.hidden=!visible;if(visible)shown++;list.appendChild(item);});if(result)result.textContent=shown+' مورد';};sort.addEventListener('change',apply);filter.addEventListener('change',apply);apply();});}
  function bindCopyControls(root){all('[data-mph-copy]',root).forEach(button=>{if(button.dataset.mphCopyBound)return;button.dataset.mphCopyBound='1';button.addEventListener('click',async()=>{const value=button.dataset.mphCopy||'';try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(value);else{const input=document.createElement('textarea');input.value=value;input.setAttribute('readonly','');input.style.position='fixed';input.style.opacity='0';document.body.appendChild(input);input.select();document.execCommand('copy');input.remove();}flash(button.closest('.mph-root')||document.body,'این لینک در کلیپ‌بورد ذخیره شد.',true);}catch(error){flash(button.closest('.mph-root')||document.body,'کپی لینک انجام نشد.',false);}});});all('[data-mph-reminder-close]',root).forEach(button=>{if(button.dataset.mphCloseBound)return;button.dataset.mphCloseBound='1';button.addEventListener('click',()=>{const popup=button.closest('[data-mph-reminder-popup]');if(popup)popup.remove();});});}
  function bindProgressControls(root){all('[data-mph-progress-delete]',root).forEach(button=>{if(button.dataset.mphDeleteBound)return;button.dataset.mphDeleteBound='1';button.addEventListener('click',event=>{event.preventDefault();if(!window.confirm('درصد دستی این هنرجو حذف شود؟'))return;const form=button.closest('form');if(!form)return;form.dataset.mphAction='mph_course_progress_delete';form.requestSubmit();});});}
  function bindTicketControls(root){all('.mph-forward-box',root).forEach(box=>{const check=one('[data-ticket-forward]',box),select=one('select[name="assigned_staff"]',box);if(!check||!select||check.dataset.forwardBound)return;check.dataset.forwardBound='1';const sync=()=>{select.disabled=!check.checked;select.required=check.checked;};check.addEventListener('change',sync);sync();});}
  function bindBaleControls(root){all('[data-bale-tab]',root).forEach(button=>{if(button.dataset.baleBound)return;button.dataset.baleBound='1';button.addEventListener('click',()=>{all('[data-bale-tab]',root).forEach(x=>x.classList.toggle('is-active',x===button));all('[data-bale-module]',root).forEach(x=>x.classList.toggle('is-active',x.dataset.baleModule===button.dataset.baleTab));});});}
  function authPanel(root,name){const card=root&&root.matches&&root.matches('.mph-smart-auth')?root:one('.mph-smart-auth',root);if(!card)return;all('[data-auth-panel]',card).forEach(x=>x.classList.toggle('is-active',x.dataset.authPanel===name));const stage=name==='phone'?1:(name==='otp_verify'||name==='email_sent'||name==='help_sent'||name==='help_verify'||name==='login_2fa'||name==='login_sms_otp'?3:2);all('.mph-auth-flow i',card).forEach((x,n)=>x.classList.toggle('is-active',n<stage));card.dataset.authStage=name;window.setTimeout(()=>{const panel=one('[data-auth-panel="'+name+'"]',card),input=panel&&one('input:not([type="hidden"]):not([readonly]),select,textarea',panel);if(input)input.focus({preventScroll:true});},140);}
  function setAuthPhone(root,phone){if(!phone)return;all('[data-auth-phone-value]',root).forEach(x=>x.value=phone);all('[data-auth-phone-label]',root).forEach(x=>x.textContent=phone);}
  function internalAccountOptions(href){
    try{const url=new URL(href,window.location.href),base=new URL(MPH_DATA.pageUrl,window.location.href);if(url.origin!==base.origin||url.pathname.replace(/\/$/,'')!==base.pathname.replace(/\/$/,''))return null;return{mode:url.searchParams.get('mph_mode')||'user',panel:url.searchParams.get('mph_open')||'',course:Number(url.searchParams.get('mph_choose_course')||0)};}catch(e){return null;}
  }
  function followRedirect(href){window.location.assign(href);return true;}
  function authResult(root,data){if(data.redirect)return followRedirect(data.redirect);if(!data.next)return false;setAuthPhone(root,data.phone);if(data.flowToken){const flow=data.next==='login_sms_otp'?one('[data-login-otp-flow]',root):one('[data-otp-flow]',root);if(flow)flow.value=data.flowToken;}if(data.loginFlow){const loginFlow=one('[data-login-2fa-flow]',root);if(loginFlow)loginFlow.value=data.loginFlow;}if(data.next==='help_sent'){try{sessionStorage.setItem('mphManagementRecovery',JSON.stringify({phone:data.phone||'',savedAt:Date.now()}));}catch(e){}}authPanel(root,data.next);const target=one('[data-auth-panel="'+data.next+'"]',root);if(target&&data.message)message(target,data.message,true);return true;}
  function sessionMount(html){
    let shell=one('#mph-standalone-content');
    if(shell){shell.innerHTML=html;}
    else{
      const inline=all('.mph-root').find(root=>!root.classList.contains('mph-global-popup-root')&&!root.closest('#mph-ajax-account-shell'));
      if(inline){inline.outerHTML=html;shell=inline.parentElement;}
      else{
        shell=one('#mph-ajax-account-shell');
        if(!shell){shell=document.createElement('main');shell.id='mph-ajax-account-shell';shell.className='mph-ajax-account-shell';document.body.appendChild(shell);}
        shell.innerHTML=html;document.body.classList.add('mph-ajax-account-active');
      }
    }
    all('.mph-global-popup-root').forEach(root=>root.remove());
    unlockScroll(true);
    all('.mph-root').forEach(root=>{delete root.dataset.mphRootBound;bindRoot(root);});
    window.scrollTo&&window.scrollTo({top:0,behavior:'smooth'});
  }
  async function refreshSession(options){
    options=options||{};
    const data=new FormData();data.append('action','mph_session_view');
    if(options.mode)data.append('session_mode',options.mode);
    if(options.panel)data.append('session_panel',options.panel);
    if(options.course)data.append('session_course',String(options.course));
    const result=await send(data);
    if(!result.success||!result.data||typeof result.data.html!=='string')throw new Error(result.data&&result.data.message?result.data.message:MPH_DATA.connectionError);
    if(result.data.nonce)MPH_DATA.nonce=result.data.nonce;
    if(typeof result.data.userId!=='undefined')MPH_DATA.userId=result.data.userId;
    if(result.data.ticketData)window.MPH_TICKET_DATA=result.data.ticketData;
    if(result.data.headerAccount){MPH_DATA.headerAccount=result.data.headerAccount;if(typeof window.MPHRefreshHeaderAccount==='function')window.MPHRefreshHeaderAccount(result.data.headerAccount);}
    sessionMount(result.data.html);
    cleanPortalUrl({mphSession:true,mode:options.mode||'user',panel:options.panel||''},false);
    return result.data;
  }
  window.MPHRefreshSession=refreshSession;
  function activateCartStage(scope,name,focus){const flows=scope&&scope.matches&&scope.matches('[data-mph-cart-flow]')?[scope]:all('[data-mph-cart-flow]',scope||document);flows.forEach(flow=>{const requested=name||flow.dataset.initialCartStage||'cart',stage=one('[data-mph-cart-stage="'+requested+'"]',flow)||one('[data-mph-cart-stage="cart"]',flow);if(!stage)return;all('[data-mph-cart-stage]',flow).forEach(item=>{const active=item===stage;item.hidden=!active;item.classList.toggle('is-active',active);});all('[data-mph-cart-step]',flow).forEach((item,index)=>{const active=item.dataset.mphCartStep===requested;item.classList.toggle('is-active',active);item.classList.toggle('is-complete',requested==='checkout'&&index===0);});flow.dataset.initialCartStage=requested;if(focus){stage.setAttribute('tabindex','-1');stage.focus({preventScroll:true});stage.scrollIntoView({behavior:'smooth',block:'start'});}});}
  function bindCartFlow(root){all('[data-mph-cart-flow]',root).forEach(flow=>{if(flow.dataset.cartFlowBound)return;flow.dataset.cartFlowBound='1';all('[data-mph-cart-next]',flow).forEach(button=>button.addEventListener('click',()=>activateCartStage(flow,'checkout',true)));all('[data-mph-cart-back]',flow).forEach(button=>button.addEventListener('click',()=>activateCartStage(flow,'cart',true)));activateCartStage(flow,flow.dataset.initialCartStage||'cart',false);});}
  function persianDigits(value){return String(value||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
  function validateBilling(flow,report){const box=flow&&one('[data-mph-invoice-fields]',flow);if(!box)return true;let valid=true;all('input,textarea',box).forEach(input=>{let error='',value=String(input.value||'').trim();if(input.required&&!value)error='این فیلد الزامی است.';if(!error&&input.name==='billing_phone'&&!/^09\d{9}$/.test(persianDigits(value).replace(/\D/g,'')))error='موبایل باید ۱۱ رقم و با 09 شروع شود.';if(!error&&input.name==='billing_email'&&value&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))error='ایمیل معتبر وارد کنید.';if(!error&&input.name==='billing_postcode'&&value&&persianDigits(value).replace(/\D/g,'').length!==10)error='کد پستی باید ۱۰ رقم باشد.';input.setAttribute('aria-invalid',error?'true':'false');const hint=input.parentElement&&one('.mph-field-error',input.parentElement);if(hint)hint.textContent=error;if(error)valid=false;});const status=one('[data-mph-billing-valid]',box);if(status){status.classList.toggle('is-valid',valid);status.innerHTML='<span class="dashicons '+(valid?'dashicons-yes-alt':'dashicons-warning')+'"></span> '+(valid?'اطلاعات صورتحساب آماده ثبت است.':'لطفاً موارد مشخص‌شده را اصلاح کنید.');}if(!valid&&report){const first=one('[aria-invalid="true"]',box);first&&first.focus();box.scrollIntoView({behavior:'smooth',block:'center'});}return valid;}
  function appendBilling(data,form){const flow=form.closest('[data-mph-cart-flow]'),box=flow&&one('[data-mph-invoice-fields]',flow);if(!box)return;all('input,textarea',box).forEach(input=>data.set(input.name,input.value));}
  function bindBilling(root){all('[data-mph-invoice-fields]',root).forEach(box=>{if(box.dataset.billingBound)return;box.dataset.billingBound='1';const flow=box.closest('[data-mph-cart-flow]');all('input,textarea',box).forEach(input=>input.addEventListener('input',()=>validateBilling(flow,false)));validateBilling(flow,false);});}
  function bindChoiceMotion(root){
    const choiceContainers='.mph-appointment-modes,.mph-appointment-payments,.mph-payment-choice,.mph-slot-mode-prices,.mph-options,.mph-course-taxonomy,.mph-role-checks,.mph-quiz-checks,.mph-delivery-builder,.mph-delivery-grid';
    const sync=input=>{const label=input.closest('label');if(!label)return;label.classList.toggle('is-choice-checked',!!input.checked);label.classList.toggle('is-choice-disabled',!!input.disabled);};
    all('input[type="radio"],input[type="checkbox"]',root).forEach(input=>{
      if(input.dataset.mphChoiceBound)return;input.dataset.mphChoiceBound='1';
      const label=input.closest('label');if(!label)return;
      label.classList.add(input.closest(choiceContainers)?'is-choice-box':'is-compact-choice');sync(input);
      input.addEventListener('change',()=>{
        const scope=input.form||input.closest('.mph-root')||document;
        if(input.type==='radio'&&input.name)all('input[type="radio"]',scope).filter(peer=>peer.name===input.name).forEach(sync);else sync(input);
        label.classList.remove('is-choice-animating');void label.offsetWidth;label.classList.add('is-choice-animating');
        window.setTimeout(()=>label.classList.remove('is-choice-animating'),460);
      });
    });
    all('.mph-action,.mph-menu-item,.mph-recovery-option,.mph-booking-time-option,.mph-certificate-course,.mph-quiz-filters button,.mph-ticket-filters button',root).forEach(box=>{
      if(box.dataset.mphPressBound)return;box.dataset.mphPressBound='1';
      const release=()=>box.classList.remove('is-pressing');
      box.addEventListener('pointerdown',()=>box.classList.add('is-pressing'));
      box.addEventListener('pointerup',release);box.addEventListener('pointercancel',release);box.addEventListener('pointerleave',release);
    });
  }
  function bindPersonNames(root){all('input[name="first_name"],input[name="last_name"],input[name="billing_first_name"],input[name="billing_last_name"],input[name="public_username"],input[name="instructor_alias"]',root).forEach(input=>{if(input.dataset.mphNameBound)return;input.dataset.mphNameBound='1';const validate=()=>{const value=input.value.trim(),valid=!value||/[A-Za-z\u0600-\u06ff]/.test(value);input.setCustomValidity(valid?'':'این مقدار باید دست‌کم شامل یک حرف باشد و نمی‌تواند فقط عدد باشد.');};input.addEventListener('input',validate);input.addEventListener('change',validate);validate();});}
  function rebindDynamic(root){bindForms(root);bindFiles(root);bindPersonNames(root);bindNoticeControls(root);bindCopyControls(root);bindProgressControls(root);bindTicketControls(root);bindBaleControls(root);bindCartFlow(root);bindBilling(root);bindChoiceMotion(root);if(typeof window.MPHInitTickets==='function')window.MPHInitTickets(root);if(typeof window.MPHInitAppointments==='function')window.MPHInitAppointments(root);if(typeof window.MPHInitWebNotifications==='function')window.MPHInitWebNotifications();}
  function bindForms(root){
    all('form[data-mph-action]',root).forEach(form=>{
      if(form.dataset.bound)return;
      form.dataset.bound='1';
      form.addEventListener('submit',async event=>{
        event.preventDefault();
        if(form.dataset.mphBusy==='1')return;
        if(form.dataset.confirm&&!event.mphConfirmed){
          event.mphConfirmed=true;
          if(!window.confirm(form.dataset.confirm))return;
        }
        const action=form.dataset.mphAction,flow=form.closest('[data-mph-cart-flow]');
        if(!action){message(form,'عملیات فرم مشخص نشده است.',false);return;}
        if((action==='mph_checkout_prepare'||action==='mph_receipt_submit')&&!validateBilling(flow,true))return;
        const cartStage=form.closest('[data-mph-cart-stage]'),activeCartStage=cartStage?cartStage.dataset.mphCartStage||'':'';
        const submitter=event.submitter||one('button[type="submit"],input[type="submit"]',form);
        const data=new FormData(form);
        appendBilling(data,form);
        if(submitter&&submitter.name)data.append(submitter.name,submitter.value);
        data.set('action',action);
        const submitters=all('button[type="submit"],input[type="submit"]',form);
        const states=submitters.map(control=>({control:control,disabled:control.disabled,html:control.tagName==='BUTTON'?control.innerHTML:'',value:control.tagName==='INPUT'?control.value:''}));
        form.dataset.mphBusy='1';form.setAttribute('aria-busy','true');
        submitters.forEach(control=>{control.disabled=true;});
        if(submitter){if(submitter.tagName==='INPUT')submitter.value=form.dataset.mphSending||MPH_DATA.working;else submitter.textContent=form.dataset.mphSending||MPH_DATA.working;}
        try{
          const result=await send(data);
          if(result.success)document.dispatchEvent(new CustomEvent('mph:form-success',{detail:{form}}));
          if(result.success&&result.data&&result.data.redirect){followRedirect(result.data.redirect);return;}
          if(result.success&&result.data&&result.data.sessionChanged){try{sessionStorage.removeItem('mphManagementRecovery');}catch(e){}closeAuthModal();window.location.assign(MPH_DATA.pageUrl);return;}
          if(result.success&&result.data&&result.data.refreshSession){const dashboard=one('.mph-dashboard');await refreshSession({mode:dashboard&&dashboard.dataset.mode?dashboard.dataset.mode:'user'});return;}
          if(result.success&&result.data&&authResult(root,result.data))return;
          if(result.success&&result.data&&result.data.html){const target=one('.mph-panel-content',root);if(target){target.innerHTML=result.data.html;rebindDynamic(root);activateCartStage(root,result.data.cartStage||activeCartStage||'cart',false);}if(result.data.clearTicketAlert)clearTicketAlert();if(result.data.clearAnnouncementAlert)clearAnnouncementAlert();if(typeof result.data.cartCount!=='undefined')all('[data-mph-cart-count]').forEach(node=>node.textContent=String(result.data.cartCount));flash(root,result.data.message,true);return;}
          if(result.success&&result.data&&result.data.identifier)all('[data-mph-user-id]',root).forEach(node=>node.textContent=result.data.identifier);
          if(result.success&&result.data&&result.data.clearAnnouncementAlert)clearAnnouncementAlert();
          message(form,result.data&&result.data.message,result.success);
        }catch(error){message(form,error.message||MPH_DATA.connectionError,false);}
        finally{
          delete form.dataset.mphBusy;form.removeAttribute('aria-busy');
          states.forEach(state=>{if(!document.body.contains(state.control))return;state.control.disabled=state.disabled;if(state.control.tagName==='INPUT')state.control.value=state.value;else state.control.innerHTML=state.html;});
        }
      });
    });
  }
  function selectPanel(root,panel){all('[data-panel]',root).forEach(x=>x.classList.toggle('is-active',x.dataset.panel===panel));const dashboard=one('.mph-dashboard',root);if(dashboard)dashboard.classList.toggle('mph-cards-visible',panel==='dashboard'||panel==='teacher_dashboard'||panel==='therapist_dashboard'||panel==='manager_dashboard');}
  function updatePanelUrl(panel){
    if(!window.history||typeof window.history.pushState!=='function')return;
    cleanPortalUrl({mphPanel:panel},false);
  }
  async function loadPanel(root,panel,writeHistory,extra){
    if(!panel||!all('[data-panel]',root).some(node=>node.dataset.panel===panel))return;
    selectPanel(root,panel);
    const target=one('.mph-panel-content',root);
    if(!target)return;
    if(root._mphPanelController)root._mphPanelController.abort();
    const controller=new AbortController();
    root._mphPanelController=controller;
    target.classList.add('is-loading');
    target.setAttribute('aria-busy','true');
    const data=new FormData();
    data.append('action','mph_panel');
    data.append('panel',panel);
    if(extra&&typeof extra==='object')Object.keys(extra).forEach(key=>data.append(key,String(extra[key])));
    try{
      const result=await send(data,{signal:controller.signal});
      if(result.success&&result.data&&result.data.redirect){followRedirect(result.data.redirect);return;}
      if(result.success){
        target.innerHTML=result.data&&typeof result.data.html==='string'?result.data.html:'';
        rebindDynamic(root);
        if(writeHistory)updatePanelUrl(panel);
        const heading=one('h2,h3',target);
        if(heading){heading.setAttribute('tabindex','-1');heading.focus({preventScroll:true});}
      }else{
        target.innerHTML='<section class="mph-section mph-error-box" role="alert">'+escapeHtml(result.data&&result.data.message?result.data.message:'خطا')+'</section>';
      }
    }catch(error){
      if(error&&error.name==='AbortError')return;
      target.innerHTML='<section class="mph-section mph-error-box" role="alert">'+escapeHtml(error&&error.message?error.message:MPH_DATA.connectionError)+'</section>';
    }finally{
      if(root._mphPanelController===controller)root._mphPanelController=null;
      target.classList.remove('is-loading');
      target.removeAttribute('aria-busy');
    }
  }
  function bindNavigation(root){
    all('[data-panel]',root).forEach(button=>{
      if(button.dataset.navBound)return;
      button.dataset.navBound='1';
      button.addEventListener('click',()=>loadPanel(root,button.dataset.panel,true));
    });
  }
  window.MPHLoadPanel=function(panel,extra){const root=all('.mph-root').find(item=>one('.mph-dashboard',item));return root?loadPanel(root,panel,true,extra||{}):Promise.resolve();};
  function bindPanelHistory(){
    if(window.__mphPanelHistoryBound)return;
    window.__mphPanelHistoryBound=true;
    window.addEventListener('popstate',event=>{
      const requested=(event.state&&(event.state.mphPanel||event.state.panel))||'';
      all('.mph-root').forEach(root=>{const dashboard=one('.mph-dashboard',root),panel=requested||(dashboard&&dashboard.dataset.initialPanel);if(panel)loadPanel(root,panel,false);});
    });
  }
  function strength(root){all('.mph-strength',root).forEach(bar=>{const label=bar.closest('label'),password=label&&one('input[type="password"]',label);if(!password||bar.dataset.strengthBound)return;bar.dataset.strengthBound='1';password.addEventListener('input',()=>{const checks=[password.value.length>=10,/[a-z]/.test(password.value),/[A-Z]/.test(password.value),/\d/.test(password.value),/[^a-zA-Z\d]/.test(password.value)],score=checks.filter(Boolean).length;bar.dataset.level=score<=1?'weak':score<=3?'medium':score===4?'good':'strong';bar.style.setProperty('--strength',(score*20)+'%');bar.setAttribute('data-label',score<=1?'ضعیف':score<=3?'متوسط':score===4?'خوب':'قوی');});});}
  function mixColor(color,target,amount){return color.map((value,index)=>Math.round(value+(target[index]-value)*amount));}
  function rgb(color){return'rgb('+color.join(',')+')';}
  function applyWelcomeColor(card,image){
    try{
      const canvas=document.createElement('canvas'),context=canvas.getContext('2d',{willReadFrequently:true});canvas.width=32;canvas.height=32;context.drawImage(image,0,0,32,32);const pixels=context.getImageData(0,0,32,32).data,buckets=new Map();
      for(let index=0;index<pixels.length;index+=4){const r=pixels[index],g=pixels[index+1],b=pixels[index+2],a=pixels[index+3];if(a<160)continue;const light=(r+g+b)/3;if(light<22||light>246)continue;const max=Math.max(r,g,b),min=Math.min(r,g,b),saturation=max-min,key=[r,g,b].map(value=>Math.round(value/32)*32).join(',');const bucket=buckets.get(key)||{weight:0,r:0,g:0,b:0,count:0},weight=1+(saturation/255);bucket.weight+=weight;bucket.r+=r;bucket.g+=g;bucket.b+=b;bucket.count++;buckets.set(key,bucket);}
      let chosen=null;buckets.forEach(bucket=>{if(!chosen||bucket.weight>chosen.weight)chosen=bucket;});if(!chosen)return;const base=[Math.round(chosen.r/chosen.count),Math.round(chosen.g/chosen.count),Math.round(chosen.b/chosen.count)],deep=mixColor(base,[8,24,36],.62),mid=mixColor(base,[255,255,255],.08),edge=mixColor(base,[255,255,255],.72);card.style.setProperty('--mph-welcome-deep',rgb(deep));card.style.setProperty('--mph-welcome-mid',rgb(mid));card.style.setProperty('--mph-welcome-edge',rgb(edge));card.classList.add('has-smart-color');
    }catch(error){card.classList.remove('has-smart-color');}
  }
  function initWelcomeColors(root){all('[data-mph-smart-welcome]',root||document).forEach(card=>{const image=one('[data-mph-welcome-image]',card);if(!image||image.dataset.mphColorBound)return;image.dataset.mphColorBound='1';const update=()=>{image.dataset.mphColorBound='1';applyWelcomeColor(card,image);};image.addEventListener('load',update);if(image.complete&&image.naturalWidth)update();});}
  function updateWelcomePhoto(root,url){const card=one('[data-mph-smart-welcome]',root),photo=card&&one('.mph-welcome-photo',card);if(!card||!photo||!url)return;let image=one('[data-mph-welcome-image]',photo);if(!image){photo.classList.remove('is-placeholder');photo.textContent='';image=document.createElement('img');image.alt='تصویر پروفایل';image.setAttribute('data-mph-welcome-image','');image.decoding='async';photo.appendChild(image);}image.dataset.mphColorBound='';image.src=url;initWelcomeColors(root);}
  function bindRoot(root){
    if(root.dataset.mphRootBound==='1')return;root.dataset.mphRootBound='1';
    root.classList.remove('mph-dark');
    all('.mph-theme-toggle',root).forEach(button=>button.remove());
    try{localStorage.removeItem('mphTheme');}catch(e){}
    all('[data-mph-phone]',root).forEach(input=>{if(input.dataset.phoneBound)return;input.dataset.phoneBound='1';input.addEventListener('input',()=>{input.value=input.value.replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g,'').slice(0,11);input.setCustomValidity(input.value&& !/^09\d{9}$/.test(input.value)?'شماره موبایل باید ۱۱ رقم و با 09 شروع شود.':'');});});
    const modal=one('.mph-auth-modal',root);all('[data-mph-open-auth]',root).forEach(x=>x.addEventListener('click',()=>ensureAuthModal(x)));all('[data-mph-close-auth]',root).forEach(x=>x.addEventListener('click',()=>{closeAuthModal(modal);restoreAuthLocation(modal);}));if(modal&&modal.classList.contains('is-open'))openAuthModal(null,modal);
    const auth=one('.mph-smart-auth',root);if(auth){const initial=auth.dataset.authStage||'phone',initialPhone=(one('[data-auth-panel="'+initial+'"] [data-auth-phone-value]',auth)||one('[data-auth-panel="phone"] input[name="phone"]',auth));if(initialPhone)setAuthPhone(auth,initialPhone.value);authPanel(auth,initial);all('[data-auth-back]',auth).forEach(button=>button.addEventListener('click',()=>authPanel(auth,button.dataset.authBack||'phone')));const recovery=one('[data-auth-recovery]',auth);if(recovery)recovery.addEventListener('click',()=>authPanel(auth,'recovery'));all('[data-recovery-option]',auth).forEach(button=>button.addEventListener('click',()=>{if(button.dataset.recoveryOption==='management'){try{const saved=JSON.parse(sessionStorage.getItem('mphManagementRecovery')||'null');if(saved&&saved.phone){setAuthPhone(auth,saved.phone);authPanel(auth,'help_sent');return;}}catch(e){}}authPanel(auth,'recovery_'+button.dataset.recoveryOption);}));all('[data-login-otp-start]',auth).forEach(button=>button.addEventListener('click',async()=>{if(button.disabled)return;const phone=(one('[data-auth-panel="password"] [data-auth-phone-value]',auth)||{}).value||'';const host=button.closest('[data-auth-panel]')||auth,old=button.textContent;button.disabled=true;button.textContent=MPH_DATA.working;const data=new FormData();data.append('action','mph_login_otp_start');data.append('phone',phone);try{const result=await send(data);if(result.success&&result.data)authResult(auth,result.data);else message(host,result.data&&result.data.message?result.data.message:'این سرویس در حال حاضر وجود ندارد',false);}catch(error){message(host,error.message||MPH_DATA.connectionError,false);}finally{button.disabled=false;button.textContent=old;}}));}
    const role=one('[data-mph-role-switch]',root);if(role)role.addEventListener('change',async()=>{if(!role.value)return;const url=new URL(role.value,window.location.href),mode=url.searchParams.get('mph_mode')||'user';role.disabled=true;try{await refreshSession({mode});}catch(error){flash(root,error.message||MPH_DATA.connectionError,false);role.disabled=false;}});
    const requestRole=one('[data-role-request]',root);if(requestRole)requestRole.addEventListener('click',async()=>{const dashboard=one('.mph-dashboard',root),target=one('.mph-panel-content',root);if(!dashboard||!target)return;requestRole.disabled=true;dashboard.classList.remove('mph-cards-visible');dashboard.classList.add('mph-role-request-active','is-busy');const data=new FormData();data.append('action','mph_panel');data.append('panel','role_request');try{const result=await send(data);if(result.success){target.innerHTML=result.data.html;rebindDynamic(root);all('[data-cancel-role-request]',target).forEach(cancel=>cancel.addEventListener('click',()=>{dashboard.classList.remove('mph-role-request-active');loadPanel(root,dashboard.dataset.initialPanel||'dashboard',false);requestRole.disabled=false;}));}else{throw new Error(result.data&&result.data.message?result.data.message:'بارگذاری فرم درخواست نقش انجام نشد.');}}catch(e){dashboard.classList.remove('mph-role-request-active');target.innerHTML='<section class="mph-section mph-error-box">'+escapeHtml(e.message||MPH_DATA.connectionError)+'</section>';requestRole.disabled=false;}finally{dashboard.classList.remove('is-busy');}});
    const logout=one('.mph-logout',root);if(logout)logout.addEventListener('click',async()=>{unlockScroll(true);logout.disabled=true;const data=new FormData();data.append('action','mph_logout');try{const result=await send(data);if(result.success){await refreshSession({mode:'user'});}}catch(e){unlockScroll(true);flash(root,e.message||MPH_DATA.connectionError,false);logout.disabled=false;}});
    all('.mph-avatar input[type="file"],.mph-avatar-button input[type="file"]',root).forEach(file=>{if(file.dataset.mphAvatarBound)return;file.dataset.mphAvatarBound='1';file.addEventListener('change',async()=>{const selected=file.files&&file.files[0];if(!selected)return;const max=Number(MPH_DATA.maxAvatarSize||2097152),allowed=['image/jpeg','image/png','image/webp'];if(selected.size>max){file.value='';flash(root,'حجم تصویر پروفایل باید حداکثر ۲ مگابایت باشد.',false);return;}if(!allowed.includes(selected.type)){file.value='';flash(root,'فقط تصویر JPG، PNG یا WebP مجاز است.',false);return;}const avatar=one('.mph-avatar',root);avatar&&avatar.classList.add('is-uploading');const data=new FormData();data.append('action','mph_avatar');data.append('avatar',selected);try{const result=await send(data);if(result.success){const img=one('.mph-avatar img',root),placeholder=one('.mph-avatar-placeholder',root);if(img)img.src=result.data.url;else if(avatar){placeholder&&placeholder.remove();avatar.insertAdjacentHTML('afterbegin',result.data.image);}updateWelcomePhoto(root,result.data.welcomeUrl||result.data.url);flash(root,result.data.message||'تصویر پروفایل به‌روزرسانی شد.',true);}else flash(root,result.data.message,false);}catch(e){flash(root,e.message||MPH_DATA.connectionError,false);}finally{avatar&&avatar.classList.remove('is-uploading');}});});
    const steps=all('[data-register-step]',root),next=one('[data-register-next]',root),back=one('[data-register-back]',root),progress=all('.mph-register-progress i',root);if(next)next.addEventListener('click',()=>{if(!all('[required]',steps[0]).every(x=>x.reportValidity()))return;steps.forEach(x=>x.classList.remove('is-active'));steps[1].classList.add('is-active');progress.forEach(x=>x.classList.add('is-active'));});if(back)back.addEventListener('click',()=>{steps.forEach(x=>x.classList.remove('is-active'));steps[0].classList.add('is-active');if(progress[1])progress[1].classList.remove('is-active');});
    initWelcomeColors(root);strength(root);bindNavigation(root);rebindDynamic(root);
  }
  function bindPopupLinks(){
    if(window.__mphLoginIntentBound)return;window.__mphLoginIntentBound=true;
    document.addEventListener('click',event=>{
      if(event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
      if(MPH_DATA.headerAccount&&MPH_DATA.headerAccount.loggedIn)return;
      const control=event.target.closest('a[href],button,[role="button"],[data-mph-open-auth],[data-login],[data-open-login]');if(!control||control.closest('.mph-smart-auth,.mph-auth-modal'))return;
      let intent=control.matches('[data-mph-open-auth],[data-login],[data-open-login],.login-button,.btn-login,.header-login,.account-login,.login-register,.account-icon,.user-account,.wd-header-my-account');
      const href=control.matches('a[href]')?control.href:'';
      if(href){try{const url=new URL(href,location.href),account=new URL(MPH_DATA.pageUrl||location.href,location.href),sameAccount=url.origin===account.origin&&url.pathname.replace(/\/$/,'')===account.pathname.replace(/\/$/,'');intent=intent||sameAccount||/\/wp-login\.php$/i.test(url.pathname)||url.searchParams.get('mph_profile_popup')==='1'||url.searchParams.get('mph_auth')==='1';}catch(error){}}
      const classes=String(control.className||'');if(/(?:^|[\s_-])(login|signin|sign-in|account)(?:$|[\s_-])/i.test(classes))intent=true;
      const label=String(control.textContent||control.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim();if(label.length<80&&/(?:ورود(?: به حساب)?|ثبت[‌ ]?نام|ورود یا ثبت[‌ ]?نام)/.test(label)&&!/خروج/.test(label))intent=true;
      if(!intent)return;event.preventDefault();event.stopPropagation();event.stopImmediatePropagation();rememberAuthOrigin();ensureAuthModal(control);
    },true);
  }
  function bindSpaLinks(){
    if(window.__mphSpaLinksBound)return;window.__mphSpaLinksBound=true;
    document.addEventListener('click',event=>{
      if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
      const link=event.target.closest('.mph-root a[href]');if(!link||link.target==='_blank'||link.hasAttribute('download')||link.hasAttribute('data-mph-no-spa')||link.hasAttribute('data-mph-course-edit'))return;
      const options=internalAccountOptions(link.href);if(!options)return;
      event.preventDefault();refreshSession(options).catch(error=>flash(link.closest('.mph-root')||document.body,error.message||MPH_DATA.connectionError,false));
    });
  }
  function bindNetworkState(){
    if(window.__mphNetworkBound)return;
    window.__mphNetworkBound=true;
    const sync=()=>{
      const offline=navigator.onLine===false;
      document.documentElement.classList.toggle('mph-is-offline',offline);
      if(offline)all('.mph-root').forEach(root=>flash(root,'اتصال اینترنت قطع است؛ عملیات پس از اتصال دوباره قابل انجام است.',false));
    };
    window.addEventListener('offline',sync);
    window.addEventListener('online',()=>{sync();all('.mph-root').forEach(root=>flash(root,'اتصال اینترنت دوباره برقرار شد.',true));});
    sync();
  }
  function watchScrollLock(){
    if(window.__mphScrollWatch)return;window.__mphScrollWatch=true;
    const clean=()=>{if(one('.mph-auth-modal.is-open')||one('[data-mph-date-modal]:not([hidden])'))return;const body=document.body,html=document.documentElement,stale=modalState.locked||html.classList.contains('mph-modal-open')||html.classList.contains('mph-date-open')||(body&&(body.classList.contains('mph-modal-open')||body.classList.contains('mph-date-open')));if(stale)unlockScroll(true);};
    const observer=new MutationObserver(clean);observer.observe(document.documentElement,{attributes:true,attributeFilter:['class','style']});
    if(document.body)observer.observe(document.body,{attributes:true,attributeFilter:['class','style']});
    document.addEventListener('click',()=>window.setTimeout(clean,0));window.setInterval(clean,2500);clean();
  }
  function start(){unlockScroll(true);watchScrollLock();installAjaxLoader();bindPopupLinks();bindPanelHistory();bindNetworkState();all('.mph-root').forEach(bindRoot);const dashboard=one('.mph-dashboard');cleanPortalUrl(dashboard?{mphPanel:dashboard.dataset.initialPanel||'',mode:dashboard.dataset.mode||'user'}:{});}
  const HOUR_IN_SECONDS=3600000;window.addEventListener('pageshow',()=>unlockScroll(true));window.addEventListener('pagehide',()=>unlockScroll(true));if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
