(function () {
  'use strict';
  const all=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const uid=()=>String(window.MPH_DATA&&MPH_DATA.userId||0);
  const id=()=>window.crypto&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)+'-'+Math.random().toString(36).slice(2);
  const originalFetch=window.fetch.bind(window);
  const storage={get(k){try{return JSON.parse(sessionStorage.getItem(k)||'null');}catch(e){return null;}},set(k,v){try{sessionStorage.setItem(k,JSON.stringify(v));}catch(e){}},remove(k){try{sessionStorage.removeItem(k);}catch(e){}}};
  const draftNames=/^(course_title|course_excerpt|course_content|section_title\[\d+\]|lesson_title\[\d+\]\[\d+\]|notice_title|notice_message|announcement_title|announcement_message|reminder_title|reminder_date|reminder_time)$/;
  function action(form){return form.dataset.mphAction||form.dataset.mphTicketAction||(form.hasAttribute('data-mph-course-admin-save')?'mph_course_admin_save':'');}
  function formKey(form){const names=['course_id','user_id','ticket_id','order_id'];return 'mph28:'+uid()+':'+action(form)+':'+names.map(n=>form.querySelector('[name="'+n+'"]')?.value||'').join(':');}
  function notice(form,text){let el=form.querySelector('.mph-recovery-note');if(!el){el=document.createElement('p');el.className='mph-recovery-note';form.prepend(el);}el.textContent=text;}
  async function rpc(data){data.set('nonce',MPH_DATA.nonce);const res=await originalFetch(MPH_DATA.ajaxUrl,{method:'POST',credentials:'same-origin',body:data,cache:'no-store'});const json=await res.json();if(!json.success){const err=new Error(json.data?.message||'درخواست انجام نشد.');err.conflict=!!json.data?.conflict;throw err;}return json.data;}
  function setupForm(form){
    if(form.dataset.mphExperience)return;form.dataset.mphExperience='1';
    form.addEventListener('input',()=>{form._mphRequestId='';});
    form.addEventListener('change',()=>{form._mphRequestId='';});
    form.addEventListener('formdata',e=>{
      if(!form._mphRequestId)form._mphRequestId=id();e.formData.set('_mph_request_id',form._mphRequestId);
      all('input[type="file"][data-mph-staged-id]',form).forEach(input=>{if(input.dataset.mphStagedId){e.formData.delete(input.name);e.formData.set('mph_attachment_id',input.dataset.mphStagedId);}});
    });
    const fields=all('input[name],textarea[name]',form).filter(el=>draftNames.test(el.name)&&!el.disabled&&el.type!=='hidden');
    if(uid()==='0'||!fields.length)return;
    const key=formKey(form),saved=storage.get(key);
    if(saved&&saved.user===uid()){
      const box=document.createElement('div');box.className='mph-draft-note';box.append('پیش‌نویس ذخیره‌شده این فرم موجود است. ');
      for(const [title,restore] of [['بازیابی',true],['حذف پیش‌نویس',false]]){const b=document.createElement('button');b.type='button';b.className='mph-secondary';b.textContent=title;b.onclick=()=>{if(restore)fields.forEach(el=>{if(Object.prototype.hasOwnProperty.call(saved.values,el.name)){el.value=saved.values[el.name];el.dispatchEvent(new Event('input',{bubbles:true}));}});else storage.remove(key);box.remove();};box.append(b);}form.prepend(box);
    }
    let timer;form.addEventListener('input',()=>{form._mphRequestId='';clearTimeout(timer);timer=setTimeout(()=>{const values={};fields.forEach(el=>values[el.name]=el.value);storage.set(key,{user:uid(),values});},350);});
  }
  function fileState(input,phase,percent,text){const ui=input._mphUpload;if(!ui)return;ui.box.dataset.phase=phase;ui.bar.value=percent;ui.label.textContent=text;ui.retry.hidden=phase!=='failed';}
  function preview(input){
    const file=input.files&&input.files[0];if(input._mphUpload){if(input._mphUpload.url)URL.revokeObjectURL(input._mphUpload.url);input._mphUpload.box.remove();}
    delete input.dataset.mphStagedId;input._mphUpload=null;if(!file)return;
    const box=document.createElement('div');box.className='mph-upload-preview';const name=document.createElement('b');name.textContent=file.name;box.append(name);
    const size=document.createElement('small');size.textContent=(file.size/1048576).toFixed(2)+' مگابایت';box.append(size);
    const url=URL.createObjectURL(file);
    if(/^image\/(jpeg|png|gif|webp)$/.test(file.type)){const img=new Image();img.src=url;img.alt='پیش‌نمایش فایل انتخابی';box.append(img);}
    else if(file.type==='application/pdf'){const object=document.createElement('object');object.type='application/pdf';object.data=url;object.textContent='پیش‌نمایش PDF در این مرورگر پشتیبانی نمی‌شود.';box.append(object);}
    const bar=document.createElement('progress');bar.max=100;bar.value=0;box.append(bar);const label=document.createElement('span');label.textContent='آماده بارگذاری';box.append(label);
    const retry=document.createElement('button');retry.type='button';retry.className='mph-secondary';retry.textContent='تلاش مجدد فقط برای پیوست';retry.hidden=true;box.append(retry);
    const replace=document.createElement('button');replace.type='button';replace.className='mph-secondary';replace.textContent='تعویض فایل';replace.onclick=()=>input.click();box.append(replace);
    input.insertAdjacentElement('afterend',box);input._mphUpload={box,bar,label,retry,url,file};
    const staged=['ticket_attachment','receipt_file'].includes(input.name);
    retry.textContent=staged?'تلاش مجدد فقط برای پیوست':'تلاش مجدد ارسال فرم';
    retry.onclick=()=>staged?stage(input):input.form?.requestSubmit();
    if(input.name==='ticket_attachment'||input.name==='receipt_file'){
      size.textContent+=' · حداکثر ۲ مگابایت';if(file.size>2097152){fileState(input,'failed',0,'حجم فایل بیشتر از ۲ مگابایت است؛ فایل را تعویض کنید.');retry.hidden=true;return;}stage(input);
    }
  }
  function stage(input){
    const ui=input._mphUpload;if(!ui||ui.file.size>2097152)return Promise.reject(new Error('حجم فایل مجاز نیست.'));
    if(ui.promise)return ui.promise;
    const data=new FormData();data.set('action','mph_private_upload');data.set('nonce',MPH_DATA.nonce);data.set('purpose',input.name==='receipt_file'?'receipt':'ticket');data.set('file',ui.file);data.set('_mph_request_id',ui.requestId||(ui.requestId=id()));
    ui.promise=new Promise((resolve,reject)=>{
      const xhr=new XMLHttpRequest();xhr.open('POST',MPH_DATA.ajaxUrl);xhr.withCredentials=true;xhr.timeout=60000;
      fileState(input,'uploading',0,'در حال بارگذاری… ۰٪');
      xhr.upload.onprogress=e=>{if(e.lengthComputable){const p=Math.round(e.loaded/e.total*100);fileState(input,'uploading',p,'بارگذاری '+p+'٪');}};
      xhr.upload.onload=()=>fileState(input,'processing',100,'بارگذاری تمام شد؛ در حال بررسی فایل…');
      const fail=message=>{fileState(input,'failed',0,message);reject(new Error(message));};
      xhr.onload=()=>{try{const result=JSON.parse(xhr.responseText);if(!result.success){fail(result.data?.message||'ثبت فایل انجام نشد.');return;}if(input._mphUpload!==ui){resolve();return;}input.dataset.mphStagedId=String(result.data.file_id);fileState(input,'complete',100,'✓ '+ui.file.name+' — پیوست آماده است');resolve();}catch(e){fail('پاسخ فایل دریافت نشد؛ فقط پیوست را دوباره ارسال کنید.');}};
      xhr.onerror=()=>fail('ارتباط قطع شد؛ متن فرم محفوظ است.');xhr.ontimeout=()=>fail('زمان ارسال تمام شد؛ دوباره تلاش کنید.');xhr.send(data);
    }).finally(()=>{ui.promise=null;});
    ui.promise.catch(()=>{});return ui.promise;
  }
  document.addEventListener('change',e=>{if(e.target.matches('.mph-root input[type="file"]'))preview(e.target);},true);
  document.addEventListener('submit',async e=>{
    const form=e.target;if(!form.matches('.mph-root form'))return;
    const inputs=all('input[type="file"]',form).filter(input=>['ticket_attachment','receipt_file'].includes(input.name)&&input.files?.length&&!input.dataset.mphStagedId);
    if(!inputs.length)return;e.preventDefault();e.stopImmediatePropagation();if(form._mphStaging)return;form._mphStaging=true;
    try{for(const input of inputs){if(!input._mphUpload)preview(input);await stage(input);}form._mphStaging=false;form.requestSubmit(e.submitter||undefined);}catch(err){notice(form,err.message);form._mphStaging=false;}
  },true);
  function tables(root){all('.mph-root table',root).forEach(table=>{
    if(table.dataset.mphResponsive)return;table.dataset.mphResponsive='1';const headers=all('thead th',table).map(th=>th.textContent.trim());
    const rows=all('tbody tr',table);const regular=headers.length&&rows.every(tr=>all('td',tr).every(td=>td.colSpan===1&&td.rowSpan===1));
    if(regular){table.classList.add('mph-responsive-table');rows.forEach(tr=>all('td',tr).forEach((td,i)=>td.dataset.label=headers[i]||''));}
    if(!table.parentElement.classList.contains('mph-table-scroll')){const wrap=document.createElement('div');wrap.className='mph-table-scroll';table.before(wrap);wrap.append(table);}
  });}
  function listState(root){all('.mph-root [data-ticket-sort],.mph-root [data-ticket-filter],.mph-root [data-ticket-search],.mph-root [data-mph-notice-sort],.mph-root [data-mph-notice-filter],.mph-root input[type="search"],.mph-root select[data-filter]',root).forEach(el=>{
    if(el.dataset.mphRemember)return;el.dataset.mphRemember='1';const panel=el.closest('.mph-ticket-system,.mph-section');const kind=Array.from(el.attributes).find(a=>/sort|filter|search/.test(a.name))?.name||el.name;const key='mph-list:'+uid()+':'+(panel?.className||'')+':'+kind;
    const saved=storage.get(key);if(saved!==null){el.value=saved;setTimeout(()=>el.dispatchEvent(new Event(el.type==='search'?'input':'change',{bubbles:true})),0);}el.addEventListener('change',()=>storage.set(key,el.value));el.addEventListener('input',()=>storage.set(key,el.value));
  });}
  function ticketState(root){all('.mph-root .mph-ticket-system',root).forEach(system=>{
    if(system.dataset.mphState)return;system.dataset.mphState='1';
    const key='mph-ticket-view:'+uid()+':'+(document.querySelector('.mph-dashboard')?.dataset.mode||'user'),saved=storage.get(key)||{};
    const filter=saved.filter&&system.querySelector('[data-ticket-filter="'+CSS.escape(saved.filter)+'"]');if(filter)setTimeout(()=>filter.click(),0);
    const card=saved.open&&system.querySelector('.mph-ticket-card[data-ticket-id="'+CSS.escape(String(saved.open))+'"]');if(card){const toggle=card.querySelector('[data-ticket-toggle]');if(toggle)setTimeout(()=>toggle.click(),0);}
    system.addEventListener('click',event=>{const f=event.target.closest('[data-ticket-filter]'),t=event.target.closest('[data-ticket-toggle]');const state=storage.get(key)||{};if(f)state.filter=f.dataset.ticketFilter;if(t){const c=t.closest('[data-ticket-id]');state.open=c&&c.classList.contains('is-open')?'':c?.dataset.ticketId||'';}storage.set(key,state);});
  });}
  function playback(root){all('video[data-mph-course][data-mph-video]',root).forEach(video=>{
    if(video.dataset.mphResume)return;video.dataset.mphResume='1';let revision='',ready=false,busy=false,last=0;
    const body=()=>{const data=new FormData();data.set('action','mph_playback');data.set('course_id',video.dataset.mphCourse);data.set('video_id',video.dataset.mphVideo);return data;};
    rpc(body()).then(saved=>{revision=saved.revision||'';const restore=()=>{if(saved.position>1&&Number.isFinite(video.duration)&&saved.position<video.duration-3)video.currentTime=saved.position;ready=true;};if(video.readyState>=1)restore();else video.addEventListener('loadedmetadata',restore,{once:true});}).catch(()=>{ready=false;});
    const save=async(force)=>{if(!ready||busy||(!force&&Date.now()-last<15000))return;busy=true;last=Date.now();const data=body();data.set('position',String(video.currentTime));data.set('revision',revision);try{const result=await rpc(data);revision=result.revision;}catch(err){if(err.conflict)ready=false;}finally{busy=false;}};
    video.addEventListener('timeupdate',()=>save(false));video.addEventListener('pause',()=>save(true));video.addEventListener('ended',()=>save(true));
    document.addEventListener('visibilitychange',()=>{if(document.hidden)save(true);});
  });}
  function scan(root=document){all('.mph-root form',root).forEach(setupForm);tables(root);listState(root);ticketState(root);playback(root);}
  const underlyingFetch=window.fetch.bind(window);
  window.fetch=function(input,options){
    const data=options&&options.body;
    if(!(data instanceof FormData)||!/^mph_/.test(String(data.get('action')||'')))return underlyingFetch(input,options);
    const files=Array.from(data.values()).filter(value=>value instanceof File&&value.size);
    if(!files.length)return underlyingFetch(input,options);
    const inputs=all('.mph-root input[type="file"]').filter(el=>el.files&&Array.from(el.files).some(f=>files.some(sent=>sent.name===f.name&&sent.size===f.size)));
    return new Promise((resolve,reject)=>{
      const xhr=new XMLHttpRequest();xhr.open('POST',typeof input==='string'?input:input.url);xhr.withCredentials=true;xhr.timeout=60000;
      if(options.headers)new Headers(options.headers).forEach((value,key)=>xhr.setRequestHeader(key,value));
      const progress=(phase,p,text)=>inputs.forEach(el=>{if(!el._mphUpload)preview(el);fileState(el,phase,p,text);});
      xhr.upload.onprogress=e=>{if(e.lengthComputable){const p=Math.round(e.loaded/e.total*100);progress('uploading',p,'بارگذاری '+p+'٪');}};
      xhr.upload.onload=()=>progress('processing',100,'در حال ثبت…');
      const abort=()=>xhr.abort();if(options.signal)options.signal.addEventListener('abort',abort,{once:true});
      const clean=()=>options.signal&&options.signal.removeEventListener('abort',abort);
      xhr.onload=()=>{clean();let success=false;try{success=!!JSON.parse(xhr.responseText).success;}catch(e){}progress(success?'complete':'failed',success?100:0,success?'✓ فایل و فرم ثبت شدند':'ثبت انجام نشد؛ اطلاعات فرم محفوظ است.');resolve(new Response(xhr.responseText,{status:xhr.status||502,headers:{'Content-Type':'application/json'}}));};
      xhr.onerror=xhr.ontimeout=()=>{clean();progress('failed',0,'ارتباط کامل نشد؛ وضعیت را بررسی و دوباره تلاش کنید.');reject(new Error('ارتباط با سرور کامل نشد.'));};xhr.onabort=()=>{clean();reject(new DOMException('Aborted','AbortError'));};if(options.signal?.aborted){reject(new DOMException('Aborted','AbortError'));return;}xhr.send(data);
    });
  };
  let queued=false;new MutationObserver(records=>{if(!records.some(r=>Array.from(r.addedNodes).some(n=>n.nodeType===1)))return;if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;scan();});}).observe(document.documentElement,{childList:true,subtree:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>scan());else scan();
  document.addEventListener('mph:form-success',e=>{if(e.detail?.form){storage.remove(formKey(e.detail.form));e.detail.form._mphRequestId='';}});
})();
