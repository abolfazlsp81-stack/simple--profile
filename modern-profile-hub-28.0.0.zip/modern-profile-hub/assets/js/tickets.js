(function () {
  'use strict';

  if (typeof MPH_TICKET_DATA === 'undefined') return;

  const one = (selector, context) => (context || document).querySelector(selector);
  const all = (selector, context) => Array.from((context || document).querySelectorAll(selector));
  let alertMutedUntil = 0;

  function formMessage(form, text, success) {
    const box = one('.mph-message', form);
    if (!box) return;
    box.textContent = text || '';
    box.className = 'mph-message ' + (success ? 'is-success' : 'is-error');
  }

  function toast(text, success) {
    let box = one('.mph-ticket-toast');
    if (!box) {
      box = document.createElement('div');
      box.className = 'mph-ticket-toast';
      box.setAttribute('role', 'status');
      document.body.appendChild(box);
    }
    box.textContent = text;
    box.className = 'mph-ticket-toast ' + (success ? 'is-success' : 'is-error') + ' is-show';
    clearTimeout(box._timer);
    box._timer = setTimeout(() => box.classList.remove('is-show'), 4000);
  }

  function request(form, submitter) {
    const body = new FormData(form);
    if (submitter && submitter.name) body.append(submitter.name, submitter.value);
    body.append('action', form.dataset.mphTicketAction);
    body.append('nonce', MPH_TICKET_DATA.nonce);
    const fileInput = one('[data-ticket-file]', form);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', MPH_TICKET_DATA.ajaxUrl, true);
      xhr.withCredentials = true;
      xhr.timeout = Math.max(15000, Number(MPH_TICKET_DATA.requestTimeout) || 45000);
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
      xhr.upload.addEventListener('progress', event => {
        if (!fileInput || !fileInput.files[0] || !event.lengthComputable) return;
        const percent = Math.max(1, Math.min(99, Math.round((event.loaded / event.total) * 100)));
        updateFileState(fileInput, { phase: 'uploading', percent: percent });
      });
      xhr.upload.addEventListener('load', () => {
        if (fileInput && fileInput.files[0]) updateFileState(fileInput, { phase: 'processing', percent: 100 });
      });
      xhr.addEventListener('load', () => {
        const raw = (xhr.responseText || '').replace(/^\uFEFF/, '').trim();
        try {
          if (raw === '0') throw new Error('مسیر ارسال تیکت در وردپرس فعال نیست؛ افزونه را به‌روزرسانی و صفحه را تازه‌سازی کنید.');
          if (raw === '-1') throw new Error('اعتبار صفحه منقضی شده است؛ صفحه را تازه‌سازی کنید.');
          const result = JSON.parse(raw);
          if (fileInput && fileInput.files[0]) {
            if (result && result.success) {
              updateFileState(fileInput, { phase: 'complete', percent: 100 });
              window.setTimeout(() => resolve(result), 320);
              return;
            }
            updateFileState(fileInput, { phase: 'failed', percent: 100 });
          }
          resolve(result);
        } catch (error) {
          if (fileInput && fileInput.files[0]) updateFileState(fileInput, { phase: 'failed', percent: 100 });
          reject(error instanceof SyntaxError ? new Error((raw && raw.length < 240 ? raw : MPH_TICKET_DATA.connectionError) || MPH_TICKET_DATA.connectionError) : error);
        }
      });
      xhr.addEventListener('error', () => {
        if (fileInput && fileInput.files[0]) updateFileState(fileInput, { phase: 'failed', percent: 0 });
        reject(new Error(MPH_TICKET_DATA.connectionError));
      });
      xhr.addEventListener('abort', () => {
        if (fileInput && fileInput.files[0]) updateFileState(fileInput, { phase: 'failed', percent: 0 });
        reject(new Error('ارسال فایل لغو شد.'));
      });
      xhr.addEventListener('timeout', () => {
        if (fileInput && fileInput.files[0]) updateFileState(fileInput, { phase: 'failed', percent: 0 });
        reject(new Error('زمان پاسخ سرور تمام شد؛ دوباره تلاش کنید.'));
      });
      xhr.send(body);
    });
  }

  function replaceSystem(html, ticketId, source) {
    const target = source ? source.closest('.mph-panel-content') : one('.mph-panel-content');
    if (!target) return;
    const previous = source ? source.closest('.mph-ticket-system') : one('.mph-ticket-system', target);
    const previousSort = previous && one('[data-ticket-sort]', previous) ? one('[data-ticket-sort]', previous).value : '';
    const previousSearch = previous && one('[data-ticket-search]', previous) ? one('[data-ticket-search]', previous).value : '';
    const previousFilter = previous && one('[data-ticket-filter].is-active', previous) ? one('[data-ticket-filter].is-active', previous).dataset.ticketFilter : 'all';
    target.innerHTML = html;
    target.classList.remove('is-loading');
    const system = one('.mph-ticket-system', target);
    if (system) {
      const sort = one('[data-ticket-sort]', system);
      const search = one('[data-ticket-search]', system);
      const filter = one('[data-ticket-filter="' + previousFilter + '"]', system);
      if (sort && previousSort && all('option', sort).some(option => option.value === previousSort)) sort.value = previousSort;
      if (search && previousSearch) search.value = previousSearch;
      if (filter) all('[data-ticket-filter]', system).forEach(button => button.classList.toggle('is-active', button === filter));
      applyFilters(system);
    }

    if (ticketId) {
      const card = one('.mph-ticket-card[data-ticket-id="' + ticketId + '"]', target);
      if (card) {
        setTicketOpen(card, true, false);
        card.classList.add('is-just-updated');
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }

  function setTicketOpen(card, shouldOpen, closeOthers) {
    if (!card) return;
    const system = card.closest('.mph-ticket-system');
    if (shouldOpen && closeOthers && system) {
      all('.mph-ticket-card.is-open', system).forEach(other => {
        if (other !== card) setTicketOpen(other, false, false);
      });
    }

    const button = one('[data-ticket-toggle]', card);
    const details = one('.mph-ticket-details', card);
    if (!button || !details) return;
    card.classList.toggle('is-open', shouldOpen);
    button.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
    details.hidden = !shouldOpen;
  }

  function setTicketAlert(active) {
    if (!active) {
      if (typeof window.MPHClearTicketAlert === 'function') window.MPHClearTicketAlert();
      all('.mph-ticket-alert .mph-alert-dot').forEach(dot => dot.remove());
      all('.mph-ticket-alert').forEach(item => item.classList.remove('mph-ticket-alert'));
    }
    all('[data-panel="ticket_support"]').forEach(item => {
      item.classList.toggle('mph-ticket-alert', active);
      let dot = one('.mph-alert-dot', item);
      if (active && !dot) {
        dot = document.createElement('i');
        dot.className = 'mph-alert-dot';
        dot.setAttribute('aria-label', 'پاسخ جدید');
        item.appendChild(dot);
      } else if (!active && dot) {
        dot.remove();
      }
    });
  }

  async function checkTicketAlert() {
    const dashboard = one('.mph-dashboard');
    if (!dashboard || document.hidden) return;
    const mode = dashboard.dataset.mode || MPH_TICKET_DATA.mode || 'user';
    if (!['user', 'instructor', 'therapist', 'manager'].includes(mode)) return;

    const body = new URLSearchParams();
    body.set('action', 'mph_ticket_v10_alert');
    body.set('nonce', MPH_TICKET_DATA.nonce);
    body.set('ticket_mode', mode);

    try {
      const response = await fetch(MPH_TICKET_DATA.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: body.toString()
      });
      const result = await response.json();
      if (result.success && result.data) {
        const active=Boolean(result.data.hasAlert);
        if (!active) { alertMutedUntil=0;setTicketAlert(false); }
        else if (Date.now() >= alertMutedUntil) setTicketAlert(true);
      }
    } catch (error) {
      // خطای موقت شبکه نباید مزاحم کاربر یا سایر بخش‌های داشبورد شود.
    }
  }

  function humanFileSize(bytes) {
    if (bytes < 1024) return bytes + ' بایت';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' کیلوبایت';
    return (bytes / 1048576).toFixed(1) + ' مگابایت';
  }

  function updateFileState(input, options) {
    const form = input && input.closest('form');
    const box = form ? one('[data-ticket-file-state]', form) : null;
    if (!box) return;
    const file = input.files && input.files[0];
    box.textContent = '';
    box.className = 'mph-ticket-file-state';
    if (!file) {
      const empty = document.createElement('span');
      empty.className = 'mph-ticket-file-empty';
      empty.textContent = 'فایلی انتخاب نشده است.';
      box.appendChild(empty);
      return;
    }

    options = options && typeof options === 'object' ? options : { phase: 'ready', percent: 0 };
    const phase = ['ready', 'uploading', 'processing', 'complete', 'failed'].includes(options.phase) ? options.phase : 'ready';
    const percent = Math.max(0, Math.min(100, Number(options.percent) || 0));
    const status = {
      ready: 'آماده ارسال',
      uploading: 'در حال آپلود ' + percent + '٪',
      processing: 'آپلود کامل؛ در حال ثبت پیوست',
      complete: 'پیوست با موفقیت ثبت شد',
      failed: 'ارسال پیوست ناموفق بود'
    }[phase];

    const icon = document.createElement('span');
    icon.className = 'mph-ticket-file-icon';
    icon.textContent = phase === 'complete' ? '✓' : (phase === 'failed' ? '!' : (phase === 'ready' ? '＋' : percent + '٪'));
    const copy = document.createElement('span');
    copy.className = 'mph-ticket-file-copy';
    const name = document.createElement('b');
    name.textContent = file.name;
    const meta = document.createElement('small');
    meta.textContent = humanFileSize(file.size) + ' — ' + status;
    copy.appendChild(name);
    copy.appendChild(meta);
    const progress = document.createElement('span');
    progress.className = 'mph-ticket-file-progress';
    const fill = document.createElement('i');
    fill.style.width = (phase === 'ready' ? 0 : percent) + '%';
    progress.appendChild(fill);
    box.appendChild(icon);
    box.appendChild(copy);
    box.appendChild(progress);
    box.classList.add('is-active', 'is-' + phase);
  }

  function validateFile(form) {
    const fileInput = one('[data-ticket-file]', form);
    if (!fileInput || !fileInput.files[0]) {
      if (fileInput) updateFileState(fileInput);
      return true;
    }
    if (fileInput.files[0].size <= Number(MPH_TICKET_DATA.maxFile)) {
      updateFileState(fileInput, { phase: 'ready', percent: 0 });
      return true;
    }
    formMessage(form, 'حجم فایل باید حداکثر ۲ مگابایت باشد.', false);
    fileInput.value = '';
    updateFileState(fileInput, { phase: 'ready', percent: 0 });
    return false;
  }

  function sortTickets(system) {
    const select = one('[data-ticket-sort]', system);
    const value = select ? select.value : 'updated-desc';
    const list = one('.mph-ticket-list', system);
    if (!list) return;
    const cards = all('.mph-ticket-card', list);
    const numeric = (card, key) => Number(card.dataset[key] || 0);
    const compare = (a, b) => {
      if (value === 'updated-asc') return numeric(a, 'ticketUpdated') - numeric(b, 'ticketUpdated');
      if (value === 'id-desc') return numeric(b, 'ticketId') - numeric(a, 'ticketId');
      if (value === 'id-asc') return numeric(a, 'ticketId') - numeric(b, 'ticketId');
      if (value === 'priority-desc') return numeric(b, 'ticketPriority') - numeric(a, 'ticketPriority') || numeric(b, 'ticketUpdated') - numeric(a, 'ticketUpdated');
      if (value === 'unanswered-first') return numeric(a, 'ticketAnswered') - numeric(b, 'ticketAnswered') || numeric(b, 'ticketPriority') - numeric(a, 'ticketPriority') || numeric(b, 'ticketUpdated') - numeric(a, 'ticketUpdated');
      if (value === 'answered-first') return numeric(b, 'ticketAnswered') - numeric(a, 'ticketAnswered') || numeric(b, 'ticketUpdated') - numeric(a, 'ticketUpdated');
      if (value === 'unread-desc') return numeric(b, 'ticketUnread') - numeric(a, 'ticketUnread') || numeric(b, 'ticketUpdated') - numeric(a, 'ticketUpdated');
      if (value === 'status-asc') return numeric(a, 'ticketStatusRank') - numeric(b, 'ticketStatusRank') || numeric(b, 'ticketUpdated') - numeric(a, 'ticketUpdated');
      return numeric(b, 'ticketUpdated') - numeric(a, 'ticketUpdated');
    };
    const anchor = one('.mph-ticket-filter-empty', list);
    cards.sort(compare).forEach(card => list.insertBefore(card, anchor));
  }

  function applyFilters(system) {
    if (!system) return;
    sortTickets(system);
    const active = one('[data-ticket-filter].is-active', system);
    const filter = active ? active.dataset.ticketFilter : 'all';
    const searchInput = one('[data-ticket-search]', system);
    const query = searchInput ? searchInput.value.trim().toLocaleLowerCase('fa-IR') : '';
    const cards = all('.mph-ticket-card', system);
    let visible = 0;

    cards.forEach(card => {
      const statusMatches = filter === 'all' || card.dataset.ticketStatus === filter;
      const haystack = (card.dataset.ticketSearch || '').toLocaleLowerCase('fa-IR');
      const searchMatches = !query || haystack.includes(query);
      card.hidden = !(statusMatches && searchMatches);
      if (!card.hidden) visible += 1;
    });

    const counter = one('[data-ticket-visible-count]', system);
    if (counter) counter.textContent = visible + ' مورد';
    const empty = one('.mph-ticket-filter-empty', system);
    if (empty) empty.hidden = visible !== 0 || cards.length === 0;
  }

  document.addEventListener('submit', async event => {
    const form = event.target.closest('form[data-mph-ticket-action]');
    if (!form) return;
    event.preventDefault();
    if (event.submitter && event.submitter.name === 'ticket_operation' && event.submitter.value === 'close') {
      if (!window.confirm('از بستن این تیکت مطمئن هستید؟ در صورت نیاز می‌توانید بعداً با ارسال پیام دوباره آن را باز کنید.')) return;
    }
    if (form.dataset.ticketBusy || !validateFile(form)) return;

    const button = event.submitter || one('button[type="submit"]', form);
    const old = button ? button.innerHTML : '';
    const ticketIdInput = one('input[name="ticket_id"]', form);
    const ticketId = ticketIdInput ? ticketIdInput.value : '';
    form.dataset.ticketBusy = '1';

    if (button) {
      button.disabled = true;
      button.innerHTML = '<span class="mph-ticket-spinner" aria-hidden="true"></span>' + MPH_TICKET_DATA.working;
    }
    formMessage(form, '', true);

    try {
      const result = await request(form, event.submitter);
      if(result.success)document.dispatchEvent(new CustomEvent('mph:form-success',{detail:{form}}));
      const message = result.data && result.data.message
        ? result.data.message
        : (result.success ? 'عملیات انجام شد.' : 'عملیات انجام نشد.');

      if (!result.success) {
        formMessage(form, message, false);
        toast(message, false);
        return;
      }

      if (result.data && result.data.html) {
        replaceSystem(result.data.html, (result.data.focusTicket || ticketId), form);
      }
      if (result.data && result.data.clearTicketAlert) {
        alertMutedUntil=Date.now()+60000;
        setTicketAlert(false);
      }
      toast(message, true);
    } catch (error) {
      formMessage(form, error.message || MPH_TICKET_DATA.connectionError, false);
      toast(error.message || MPH_TICKET_DATA.connectionError, false);
    } finally {
      delete form.dataset.ticketBusy;
      if (button && document.body.contains(button)) {
        button.disabled = false;
        button.innerHTML = old;
      }
    }
  });

  document.addEventListener('click', event => {
    const filter = event.target.closest('[data-ticket-filter]');
    if (filter) {
      const system = filter.closest('.mph-ticket-system');
      all('[data-ticket-filter]', system).forEach(button => button.classList.toggle('is-active', button === filter));
      applyFilters(system);
      return;
    }

    const toggle = event.target.closest('[data-ticket-toggle]');
    if (toggle) {
      const card = toggle.closest('.mph-ticket-card');
      setTicketOpen(card, !card.classList.contains('is-open'), true);
    }
  });

  document.addEventListener('input', event => {
    if (!event.target.matches('[data-ticket-search]')) return;
    applyFilters(event.target.closest('.mph-ticket-system'));
  });

  document.addEventListener('change', event => {
    if (event.target.matches('[data-ticket-file]')) {
      validateFile(event.target.closest('form'));
    }
    if (event.target.matches('[data-ticket-sort]')) {
      applyFilters(event.target.closest('.mph-ticket-system'));
    }
    if (event.target.matches('[data-ticket-forward]')) {
      const select = one('select[name="assigned_staff"]', event.target.closest('.mph-forward-box'));
      if (select) {
        select.disabled = !event.target.checked;
        select.required = event.target.checked;
        if (event.target.checked) select.focus();
      }
    }
  });

  window.setTimeout(checkTicketAlert, 4000);
  window.setInterval(checkTicketAlert, Math.max(15000, Number(MPH_TICKET_DATA.pollInterval) || 30000));
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) checkTicketAlert();
  });
  window.MPHInitTickets = function (root) {
    const scope = root || document;
    all('.mph-ticket-system', scope).forEach(applyFilters);
  };
  window.MPHInitTickets(document);
})();
