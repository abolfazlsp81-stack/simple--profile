(function(){
  'use strict';

  let config=window.MPH_DATA&&MPH_DATA.headerAccount;
  if(!config)return;

  const personIcon='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 12.25a4.25 4.25 0 1 0 0-8.5 4.25 4.25 0 0 0 0 8.5Zm0 2c-4.54 0-8.25 2.5-8.25 5.57 0 .24.1.47.27.64.17.17.4.27.64.27h14.68a.9.9 0 0 0 .9-.91c0-3.07-3.7-5.57-8.24-5.57Z"/></svg>';
  const headerSelector='#masthead,.site-header,header[role="banner"]';
  const actionSelector='.upstudy-header-right-side,.header-right,.header-actions,.header-tools,.header-icons,.header-controls,.site-header__actions,[class*="header-right"],[class*="header-action"]';
  const knownAccountSelector=[
    '.header-account','.header-user','.user-account','.user-profile','.profile-menu',
    '.header-login','.login-register','.account-icon','.user-icon','.my-account',
    '.tutor-header-profile-menu','.tutor-user-profile','.tutor-dashboard-menu-avatar',
    '.upstudy-user','.upstudy-account','.upstudy-login','.user-menu','.account-menu',
    '[class*="header-account"]','[class*="header-user"]','[class*="user-account"]',
    '[class*="account-icon"]','[class*="login-register"]','[class*="profile-menu"]',
    '[class*="user-profile"]','[class*="login-user"]'
  ];
  let queued=false;

  function headers(){return document&&document.documentElement?Array.from(document.querySelectorAll(headerSelector)):[];}
  function normalize(value){return String(value||'').replace(/[\u200c-\u200f\u202a-\u202e\s]+/g,' ').trim().toLowerCase();}
  function accountTokens(){return (Array.isArray(config.accountTokens)?config.accountTokens:[]).map(normalize).filter(token=>token.length>=4);}
  function isOurs(node){return Boolean(node&&node.closest&&node.closest('.mph-header-account-host,.mph-header-account-link'));}
  function isSearch(node){return Boolean(node&&node.closest&&node.closest('#search,.search-trigger,.header-search,.search-toggle,[class*="search-toggle"]'));
  }
  function matchesKnown(node){
    const selectors=knownAccountSelector.concat(Array.isArray(config.themeAccountSelectors)?config.themeAccountSelectors:[]);
    return selectors.some(selector=>{try{return node.matches(selector)||Boolean(node.closest(selector));}catch(e){return false;}});
  }
  function accountHref(node){
    const link=node.matches&&node.matches('a[href]')?node:node.closest&&node.closest('a[href]');
    if(!link)return false;
    const href=normalize(link.getAttribute('href'));
    return /(?:my[-_]?account|user[-_]?account|profile|dashboard|tutor-dashboard|login|sign[-_]?in)/.test(href);
  }
  function accountText(node){
    const text=normalize(node.textContent);
    if(!text)return false;
    if(/(?:^|\s)mph_[0-9a-z._-]{3,}/i.test(text))return true;
    return accountTokens().some(token=>text.includes(token));
  }
  function accountLabel(node){
    const label=normalize((node.getAttribute&&node.getAttribute('aria-label'))||'')+' '+normalize((node.getAttribute&&node.getAttribute('title'))||'');
    return /حساب|کاربر|ورود|پروفایل|account|profile|user|login/.test(label);
  }
  function accountVisual(node){
    return Boolean(node.querySelector&&node.querySelector('.avatar,[class*="avatar"],img[src*="avatar"],img[alt*="کاربر"],img[alt*="پروفایل"],svg,i,[class*="account"],[class*="user"]'));
  }
  function actionRoots(header){
    const roots=Array.from(header.querySelectorAll(actionSelector));
    return roots.length?roots:[header];
  }
  function compactWrapper(node,root){
    let current=node.nodeType===3?node.parentElement:node;
    let best=current;
    while(current&&current!==root&&current!==document.body){
      if(isOurs(current)||isSearch(current))break;
      if(current.querySelector&&current.querySelector('.mph-header-account-host'))break;
      const text=normalize(current.textContent),rect=current.getBoundingClientRect?current.getBoundingClientRect():{width:0};
      const compact=!rect.width||rect.width<390;
      const semantic=matchesKnown(current)||current.matches('a,button,li,[role="button"],[class*="dropdown"],[class*="menu"]');
      if(compact&&(accountText(current)||accountHref(current)||accountLabel(current))&&(semantic||accountVisual(current)))best=current;
      if(current.parentElement===root)break;
      current=current.parentElement;
    }
    return best;
  }
  function hideNode(node,root){
    if(!node||isOurs(node)||isSearch(node))return;
    const target=compactWrapper(node,root);
    if(!target||target===root||isOurs(target)||isSearch(target)||(target.querySelector&&target.querySelector('.mph-header-account-host')))return;
    target.setAttribute('data-mph-theme-account-hidden','1');
    target.setAttribute('aria-hidden','true');
    target.querySelectorAll('a,button,input,select,[tabindex]').forEach(control=>control.setAttribute('tabindex','-1'));
    if(target.matches('a,button,input,select,[tabindex]'))target.setAttribute('tabindex','-1');
  }
  function removeThemeAccounts(header){
    actionRoots(header).forEach(root=>{
      const candidates=new Set();
      knownAccountSelector.concat(Array.isArray(config.themeAccountSelectors)?config.themeAccountSelectors:[]).forEach(selector=>{
        try{root.querySelectorAll(selector).forEach(node=>candidates.add(node));}catch(e){}
      });
      root.querySelectorAll('a[href],button,[aria-label],[title],span,div,li').forEach(node=>{
        if(isOurs(node)||isSearch(node))return;
        if(accountText(node)||accountHref(node)||accountLabel(node))candidates.add(node);
      });
      candidates.forEach(node=>hideNode(node,root));
    });
  }
  function accountLink(){
    const link=document.createElement('a');
    link.className='mph-header-account-link '+(config.loggedIn?'is-logged-in':'is-guest');
    link.href=config.url||'#';
    link.setAttribute('aria-label',config.label||'حساب کاربری');
    link.setAttribute('data-mph-account-entry','1');
    link.innerHTML='<span class="mph-header-account-icon">'+personIcon+(config.loggedIn&&Number(config.cartCount||0)>0?'<b class="mph-header-cart-count"></b>':'')+'</span>'+(config.greeting?'<span class="mph-header-account-greeting"></span>':'');
    const greeting=link.querySelector('.mph-header-account-greeting');
    if(greeting)greeting.textContent=config.greeting;
    const count=link.querySelector('.mph-header-cart-count');if(count)count.textContent=String(config.cartCount||0);
    return link;
  }
  function findHost(header){
    let host=header.querySelector('.mph-header-account-slot');
    const mobile=window.matchMedia&&window.matchMedia('(max-width: 900px)').matches;
    const burger=header.querySelector('.menu-toggle,.mobile-menu-toggle,.hamburger,.hamburger-menu,.navbar-toggler,.offcanvas-toggle,.meanmenu-reveal,.mobile-nav-toggler,[class*="menu-toggle"],[class*="hamburger"]');
    const burgerBox=burger&&(burger.closest('button,a,.menu-toggle,.mobile-menu-toggle,.hamburger,.navbar-toggler,.offcanvas-toggle,.meanmenu-reveal,.mobile-nav-toggler')||burger);
    const search=header.querySelector('#search,a.search-trigger,.header-search a,.search-toggle,[class*="search-toggle"]');
    const root=(search&&search.closest(actionSelector))||header.querySelector(actionSelector);
    if(!host&&!search&&!root&&!(mobile&&burgerBox))return null;
    const searchBox=search&&(search.closest('.header-quote,.quote-icon,.header-search,.search-toggle,[class*="search-toggle"]')||search);
    if(!host){host=document.createElement('div');host.className='mph-header-account-slot mph-header-account-host';}
    if(mobile&&burgerBox&&burgerBox.parentNode){
      host.classList.add('is-mobile-anchor');
      if(host.nextElementSibling!==burgerBox)burgerBox.parentNode.insertBefore(host,burgerBox);
    }else{
      host.classList.remove('is-mobile-anchor');
      if(searchBox&&searchBox.parentNode&&host.nextElementSibling!==searchBox)searchBox.parentNode.insertBefore(host,searchBox);
      else if(!searchBox&&root&&!root.contains(host))root.appendChild(host);
    }
    return host;
  }
  function install(){
    headers().forEach(header=>{
      removeThemeAccounts(header);
      const host=findHost(header);if(!host)return;
      host.classList.add('mph-header-account-host');
      const current=host.querySelector('.mph-header-account-link');
      const expected=config.loggedIn?'1':'0';
      if(!current||host.dataset.mphLogged!==expected||current.getAttribute('href')!==(config.url||'#')){
        host.dataset.mphLogged=expected;host.replaceChildren(accountLink());
      }else{
        const greeting=current.querySelector('.mph-header-account-greeting');if(greeting)greeting.textContent=config.greeting||'';
      }
      removeThemeAccounts(header);
    });
  }
  function queueInstall(){if(queued)return;queued=true;window.requestAnimationFrame(()=>{queued=false;install();});}

  document.addEventListener('click',event=>{
    const entry=event.target.closest('[data-mph-account-entry]');if(!entry)return;
    event.preventDefault();event.stopPropagation();
    if(config.loggedIn)window.location.assign(config.url||'#');
    else if(typeof window.MPHEnsureAuth==='function')window.MPHEnsureAuth(entry);
    else if(typeof window.MPHOpenAuth==='function')window.MPHOpenAuth(entry);
  },true);

  window.MPHRefreshHeaderAccount=function(next){if(next&&typeof next==='object')config=next;install();};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
  const observer=new MutationObserver(queueInstall);
  function observe(){headers().forEach(header=>{if(header.dataset.mphObserved)return;header.dataset.mphObserved='1';observer.observe(header,{childList:true,subtree:true});});}
  observe();
  if(document.body)new MutationObserver(()=>{observe();queueInstall();}).observe(document.body,{childList:true,subtree:false});
  window.addEventListener('load',()=>{observe();install();},{once:true});
  window.addEventListener('resize',queueInstall,{passive:true});
})();
