<?php
defined('ABSPATH') || exit;

/** Native bot workflows use the same account cart and booking service as the portal. */
final class MPH_Bale_Native {
    public static function call($p) {
        $actor=MPH_Bale_Sync::require_actor($p,false);if(is_wp_error($actor))return $actor;
        if(get_user_meta($actor->ID,MPH_Bale_Sync::BLOCK_META,true))return new WP_Error('forbidden','حساب شما مسدود است.',array('status'=>403));
        $previous=get_current_user_id();wp_set_current_user($actor->ID);
        try {
            $op=sanitize_key($p['op']??'');
            if($op==='therapists')return self::therapists();
            if($op==='slots')return self::slots(absint($p['therapist_id']??0),absint($p['page']??1));
            if($op==='appointment_add')return self::result(MPH_Appointment_Cart::add($actor->ID,absint($p['slot_id']??0),sanitize_key($p['mode']??''),sanitize_textarea_field($p['note']??'')),$actor->ID);
            if($op==='cart_add')return self::result(MPH_Shared_Cart::add($actor->ID,array('product_id'=>absint($p['product_id']??0))),$actor->ID);
            if($op==='cart_remove'){
                $prefix=(string)($p['prefix']??'');$instance=(string)($p['instance_prefix']??'');$saved=MPH_Shared_Cart::read($actor->ID);
                if(strlen($prefix)!==12 || strlen($instance)!==12)return new WP_Error('cart_item','دکمه حذف معتبر نیست.');
                foreach($saved['items'] as $key=>$item)if(hash_equals(substr($key,0,12),$prefix)&&hash_equals(substr($item['instance'],0,12),$instance))return self::result(MPH_Shared_Cart::remove($actor->ID,$key,$item['instance']),$actor->ID);
                return new WP_Error('cart_changed','این انتخاب قبلاً تغییر کرده است؛ سبد را دوباره باز کنید.');
            }
            if($op==='cart')return self::cart($actor->ID);
            if($op==='billing')return MPH_Commerce::billing_from_profile($actor);
            if($op==='orders'){
                if(!function_exists('wc_get_orders'))return array();$rows=array();
                foreach(wc_get_orders(array('customer_id'=>$actor->ID,'limit'=>20,'orderby'=>'date','order'=>'DESC')) as $order)$rows[]=self::order($order);
                return $rows;
            }
            if($op==='file'){
                $id=absint($p['file_id']??0);
                if(!MPH_Private_Files::can_read($id,$actor->ID))return new WP_Error('forbidden','دسترسی پیوست مجاز نیست.',array('status'=>403));
                $path=get_attached_file($id);if(!$path || !is_readable($path) || filesize($path)>10*MB_IN_BYTES)return new WP_Error('file_unavailable','فایل در دسترس نیست.');
                $meta=get_post_meta($id,MPH_Private_Files::META,true);return array('name'=>$meta['name'],'mime'=>get_post_mime_type($id),'content'=>base64_encode(file_get_contents($path)));
            }
            if($op==='checkout') {
                if(!function_exists('WC'))return new WP_Error('woocommerce','فروشگاه در دسترس نیست.');
                if(!WC()->session)WC()->initialize_session();
                WC()->customer=new WC_Customer($actor->ID);WC()->cart=new WC_Cart();MPH_Shared_Cart::sync();
                $posted=$_POST;$_POST=array();
                foreach(array('first_name','last_name','phone','email','postcode','address_1') as $key)$_POST['billing_'.$key]=sanitize_text_field($p['billing'][$key]??'');
                $billing=MPH_Commerce::billing_from_request($actor);$_POST=$posted;
                if(is_wp_error($billing))return $billing;
                $file=absint($p['file_id']??0);$kind=$file?'receipt':'online';
                if($file && (!MPH_Security::get_secret_option('mph_bank_card_number')||!MPH_Security::get_secret_option('mph_bank_card_owner')))return new WP_Error('receipt_config','اطلاعات کارت مجموعه کامل نیست.');
                $upload=$file?function()use($file){return MPH_Private_Files::staged($file,'receipt');}:null;
                $result=MPH_Checkout::submit($actor,$billing,$kind,sanitize_key($p['gateway_id']??''),$upload);
                if(is_wp_error($result))return $result;
                $order=wc_get_order($result['order_id']);$data=self::order($order);
                $url=$result['redirect']??'';
                // Only the bank redirect leaves the bot; receipt and order results stay native.
                if($url && wp_parse_url($url,PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST))$data['payment_url']=$url;
                return $data;
            }
            return new WP_Error('native_operation','این عملیات در دسترس نیست.',array('status'=>404));
        } finally {wp_set_current_user($previous);}
    }
    private static function result($result,$uid){return is_wp_error($result)?$result:self::cart($uid);}
    private static function therapists() {
        $users=get_users(array('role'=>'mph_therapist','number'=>100,'orderby'=>'display_name'));$rows=array();
        foreach($users as $u)$rows[]=array('id'=>$u->ID,'name'=>MPH_Helpers::display_name($u));return $rows;
    }
    private static function slots($therapist,$page) {
        $page=max(1,$page);$posts=get_posts(array('post_type'=>MPH_Appointments::SLOT_TYPE,'post_status'=>'publish','numberposts'=>200,'meta_key'=>'_mph_slot_date','orderby'=>'meta_value','order'=>'ASC','author'=>$therapist,'meta_query'=>array(array('key'=>'_mph_slot_date','value'=>current_time('Y-m-d'),'compare'=>'>='))));
        $rows=array();foreach($posts as $post){foreach(array('phone','online','inperson') as $mode){$valid=MPH_Appointment_Cart::validate($post->ID,$mode);if(is_wp_error($valid))continue;$rows[]=array('id'=>$post->ID,'mode'=>$mode,'label'=>$valid['label'],'date'=>MPH_Helpers::gregorian_to_jalali_date($valid['date']),'time'=>$valid['time'],'price'=>$valid['price']);}}
        usort($rows,function($a,$b){return strcmp($a['date'].$a['time'],$b['date'].$b['time']);});return array('items'=>array_slice($rows,($page-1)*8,8),'page'=>$page,'more'=>count($rows)>$page*8);
    }
    private static function cart($uid) {
        if(function_exists('WC')){if(!WC()->session)WC()->initialize_session();WC()->customer=new WC_Customer($uid);if(!WC()->cart)WC()->cart=new WC_Cart();MPH_Shared_Cart::sync();}
        $saved=MPH_Shared_Cart::read($uid);$rows=array();
        foreach($saved['items'] as $key=>$entry){$product=function_exists('wc_get_product')?wc_get_product($entry['product_id']):false;$price=$entry['kind']==='appointment'?($entry['price']??0):($product?$product->get_price():0);$rows[]=array('key'=>$key,'instance'=>$entry['instance'],'name'=>wp_strip_all_tags($entry['label']??($product?$product->get_name():'انتخاب ناموجود')),'price'=>$price,'kind'=>$entry['kind']);}
        return array('items'=>$rows,'revision'=>$saved['revision'],'total'=>function_exists('WC')&&WC()->cart?(float)WC()->cart->get_total('edit'):0,'currency'=>function_exists('get_woocommerce_currency')?get_woocommerce_currency():'','gateways'=>array_keys(MPH_Checkout::gateways()),'receipt_available'=>(bool)MPH_Security::get_secret_option('mph_bank_card_number'),'card'=>MPH_Security::get_secret_option('mph_bank_card_number'),'card_owner'=>MPH_Security::get_secret_option('mph_bank_card_owner'));
    }
    private static function order($order) {
        $state=MPH_Payment_Result::state($order);
        return array('id'=>$order->get_id(),'number'=>$order->get_order_number(),'total'=>$order->get_total(),'currency'=>$order->get_currency(),'state'=>$state['key'],'message'=>$state['title'].' — '.$state['message'],'reference'=>$order->is_paid()?(string)$order->get_transaction_id():'','events'=>(array)$order->get_meta('_mph_order_events'));
    }
}
