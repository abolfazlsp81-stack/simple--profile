<?php
defined('ABSPATH') || exit;

/** لایه دسترسی داده نوبت‌ها؛ منطق HTTP و رابط کاربری را از ذخیره‌سازی جدا می‌کند. */
final class MPH_Appointment_Repository {
    public static function query($view, $user_id, $limit = 200) {
        $args=array('post_type'=>'mph_appointment','post_status'=>'publish','numberposts'=>max(1,min(500,absint($limit))),'meta_key'=>'_mph_appointment_date','orderby'=>'meta_value','order'=>'DESC');
        if($view==='user')$args['meta_query']=array(array('key'=>'_mph_appointment_patient','value'=>absint($user_id),'compare'=>'='));
        elseif($view==='therapist')$args['meta_query']=array(array('key'=>'_mph_appointment_therapist','value'=>absint($user_id),'compare'=>'='));
        return get_posts($args);
    }

    public static function slot_state($slot_id) {
        return array('reserved'=>absint(get_post_meta(absint($slot_id),'_mph_reserved_appointment',true)),'booked'=>absint(get_post_meta(absint($slot_id),'_mph_slot_booked',true)));
    }

    public static function reserve_slot($slot_id, $appointment_id) {
        return (bool)add_post_meta(absint($slot_id),'_mph_reserved_appointment',absint($appointment_id),true);
    }

    public static function confirm_slot($slot_id, $appointment_id) {
        $state=self::slot_state($slot_id);if($state['booked']&&$state['booked']!==absint($appointment_id))return false;
        if($state['reserved']&&$state['reserved']!==absint($appointment_id))return false;
        delete_post_meta(absint($slot_id),'_mph_reserved_appointment',absint($appointment_id));update_post_meta(absint($slot_id),'_mph_slot_booked',absint($appointment_id));return true;
    }

    public static function release_slot($slot_id, $appointment_id) {
        delete_post_meta(absint($slot_id),'_mph_reserved_appointment',absint($appointment_id));delete_post_meta(absint($slot_id),'_mph_slot_booked',absint($appointment_id));
    }
}
