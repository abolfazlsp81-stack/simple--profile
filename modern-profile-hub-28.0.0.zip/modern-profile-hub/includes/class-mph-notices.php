<?php
defined('ABSPATH') || exit;

/**
 * مرکز اطلاعیه مستقل افزونه.
 *
 * اطلاعیه‌ها در جدول اختصاصی ذخیره می‌شوند تا فیلترهای wp_insert_post قالب،
 * Tutor یا افزونه‌های امنیتی نتوانند انتشار اطلاعیه را متوقف کنند.
 */
final class MPH_Notices {
    const POST_TYPE = 'mph_instructor_notice';
    const DB_VERSION = '2.0.0';
    const LEGACY_MIGRATION_OPTION = 'mph_notice_legacy_migrated_v25';

    public static function init() {
        add_action('init', array(__CLASS__, 'register_type'), 5);
        add_action('init', array(__CLASS__, 'migrate_legacy'), 30);
        add_action('wp_ajax_mph_notice_create', array(__CLASS__, 'ajax_create'));
        add_action('wp_ajax_mph_notice_seen', array(__CLASS__, 'ajax_mark_seen'));
    }

    public static function register_type() {
        register_post_type(self::POST_TYPE, array(
            'label' => 'اطلاعیه‌های قدیمی پورتال',
            'public' => false,
            'show_ui' => false,
            'supports' => array('title', 'editor', 'author'),
        ));
    }

    public static function maybe_install() {
        if (get_option('mph_notice_db_version') === self::DB_VERSION && self::table_ready()) return true;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            author_id bigint(20) unsigned NOT NULL DEFAULT 0,
            title varchar(190) NOT NULL,
            message longtext NOT NULL,
            audience varchar(20) NOT NULL DEFAULT 'all',
            recipient_count bigint(20) unsigned NOT NULL DEFAULT 0,
            legacy_id bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY audience (audience),
            KEY created_at (created_at),
            KEY legacy_id (legacy_id)
        ) {$charset};");
        if (!self::table_ready(true)) return false;
        update_option('mph_notice_db_version', self::DB_VERSION, false);
        return true;
    }

    public static function migrate_legacy() {
        if (get_option(self::LEGACY_MIGRATION_OPTION) === 'yes' || !self::table_ready()) return;
        global $wpdb;
        $migration_ok = true;
        $posts = get_posts(array(
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ));
        foreach ($posts as $post) {
            $exists = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::table() . ' WHERE legacy_id = %d LIMIT 1', $post->ID));
            if ($exists) continue;
            $audience = get_post_meta($post->ID, '_mph_notice_audience', true) ?: 'all';
            if (!isset(self::audiences()[$audience])) $audience = 'manager';
            $inserted = $wpdb->insert(self::table(), array(
                'author_id' => absint($post->post_author),
                'title' => $post->post_title,
                'message' => $post->post_content,
                'audience' => $audience,
                'recipient_count' => absint(get_post_meta($post->ID, '_mph_notice_recipients', true)),
                'legacy_id' => absint($post->ID),
                'created_at' => $post->post_date ?: current_time('mysql'),
            ), array('%d','%s','%s','%s','%d','%d','%s'));
            if (!$inserted) {
                $migration_ok = false;
                break;
            }
        }
        if ($migration_ok) update_option(self::LEGACY_MIGRATION_OPTION, 'yes', false);
    }

    public static function render($mode = '') {
        if (!is_user_logged_in()) return '<div class="mph-empty">ابتدا وارد حساب شوید.</div>';
        if (!self::maybe_install()) return '<section class="mph-section"><div class="mph-empty"><p>جدول اطلاعیه کامل ساخته نشده است؛ مدیر سایت عملیات نگهداری را اجرا کند.</p></div></section>';
        self::migrate_legacy();
        $mode = MPH_Helpers::allowed_mode($mode ?: MPH_Helpers::current_mode());
        $can_publish = $mode === 'manager' && self::can_manage();
        global $wpdb;
        $rows = self::table_exists() ? $wpdb->get_results('SELECT * FROM ' . self::table() . ' ORDER BY created_at DESC, id DESC LIMIT 100') : array();
        $notices = array_values(array_filter((array) $rows, function($notice) use ($mode, $can_publish) {
            return self::is_visible($notice, $mode, $can_publish);
        }));
        $has_unread = self::has_unread($mode, get_current_user_id());
        $seen_id = absint(get_user_meta(get_current_user_id(), self::seen_key($mode), true));

        ob_start(); ?>
        <section class="mph-section mph-notices mph-announcements" data-announcement-feed>
            <div class="mph-section-heading mph-announcement-heading">
                <div><small class="mph-eyebrow">مرکز اطلاع‌رسانی</small><h3>اطلاعیه</h3><p>آخرین اطلاعیه‌های مدیریت از جدیدترین تا قدیمی‌ترین</p></div>
                <div class="mph-announcement-actions">
                    <span class="mph-announcement-count"><b><?php echo esc_html(self::fa_number(count($notices))); ?></b> اطلاعیه</span>
                    <?php if ($can_publish) : ?><button type="button" class="mph-primary mph-notice-create-button" data-toggle-notice-form aria-expanded="false"><span class="dashicons dashicons-plus-alt2"></span> ارسال اطلاعیه</button><?php endif; ?>
                    <form class="mph-announcement-seen-form" data-mph-action="mph_notice_seen"><input type="hidden" name="notice_mode" value="<?php echo esc_attr($mode); ?>"><button type="submit" class="mph-secondary mph-notice-seen-button" <?php disabled(!$has_unread); ?>><span class="dashicons <?php echo $has_unread?'dashicons-visibility':'dashicons-yes-alt'; ?>"></span><?php echo $has_unread?'مشاهده اطلاعیه‌ها':'اطلاعیه‌ها دیده شد'; ?></button><div class="mph-message" aria-live="polite"></div></form>
                    <?php if (!$can_publish) : ?><span class="mph-readonly-badge"><span class="dashicons dashicons-visibility"></span> فقط مشاهده</span><?php endif; ?>
                </div>
            </div>

            <div class="mph-list-toolbar mph-notice-toolbar" data-mph-notice-toolbar>
                <label>مرتب‌سازی
                    <select data-mph-notice-sort>
                        <option value="date-desc">تاریخ: جدیدترین</option>
                        <option value="date-asc">تاریخ: قدیمی‌ترین</option>
                        <option value="id-desc">شماره: نزولی</option>
                        <option value="id-asc">شماره: صعودی</option>
                        <option value="unread-first">خوانده‌نشده ابتدا</option>
                        <option value="read-first">خوانده‌شده ابتدا</option>
                    </select>
                </label>
                <label>وضعیت
                    <select data-mph-notice-filter>
                        <option value="all">همه اطلاعیه‌ها</option>
                        <option value="unread">خوانده‌نشده</option>
                        <option value="read">خوانده‌شده</option>
                    </select>
                </label>
                <span class="mph-toolbar-result" data-mph-notice-result><?php echo esc_html(self::fa_number(count($notices))); ?> مورد</span>
            </div>

            <?php if ($can_publish) : ?>
                <form class="mph-form mph-notice-form mph-announcement-form" data-notice-form data-mph-action="mph_notice_create" hidden>
                    <div class="mph-form-intro"><span class="dashicons dashicons-megaphone"></span><div><b>انتشار اطلاعیه جدید</b><small>اطلاعیه بلافاصله در کارتابل نقش‌های انتخاب‌شده نمایش داده می‌شود.</small></div></div>
                    <div class="mph-field-grid">
                        <label><?php echo MPH_Helpers::required('عنوان اطلاعیه'); ?><input name="notice_title" maxlength="140" required placeholder="عنوان کوتاه و روشن"></label>
                        <label>مخاطبان<select name="notice_audience" required><?php foreach (self::audiences() as $key => $label) : ?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                    </div>
                    <label><?php echo MPH_Helpers::required('متن اطلاعیه'); ?><textarea name="notice_message" maxlength="8000" rows="6" required placeholder="متن کامل اطلاعیه را بنویسید…"></textarea></label>
                    <div class="mph-announcement-form-footer"><small><span class="dashicons dashicons-calendar-alt"></span> تاریخ انتشار: <?php echo esc_html(wp_date('Y/m/d · H:i')); ?></small><button class="mph-primary" type="submit"><span class="dashicons dashicons-megaphone"></span> انتشار اطلاعیه</button></div>
                    <div class="mph-message" aria-live="polite"></div>
                </form>
            <?php endif; ?>

            <div class="mph-notice-list mph-announcement-list">
                <?php if (!$notices) : ?><div class="mph-empty mph-announcement-empty"><span class="dashicons dashicons-megaphone"></span><h4>هنوز اطلاعیه‌ای منتشر نشده است</h4><p>اطلاعیه‌های مدیریت در این قسمت نمایش داده می‌شوند.</p></div><?php endif; ?>
                <?php foreach ($notices as $index => $notice) : $author = get_user_by('id', absint($notice->author_id));$labels = self::audiences();$is_read=absint($notice->id)<=$seen_id; ?>
                    <article class="mph-announcement-item <?php echo $index === 0 ? 'is-latest' : ''; ?> <?php echo $is_read?'is-read':'is-unread'; ?>" data-mph-notice-item data-id="<?php echo absint($notice->id); ?>" data-date="<?php echo esc_attr(strtotime($notice->created_at)); ?>" data-read="<?php echo $is_read?'1':'0'; ?>">
                        <div class="mph-announcement-icon"><span class="dashicons dashicons-megaphone"></span></div>
                        <div class="mph-announcement-body">
                            <header><div><h4><?php echo esc_html($notice->title); ?></h4><?php if ($index === 0) : ?><span class="mph-latest-badge">جدیدترین</span><?php endif; ?></div><time datetime="<?php echo esc_attr(mysql2date('c', $notice->created_at)); ?>"><?php echo esc_html(mysql2date('Y/m/d · H:i', $notice->created_at)); ?></time></header>
                            <div class="mph-announcement-copy"><?php echo wpautop(esc_html($notice->message)); ?></div>
                            <footer><span class="dashicons dashicons-admin-users"></span><span><?php echo esc_html($labels[$notice->audience] ?? 'همه مخاطبان'); ?></span><i></i><span>شماره <?php echo esc_html(self::fa_number($notice->id)); ?></span><i></i><span>منتشرکننده: <?php echo esc_html($author ? MPH_Helpers::display_name($author) : 'مدیریت سایت'); ?></span></footer>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
        <?php return ob_get_clean();
    }

    public static function ajax_create() {
        MPH_Helpers::verify_ajax();
        nocache_headers();
        if (MPH_Helpers::requested_mode() !== 'manager' || !self::can_manage()) wp_send_json_error(array('message' => 'فقط در نقش مدیر مجموعه اجازه انتشار اطلاعیه دارید.'), 403);
        if (!self::maybe_install()) wp_send_json_error(array('message' => 'جدول اطلاعیه ساخته نشد؛ دسترسی ساخت جدول پایگاه‌داده را بررسی کنید.'), 503);
        $title = MPH_Helpers::posted('notice_title');
        $message = MPH_Helpers::posted('notice_message', 'textarea');
        $audience = MPH_Helpers::posted('notice_audience', 'key') ?: 'all';
        if (!$title || !$message) wp_send_json_error(array('message' => 'عنوان و متن اطلاعیه را کامل کنید.'));
        if (!isset(self::audiences()[$audience])) wp_send_json_error(array('message' => 'گروه مخاطبان معتبر نیست.'));
        if (!self::table_exists()) wp_send_json_error(array('message' => 'جدول اطلاعیه ساخته نشد؛ یک‌بار افزونه را غیرفعال و فعال کنید یا دسترسی ساخت جدول پایگاه‌داده را بررسی کنید.'));
        global $wpdb;
        $ok = $wpdb->insert(self::table(), array(
            'author_id' => get_current_user_id(),
            'title' => $title,
            'message' => $message,
            'audience' => $audience,
            'recipient_count' => self::audience_count($audience),
            'legacy_id' => 0,
            'created_at' => current_time('mysql'),
        ), array('%d','%s','%s','%s','%d','%d','%s'));
        if ($ok === false) wp_send_json_error(array('message' => 'ذخیره اطلاعیه انجام نشد. دسترسی نوشتن جدول اختصاصی پایگاه‌داده را بررسی کنید.'));
        wp_send_json_success(array('message' => 'اطلاعیه منتشر شد و اکنون در کارتابل مخاطبان قابل مشاهده است.','html' => self::render('manager')));
    }

    public static function ajax_mark_seen() {
        MPH_Helpers::verify_ajax();
        if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد حساب شوید.'),401);
        $mode=MPH_Helpers::allowed_mode(MPH_Helpers::posted('notice_mode','key')?:MPH_Helpers::requested_mode());
        self::mark_seen($mode,get_current_user_id());
        wp_send_json_success(array('message'=>'اطلاعیه‌ها مشاهده‌شده ثبت شدند.','html'=>self::render($mode),'clearAnnouncementAlert'=>true));
    }

    public static function has_unread($mode,$user_id=0) {
        $user_id=absint($user_id?:get_current_user_id());if(!$user_id)return false;$latest=self::latest_visible_id($mode);if(!$latest)return false;$seen=absint(get_user_meta($user_id,self::seen_key($mode),true));return$latest>$seen;
    }

    public static function mark_seen($mode,$user_id=0) {
        $user_id=absint($user_id?:get_current_user_id());if(!$user_id)return;$latest=self::latest_visible_id($mode);if($latest>absint(get_user_meta($user_id,self::seen_key($mode),true)))update_user_meta($user_id,self::seen_key($mode),$latest);
    }

    public static function notification_payload($mode,$user_id=0) {
        $user_id=absint($user_id?:get_current_user_id());$mode=MPH_Helpers::allowed_mode($mode);if(!$user_id||!self::has_unread($mode,$user_id)||!self::table_ready())return array();global$wpdb;
        if($mode==='manager')$row=$wpdb->get_row('SELECT * FROM '.self::table().' ORDER BY id DESC LIMIT 1');else$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE audience=%s OR audience=%s ORDER BY id DESC LIMIT 1','all',$mode));if(!$row)return array();$stamp=strtotime($row->created_at)?:time();return array('id'=>'notice-'.$row->id,'type'=>'notice','title'=>'اطلاعیه: '.$row->title,'body'=>wp_trim_words(wp_strip_all_tags($row->message),18,'…'),'panel'=>'announcements','timestamp'=>$stamp,'icon'=>'dashicons-megaphone');
    }

    private static function latest_visible_id($mode) {
        if(!self::maybe_install())return 0;$mode=MPH_Helpers::allowed_mode($mode);global$wpdb;if($mode==='manager')return absint($wpdb->get_var('SELECT MAX(id) FROM '.self::table()));return absint($wpdb->get_var($wpdb->prepare('SELECT MAX(id) FROM '.self::table().' WHERE audience = %s OR audience = %s','all',$mode)));
    }

    private static function seen_key($mode){return'mph_notice_seen_'.sanitize_key(MPH_Helpers::allowed_mode($mode));}

    private static function table() {global $wpdb;return $wpdb->prefix . 'mph_announcements';}
    private static function table_exists() {global $wpdb;$table=self::table();return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table;}
    public static function table_ready($refresh=false) {static$ready=null;if(!$refresh&&$ready!==null)return$ready;if(!self::table_exists())return$ready=false;global$wpdb;$columns=(array)$wpdb->get_col('SHOW COLUMNS FROM '.self::table(),0);return$ready=!array_diff(array('id','author_id','title','message','audience','recipient_count','legacy_id','created_at'),$columns);}
    private static function audiences() {return array('all'=>'همه کاربران، مدرسین، درمانگران و مدیران','user'=>'فقط کاربران','instructor'=>'فقط مدرسین','therapist'=>'فقط درمانگران','manager'=>'فقط مدیران');}
    private static function is_visible($notice, $mode, $can_publish) {if ($can_publish) return true;return empty($notice->audience) || $notice->audience === 'all' || $notice->audience === $mode;}
    private static function audience_count($audience) {if($audience==='all')return absint(count_users()['total_users']??0);if($audience==='manager')return count(get_users(array('role__in'=>array('administrator','mph_manager'),'fields'=>'ID')));if($audience==='instructor')return count(get_users(array('role__in'=>array('mph_instructor','tutor_instructor'),'fields'=>'ID')));if($audience==='therapist')return count(get_users(array('role'=>'mph_therapist','fields'=>'ID')));$users=get_users(array('fields'=>'all'));$count=0;foreach($users as$user)if(!array_intersect((array)$user->roles,array('administrator','mph_manager','mph_instructor','tutor_instructor','mph_therapist')))$count++;return$count;}
    private static function can_manage() {return is_user_logged_in()&&(MPH_Helpers::has_role('mph_manager')||current_user_can('mph_manage_portal')||current_user_can('manage_options'));}
    private static function fa_number($value) {return strtr((string)absint($value),array('0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹'));}
}
