<?php
defined('ABSPATH') || exit;

final class MPH_Payment_Result {
    public static function init() {
        add_action('template_redirect',array(__CLASS__,'route'),2);
        add_action('wp_ajax_mph_payment_recheck',array(__CLASS__,'recheck'));
        add_action('wp_ajax_mph_payment_retry',array(__CLASS__,'retry'));
        add_action('woocommerce_order_status_changed',array(__CLASS__,'status_changed'),40,4);
    }
    public static function url($order) {return add_query_arg(array('mph_payment_result'=>$order->get_id()),MPH_Helpers::account_page_url());}
    public static function can_view($order) {return $order && is_user_logged_in() && ((int)$order->get_customer_id()===get_current_user_id() || current_user_can('manage_options') || current_user_can('mph_manage_portal'));}

    public static function state($order) {
        if ($order->get_meta('_mph_payment_review')) return array('key'=>'review','title'=>'پرداخت نیازمند بررسی مدیر است','message'=>'وجه دریافت شده، اما مبلغ سفارش تغییر کرده است. دوباره پرداخت نکنید و با پشتیبانی تماس بگیرید.','icon'=>'warning');
        if ($order->is_paid()) return array('key'=>'success','title'=>'پرداخت موفق بود','message'=>'پرداخت این سفارش تأیید شده است.','icon'=>'yes-alt');
        if ($order->get_meta(MPH_Commerce::RECEIPT_STATUS)==='pending') return array('key'=>'pending','title'=>'فیش در انتظار بررسی است','message'=>'فیش ثبت شده است؛ تأیید نهایی پس از بررسی مدیر انجام می‌شود.','icon'=>'clock');
        $rows=MPH_Payment_Attempts::rows($order);
        foreach ($rows as $row) if (in_array($row['state']??'',array('unknown','verifying'),true)) return array('key'=>'pending','title'=>'نتیجه پرداخت در حال بررسی است','message'=>'نتیجه قطعی دریافت نشده است. ابتدا وضعیت را بررسی کنید و دوباره پرداخت نکنید.','icon'=>'clock');
        $last=end($rows);
        if ($last && in_array($last['state']??'',array('failed','cancelled'),true)) return array('key'=>'failed','title'=>'پرداخت کامل نشد','message'=>'پرداخت این تلاش تأیید نشده است؛ انتخاب‌های شما در سبد محفوظ‌اند.','icon'=>'dismiss');
        if ($order->has_status(array('failed','cancelled','refunded'))) return array('key'=>'failed','title'=>'این سفارش پرداخت فعال ندارد','message'=>'وضعیت سفارش: '.wc_get_order_status_name($order->get_status()),'icon'=>'dismiss');
        return array('key'=>'pending','title'=>'در انتظار پرداخت','message'=>'سفارش ثبت شده است؛ پس از پرداخت، نتیجه تأیید در همین صفحه نمایش داده می‌شود.','icon'=>'clock');
    }

    public static function render($order) {
        if (!self::can_view($order)) return '<div class="mph-empty">برای دیدن نتیجه، وارد حساب صاحب سفارش شوید.</div>';
        $state=self::state($order);$ref=(string)$order->get_transaction_id();
        ob_start(); ?>
        <section class="mph-section mph-payment-result is-<?php echo esc_attr($state['key']); ?>">
            <span class="mph-result-icon dashicons dashicons-<?php echo esc_attr($state['icon']); ?>"></span>
            <h2><?php echo esc_html($state['title']); ?></h2><p><?php echo esc_html($state['message']); ?></p>
            <dl class="mph-result-details"><div><dt>شماره سفارش</dt><dd><?php echo esc_html($order->get_order_number()); ?></dd></div><div><dt>مبلغ</dt><dd><?php echo wp_kses_post($order->get_formatted_order_total()); ?></dd></div><div><dt>کد پیگیری بانکی</dt><dd dir="ltr"><?php echo esc_html($order->is_paid()&&$ref?$ref:'—'); ?></dd></div></dl>
            <?php if($order->get_meta('_mph_appointment_conflicts')): ?><p class="mph-message is-error">وجه دریافت شده است، اما ظرفیت نوبت نیازمند بررسی مدیر است؛ برای تعیین تکلیف با پشتیبانی تماس بگیرید.</p><?php endif; ?>
            <?php if(!$order->is_paid()&&$order->get_payment_method()==='mph_zarinpal'&&MPH_Payment_Attempts::rows($order)): ?><form data-mph-action="mph_payment_recheck"><input type="hidden" name="order_id" value="<?php echo $order->get_id(); ?>"><button class="mph-primary" type="submit">بررسی وضعیت پرداخت</button><div class="mph-message"></div></form><?php endif; ?>
            <?php if(self::can_retry($order)): ?><form data-mph-action="mph_payment_retry"><input type="hidden" name="order_id" value="<?php echo $order->get_id(); ?>"><button class="mph-secondary" type="submit">ادامه پرداخت همین سفارش</button><div class="mph-message"></div></form><?php endif; ?>
            <div class="mph-result-actions"><a class="mph-primary" href="<?php echo esc_url(add_query_arg(array('mph_open'=>'orders','order_id'=>$order->get_id()),MPH_Helpers::account_page_url())); ?>">سوابق خرید و صورتحساب</a><a class="mph-secondary" href="<?php echo esc_url(MPH_Commerce::cart_redirect()); ?>">بازگشت به سبد خرید</a></div>
            <?php echo self::timeline($order); ?>
        </section><?php return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    public static function timeline($order) {
        if (!self::can_view($order)) return '';
        $rows=(array)$order->get_meta('_mph_order_events');
        if (!$rows) return '';
        $html='<section class="mph-order-timeline"><h3>مسیر سفارش</h3><ol>';
        foreach ($rows as $row) if (isset($row['time'],$row['message'])) $html.='<li><time>'.esc_html(wp_date('Y/m/d H:i',(int)$row['time'])).'</time><span>'.esc_html($row['message']).'</span></li>';
        return $html.'</ol></section>';
    }

    public static function route() {
        if (empty($_GET['mph_payment_result'])) return;
        nocache_headers();header('X-Robots-Tag: noindex, nofollow',true);header('Referrer-Policy: same-origin',true);
        $order=function_exists('wc_get_order')?wc_get_order(absint($_GET['mph_payment_result'])):false;
        MPH_Dashboard::enqueue_client_assets();get_header();
        echo '<main class="mph-root mph-inline-mode mph-result-page" dir="rtl">';
        if (!is_user_logged_in()) echo '<div class="mph-inline-auth"><p>برای مشاهده نتیجه پرداخت وارد حساب خود شوید.</p>'.MPH_Auth::render().'</div>';
        elseif (!self::can_view($order)) echo '<div class="mph-empty">این سفارش برای حساب شما قابل مشاهده نیست.</div>';
        else echo self::render($order);
        echo '</main>';wp_footer();echo '</body></html>';exit;
    }

    private static function requested_order() {
        MPH_Helpers::verify_ajax();$order=wc_get_order(absint($_POST['order_id']??0));
        if (!self::can_view($order)) wp_send_json_error(array('message'=>'سفارش برای این حساب قابل مشاهده نیست.'),403);
        if (!MPH_Security::allow('payment_check',6,MINUTE_IN_SECONDS,'u:'.get_current_user_id())) wp_send_json_error(array('message'=>'کمی بعد دوباره بررسی کنید.'),429);
        return $order;
    }
    public static function recheck() {
        $order=self::requested_order();
        if (!$order->is_paid() && $order->get_payment_method()==='mph_zarinpal') MPH_Payment_Attempts::reconcile($order);
        wp_send_json_success(array('message'=>'آخرین وضعیت سفارش بررسی شد.','redirect'=>self::url($order)));
    }
    public static function can_retry($order) {
        if (!$order || (int)$order->get_customer_id()!==get_current_user_id() || $order->is_paid() || !$order->needs_payment() || $order->get_meta('_mph_payment_review')) return false;
        foreach(MPH_Payment_Attempts::rows($order) as $row) if(in_array($row['state']??'',array('unknown','verifying','review'),true)) return false;
        return true;
    }
    public static function retry() {
        $order=self::requested_order();
        if (!self::can_retry($order)) wp_send_json_error(array('message'=>'این سفارش قابل پرداخت دوباره نیست؛ وضعیت پرداخت را بررسی کنید.'),409);
        $holds=MPH_Appointment_Cart::ensure_holds($order);
        if (is_wp_error($holds)) wp_send_json_error(array('message'=>$holds->get_error_message()),409);
        $result=MPH_Checkout::pay($order,$order->get_payment_method());
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()),409);
        wp_send_json_success($result);
    }
    public static function status_changed($id,$from,$to,$order) {
        if (!$order || !$order->get_meta('_mph_cart_snapshot')) return;
        MPH_Payment_Attempts::event($order,'status_'.$to,'وضعیت سفارش: '.wc_get_order_status_name($to));
    }
}
