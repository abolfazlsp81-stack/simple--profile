<?php
defined('ABSPATH') || exit;

/** Appointment selections stay in the cart; finite slot holds start at checkout. */
final class MPH_Appointment_Cart {
    public static function validate($slot_id,$mode,$own_appointment=0) {
        return MPH_Appointments::cart_slot($slot_id,$mode,$own_appointment);
    }

    public static function add($user_id,$slot_id,$mode,$note='') {
        $valid=self::validate($slot_id,$mode);
        if (is_wp_error($valid)) return $valid;
        return MPH_Shared_Cart::add($user_id,array('kind'=>'appointment','slot_id'=>$slot_id,'appointment_mode'=>$mode,'note'=>$note));
    }

    public static function reserve($entry,$order,$cart_key) {
        $slot_id=absint($entry['slot_id']);
        // Expired holds are released before the new slot lease; validate again under it.
        $probe=self::validate($slot_id,$entry['appointment_mode']);
        if(is_wp_error($probe))return $probe;
        $lease=MPH_Appointment_Lock::acquire($slot_id,90);
        if (!$lease) return new WP_Error('mph_slot_busy','این ساعت در حال بررسی است؛ چند لحظه بعد دوباره تلاش کنید.');
        try {
            $valid=self::validate($slot_id,$entry['appointment_mode']);
            if (is_wp_error($valid)) return $valid;
            if ((string)$valid['price']!==(string)$entry['price']) return new WP_Error('mph_price_changed','مبلغ نوبت تغییر کرده است؛ انتخاب قبلی در سبد محفوظ است. مبلغ جدید را در تقویم بررسی و نوبت را دوباره اضافه کنید.');
            $id=wp_insert_post(array('post_type'=>MPH_Appointments::APPOINTMENT_TYPE,'post_status'=>'publish','post_author'=>$order->get_customer_id(),'post_title'=>$valid['label']),true);
            if (is_wp_error($id)) return $id;
            if (!MPH_Appointment_Repository::reserve_slot($slot_id,$id)) {wp_delete_post($id,true);return new WP_Error('mph_slot_full','این ساعت لحظاتی پیش رزرو شد؛ انتخاب شما در سبد محفوظ است.');}
            $fields=array('therapist'=>$valid['therapist_id'],'patient'=>$order->get_customer_id(),'slot'=>$slot_id,'date'=>$valid['date'],'time'=>$valid['time'],'end'=>$valid['end'],'duration'=>$valid['duration'],'mode'=>$valid['mode'],'status'=>'awaiting_payment','price'=>$valid['price'],'tracking'=>strtoupper(wp_generate_password(12,false,false)),'note'=>MPH_Security::decrypt($entry['note']??''),'order'=>$order->get_id(),'hold_until'=>time()+MPH_Appointments::HOLD_MINUTES*MINUTE_IN_SECONDS);
            foreach ($fields as $key=>$value) update_post_meta($id,'_mph_appointment_'.$key,$value);
            update_post_meta($id,'_mph_cart_booking',$cart_key);
            wp_schedule_single_event($fields['hold_until'],'mph_release_appointment_hold',array($id));
            MPH_Security::audit('appointment_reserved','appointment='.$id.';order='.$order->get_id(),$order->get_customer_id());
            return $id;
        } finally {MPH_Appointment_Lock::release($slot_id,$lease);}
    }

    public static function order_ids($order) {
        $ids=array_map('absint',(array)$order->get_meta('_mph_appointment_ids'));
        $ids[]=absint($order->get_meta(MPH_Appointments::ORDER_META));
        return array_values(array_unique(array_filter($ids)));
    }

    public static function ensure_holds($order) {
        foreach (self::order_ids($order) as $id) {
            $slot=absint(get_post_meta($id,'_mph_appointment_slot',true));
            $lease=MPH_Appointment_Lock::acquire($slot,90);
            if (!$lease) return new WP_Error('mph_slot_busy','ظرفیت نوبت در حال بررسی است.');
            try {
                $status=get_post_meta($id,'_mph_appointment_status',true);
                if ($status==='cancelled') return new WP_Error('mph_slot_cancelled','این نوبت لغو شده است؛ انتخاب زمان را در سبد اصلاح کنید.');
                $valid=self::validate($slot,get_post_meta($id,'_mph_appointment_mode',true),$id);
                if (is_wp_error($valid)) return $valid;
                if ((float)$valid['price']!==(float)get_post_meta($id,'_mph_appointment_price',true)) return new WP_Error('mph_price_changed','مبلغ نوبت تغییر کرده است؛ انتخاب را در سبد دوباره بررسی کنید.');
                $state=MPH_Appointment_Repository::slot_state($slot);
                if (!$state['reserved'] && !MPH_Appointment_Repository::reserve_slot($slot,$id)) return new WP_Error('mph_slot_full','زمان انتخابی اکنون در دسترس نیست.');
                $until=time()+MPH_Appointments::HOLD_MINUTES*MINUTE_IN_SECONDS;
                update_post_meta($id,'_mph_appointment_hold_until',$until);
                update_post_meta($id,'_mph_appointment_status',$order->get_meta(MPH_Commerce::RECEIPT_STATUS)==='pending'?'pending_receipt':'awaiting_payment');
                wp_schedule_single_event($until,'mph_release_appointment_hold',array($id));
            } finally {MPH_Appointment_Lock::release($slot,$lease);}
        }
        return true;
    }

    public static function expire($id) {
        $status=get_post_meta($id,'_mph_appointment_status',true);
        if (!in_array($status,array('awaiting_payment','pending_receipt'),true) || (int)get_post_meta($id,'_mph_appointment_hold_until',true)>time()) return;
        $order=wc_get_order(absint(get_post_meta($id,'_mph_appointment_order',true)));
        if ($order && $order->is_paid()) {MPH_Appointments::confirm_paid_order($order->get_id());return;}
        $slot=absint(get_post_meta($id,'_mph_appointment_slot',true));$lease=MPH_Appointment_Lock::acquire($slot,30);
        if (!$lease) {wp_schedule_single_event(time()+30,'mph_release_appointment_hold',array(absint($id)));return;}
        try {
            // Re-read after the lease: a checkout may have extended this hold.
            wp_cache_delete($id,'post_meta');
            if ((int)get_post_meta($id,'_mph_appointment_hold_until',true)>time()) return;
            MPH_Appointment_Repository::release_slot($slot,$id);
            update_post_meta($id,'_mph_appointment_status','expired');
            if ($order) MPH_Payment_Attempts::event($order,'appointment_hold_expired','مهلت نگهداری ساعت تمام شد؛ انتخاب نوبت در سبد محفوظ است و ظرفیت باید دوباره بررسی شود.');
        } finally {MPH_Appointment_Lock::release($slot,$lease);}
    }

    public static function abandon_order($order) {
        foreach(self::order_ids($order) as $id) {
            MPH_Appointment_Repository::release_slot(get_post_meta($id,'_mph_appointment_slot',true),$id);
            update_post_meta($id,'_mph_appointment_status','expired');
        }
    }
}
