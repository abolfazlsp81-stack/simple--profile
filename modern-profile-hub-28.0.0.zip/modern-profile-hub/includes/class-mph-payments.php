<?php
defined('ABSPATH') || exit;

final class MPH_Payments {
    const OPTION = 'mph_online_payment_settings';

    public static function init() {
        add_action('plugins_loaded', array(__CLASS__, 'bootstrap_gateways'), 30);
        add_action('admin_init', array(__CLASS__, 'save_admin'));
        add_action('init', array(__CLASS__, 'schedule_reconciliation'));
        add_action('mph_reconcile_pending_payments', array(__CLASS__, 'reconcile_pending_orders'));
    }

    public static function bootstrap_gateways() {
        if (!class_exists('WC_Payment_Gateway')) return;
        require_once MPH_DIR . 'includes/class-mph-payment-gateways.php';
        add_filter('woocommerce_payment_gateways', array(__CLASS__, 'register_gateways'));
    }

    public static function register_gateways($gateways) {
        $gateways[] = 'MPH_Gateway_Zarinpal';
        $gateways[] = 'MPH_Gateway_IDPay';
        return $gateways;
    }

    public static function settings() {
        $settings=wp_parse_args(get_option(self::OPTION, array()), array(
            'zarinpal_merchant' => '', 'zarinpal_sandbox' => 0,
            'idpay_api_key' => '', 'idpay_sandbox' => 0,
        ));
        $settings['zarinpal_merchant']=MPH_Security::decrypt($settings['zarinpal_merchant']);
        $settings['idpay_api_key']=MPH_Security::decrypt($settings['idpay_api_key']);
        return $settings;
    }

    public static function get($key, $default = '') {
        $settings = self::settings();
        return $settings[$key] ?? $default;
    }

    public static function enabled_names() {
        $names = array();
        if (trim((string) self::get('zarinpal_merchant')) !== '') $names[] = 'زرین‌پال';
        if (trim((string) self::get('idpay_api_key')) !== '') $names[] = 'IDPay';
        return $names;
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) wp_die('دسترسی ندارید.');
        $settings = self::settings();
        settings_errors('mph-payments'); ?>
        <div class="wrap mph-admin mph-payment-admin" dir="rtl">
            <header class="mph-admin-head"><span class="dashicons dashicons-money-alt"></span><div><h1>روش پرداخت آنلاین</h1><p>کلید درگاه را وارد کنید؛ درگاه به‌صورت خودکار در تسویه‌حساب WooCommerce فعال می‌شود.</p></div></header>
            <div class="mph-payment-security-note"><span class="dashicons dashicons-shield-alt"></span><div><b>پرداخت امن و متصل به WooCommerce</b><p>مبلغ از خود سفارش خوانده می‌شود، شناسه تراکنش داخل سفارش ذخیره و پرداخت فقط پس از Verify درگاه تکمیل خواهد شد.</p></div></div>
            <form method="post" class="mph-admin-box mph-gateway-settings"><?php wp_nonce_field('mph_payment_admin','mph_payment_nonce'); ?>
                <div class="mph-gateway-grid">
                    <section class="mph-gateway-card <?php echo $settings['zarinpal_merchant']?'is-ready':''; ?>">
                        <header><span class="mph-gateway-logo">ZP</span><div><h2>زرین‌پال</h2><small><?php echo $settings['zarinpal_merchant']?'کلید ثبت شده و آماده نمایش':'Merchant ID وارد نشده'; ?></small></div><i></i></header>
                        <label>Merchant ID<input type="password" name="zarinpal_merchant" value="<?php echo esc_attr($settings['zarinpal_merchant']); ?>" autocomplete="new-password" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" dir="ltr"></label>
                        <label class="mph-switch-row"><span><b>حالت آزمایشی</b><small>پرداخت واقعی انجام نمی‌شود.</small></span><input type="checkbox" name="zarinpal_sandbox" value="1" <?php checked(!empty($settings['zarinpal_sandbox'])); ?>></label>
                        <a href="https://www.zarinpal.com/docs/paymentGateway/connectToGateway" target="_blank" rel="noopener">مستندات رسمی زرین‌پال ↗</a>
                    </section>
                    <section class="mph-gateway-card <?php echo $settings['idpay_api_key']?'is-ready':''; ?>">
                        <header><span class="mph-gateway-logo is-idpay">ID</span><div><h2>IDPay</h2><small><?php echo $settings['idpay_api_key']?'کلید ثبت شده و آماده نمایش':'API Key وارد نشده'; ?></small></div><i></i></header>
                        <label>API Key<input type="password" name="idpay_api_key" value="<?php echo esc_attr($settings['idpay_api_key']); ?>" autocomplete="new-password" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" dir="ltr"></label>
                        <label class="mph-switch-row"><span><b>حالت آزمایشگاه</b><small>هدر X-SANDBOX فعال می‌شود.</small></span><input type="checkbox" name="idpay_sandbox" value="1" <?php checked(!empty($settings['idpay_sandbox'])); ?>></label>
                        <a href="https://idpay.ir/web-service/v1.1/" target="_blank" rel="noopener">مستندات رسمی IDPay ↗</a>
                    </section>
                </div>
                <div class="mph-direct-bank-note"><span class="dashicons dashicons-bank"></span><div><b>درگاه مستقیم بانکی</b><p>اتصال مستقیم بانک با یک API Key انجام نمی‌شود و به اطلاعات قرارداد مانند Terminal ID و حساب پذیرنده نیاز دارد. پس از دریافت قرارداد بانک، می‌توان ماژول همان بانک را جداگانه اضافه کرد.</p></div></div>
                <button class="button button-primary button-hero" name="mph_save_payments" value="1">ذخیره روش‌های پرداخت</button>
            </form>
        </div><?php
    }

    public static function save_admin() {
        if (!isset($_POST['mph_save_payments'])) return;
        if (!current_user_can('manage_options') || empty($_POST['mph_payment_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mph_payment_nonce'])), 'mph_payment_admin')) return;
        $result=self::persist(wp_unslash($_POST));
        add_settings_error('mph-payments',is_wp_error($result)?'error':'saved',is_wp_error($result)?$result->get_error_message():'تنظیمات ذخیره و بازخوانی شد.',is_wp_error($result)?'error':'success');
    }

    public static function persist($input) {
        $old=self::settings();$merchant=trim(sanitize_text_field($input['zarinpal_merchant']??''));$idpay=trim(sanitize_text_field($input['idpay_api_key']??''));
        if($merchant==='')$merchant=$old['zarinpal_merchant'];if($idpay==='')$idpay=$old['idpay_api_key'];
        if($merchant!==''&&!MPH_Payment_Attempts::valid_merchant($merchant))return new WP_Error('mph_merchant','فرمت مرچنت زرین‌پال معتبر نیست؛ تنظیمات قبلی حفظ شد.');
        $new=array('zarinpal_merchant'=>MPH_Security::encrypt($merchant),'idpay_api_key'=>MPH_Security::encrypt($idpay),'zarinpal_sandbox'=>empty($input['zarinpal_sandbox'])?0:1,'idpay_sandbox'=>empty($input['idpay_sandbox'])?0:1);
        if(($merchant!==''&&$new['zarinpal_merchant']===$merchant)||($idpay!==''&&$new['idpay_api_key']===$idpay))return new WP_Error('mph_crypto','ذخیره امن کلید روی این میزبان آماده نیست.');
        $previous=get_option(self::OPTION,array());update_option(self::OPTION,$new,false);
        if(get_option(self::OPTION)!==$new){update_option(self::OPTION,$previous,false);return new WP_Error('mph_storage','ذخیره تنظیمات کامل نشد؛ دوباره تلاش کنید.');}
        MPH_Helpers::audit('payment_settings_saved','gateway_settings_updated');return true;
    }

    public static function amount($order, $target) {
        $currency = strtoupper((string) $order->get_currency());
        $value = (float) $order->get_total();
        $is_rial = in_array($currency, array('IRR','RIAL'), true);
        $is_toman = in_array($currency, array('IRT','TOMAN','TMN'), true);
        if (!$is_rial && !$is_toman) return new WP_Error('mph_currency', 'واحد پول فروشگاه باید ریال یا تومان باشد.');
        if ($target === 'IRR') return max(1, (int) round($is_rial ? $value : $value * 10));
        if ($target === 'IRT') return max(1, (int) round($is_toman ? $value : $value / 10));
        return new WP_Error('mph_currency', 'واحد مقصد درگاه معتبر نیست.');
    }

    public static function post_json($url, $payload, $headers = array()) {
        $response = wp_remote_post($url, array(
            'timeout' => 25, 'redirection' => 0, 'sslverify' => true,
            'headers' => array_merge(array('Accept'=>'application/json','Content-Type'=>'application/json'), $headers),
            'body' => wp_json_encode($payload),
            'user-agent' => 'Modern-Profile-Hub/' . MPH_VERSION . '; ' . home_url('/'),
        ));
        if (is_wp_error($response)) return $response;
        $code = absint(wp_remote_retrieve_response_code($response));
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body)) return new WP_Error('mph_gateway_response', 'پاسخ نامعتبر از درگاه دریافت شد.');
        $body['_http_code'] = $code;
        return $body;
    }

    public static function error_message($response, $fallback = 'ارتباط با درگاه انجام نشد.') {
        if (is_wp_error($response)) return $response->get_error_message();
        foreach (array('error_message','message') as $key) if (!empty($response[$key]) && is_scalar($response[$key])) return sanitize_text_field((string) $response[$key]);
        if (!empty($response['errors']['message'])) return sanitize_text_field((string) $response['errors']['message']);
        return $fallback;
    }

    /** زمان‌بندی کنترل سمت سرور سفارش‌هایی که بازگشت مرورگرشان کامل نشده است. */
    public static function schedule_reconciliation() {
        if (!wp_next_scheduled('mph_reconcile_pending_payments')) {
            wp_schedule_event(time() + 5 * MINUTE_IN_SECONDS, 'hourly', 'mph_reconcile_pending_payments');
        }
    }

    /**
     * تطبیق امن وضعیت پرداخت با سرور درگاه. این تابع idempotent است و سفارش پرداخت‌شده را دوباره تغییر نمی‌دهد.
     *
     * @return array{checked:int,paid:int,failed:int,skipped:int}
     */
    public static function reconcile_pending_orders($limit = 20, $force = false) {
        $result = array('checked'=>0,'paid'=>0,'failed'=>0,'skipped'=>0);
        if (!function_exists('wc_get_orders')) return $result;
        $orders = wc_get_orders(array(
            'limit' => max(1, min(100, absint($limit))),
            'status' => array('pending','on-hold'),
            'orderby' => 'date',
            'order' => 'DESC',
            'date_created' => '>' . (time() - 2 * DAY_IN_SECONDS),
        ));
        foreach ($orders as $order) {
            if (!$order instanceof WC_Order || $order->is_paid()) {$result['skipped']++;continue;}
            $method = (string) $order->get_payment_method();
            $token = (string) $order->get_meta('_mph_gateway_token');
            if (!$token || !in_array($method, array('mph_zarinpal','mph_idpay'), true)) {$result['skipped']++;continue;}
            $last = absint($order->get_meta('_mph_last_reconcile'));
            if (!$force && $last && time() - $last < 10 * MINUTE_IN_SECONDS) {$result['skipped']++;continue;}
            $order->update_meta_data('_mph_last_reconcile', time());
            $order->save();
            $result['checked']++;
            $verified = self::verify_order_server_side($order);
            if (is_wp_error($verified)) {
                $result['failed']++;
                MPH_Security::audit('payment_reconcile_failed','order='.$order->get_id().';code='.$verified->get_error_code(),$order->get_user_id());
                continue;
            }
            if (empty($verified['paid'])) {$result['skipped']++;continue;}
            $reference = sanitize_text_field((string) ($verified['reference'] ?? $token));
            if (!$order->is_paid()) {
                $order->payment_complete($reference);
                $order->add_order_note('پرداخت با کنترل خودکار سمت سرور تأیید شد. کد رهگیری: '.$reference);
                $order->update_meta_data('_mph_reconciled_at', current_time('mysql'));
                $order->save();
            }
            $result['paid']++;
            MPH_Security::audit('payment_reconciled','order='.$order->get_id().';gateway='.$method.';ref='.hash('sha256',$reference),$order->get_user_id());
        }
        update_option('mph_last_payment_reconciliation', array('time'=>time(),'result'=>$result), false);
        return $result;
    }

    private static function verify_order_server_side($order) {
        $method = (string) $order->get_payment_method();
        if ($method === 'mph_zarinpal' && class_exists('MPH_Payment_Attempts')) return MPH_Payment_Attempts::reconcile($order);
        $token = (string) $order->get_meta('_mph_gateway_token');
        $amount = absint($order->get_meta('_mph_gateway_amount'));
        if (!$token || !$amount) return new WP_Error('missing_payment_meta','اطلاعات تراکنش کامل نیست.');
        if ($method === 'mph_zarinpal') {
            $merchant = trim((string) self::get('zarinpal_merchant'));
            if (!$merchant) return new WP_Error('missing_merchant','شناسه زرین‌پال تنظیم نشده است.');
            $host = self::get('zarinpal_sandbox') ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com';
            $response = self::post_json($host.'/pg/v4/payment/verify.json', array('merchant_id'=>$merchant,'amount'=>$amount,'authority'=>$token));
            if (is_wp_error($response)) return $response;
            $code = absint($response['data']['code'] ?? 0);
            if (!in_array($code, array(100,101), true)) return new WP_Error('not_paid','پرداخت زرین‌پال هنوز تأیید نشده است.');
            return array('paid'=>true,'reference'=>(string)($response['data']['ref_id'] ?? $token));
        }
        if ($method === 'mph_idpay') {
            $key = trim((string) self::get('idpay_api_key'));
            if (!$key) return new WP_Error('missing_api_key','کلید IDPay تنظیم نشده است.');
            $response = self::post_json('https://api.idpay.ir/v1.1/payment/verify', array('id'=>$token,'order_id'=>(string)$order->get_id()), array('X-API-KEY'=>$key,'X-SANDBOX'=>self::get('idpay_sandbox')?'1':'0'));
            if (is_wp_error($response)) return $response;
            if (absint($response['status'] ?? 0)!==100 || absint($response['amount'] ?? 0)!==$amount) return new WP_Error('not_paid','پرداخت IDPay هنوز تأیید نشده یا مبلغ متفاوت است.');
            return array('paid'=>true,'reference'=>(string)($response['payment']['track_id'] ?? $response['track_id'] ?? $token));
        }
        return new WP_Error('unsupported_gateway','درگاه پشتیبانی نمی‌شود.');
    }
}
