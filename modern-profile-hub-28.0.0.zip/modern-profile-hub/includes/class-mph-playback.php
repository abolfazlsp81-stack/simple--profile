<?php
defined('ABSPATH') || exit;

final class MPH_Playback {
    public static function init(){add_action('wp_ajax_mph_playback',array(__CLASS__,'ajax'));}
    public static function ajax() {
        MPH_Helpers::verify_ajax();$uid=get_current_user_id();$course=absint($_POST['course_id']??0);$video=absint($_POST['video_id']??0);
        if(!$uid || !MPH_Courses::has_access($uid,$course,'offline') || !MPH_Courses::video_in_course($course,$video))wp_send_json_error(array('message'=>'دسترسی تماشای این درس را ندارید.'),403);
        $key='_mph_playback_'.$course.'_'.$video;$saved=get_user_meta($uid,$key,true);$saved=is_array($saved)?$saved:array('position'=>0,'revision'=>'');
        if(isset($_POST['position'])){
            $position=(float)$_POST['position'];if(!is_finite($position)||$position<0||$position>604800)wp_send_json_error(array('message'=>'موقعیت پخش معتبر نیست.'),400);
            $result=MPH_Operation_Lock::run('playback:'.$uid.':'.$course.':'.$video,function()use($uid,$course,$video,$key,$position){
                wp_cache_delete($uid,'user_meta');$old=get_user_meta($uid,$key,true);$expected=(string)($_POST['revision']??'');
                if((string)($old['revision']??'')!==$expected)return new WP_Error('mph_playback_conflict','موقعیت پخش در دستگاه دیگری تغییر کرده است.');
                $new=array('position'=>round($position,2),'revision'=>bin2hex(random_bytes(12)),'updated'=>time());update_user_meta($uid,$key,$new);update_user_meta($uid,'_mph_last_video_'.$course,$video);return $new;
            });
            if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message(),'conflict'=>true),409);$saved=$result;
        }
        wp_send_json_success($saved);
    }
}
