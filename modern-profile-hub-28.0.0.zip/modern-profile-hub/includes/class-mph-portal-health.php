<?php
defined('ABSPATH') || exit;

final class MPH_Portal_Health {
    public static function init(){add_action('wp_ajax_mph_service_health',array(__CLASS__,'check'));add_action('wp_ajax_mph_payment_settings',array(__CLASS__,'save_payment'));}
    private static function allowed(){return current_user_can('manage_options')||current_user_can('mph_manage_portal');}
    public static function render() {
        if(!self::allowed())return '';
        global $wpdb;
        $checked=(array)get_option('mph_portal_health_v28',array());$sms=(array)get_option(MPH_SMS::STATUS_OPTION,array());$seen=(int)get_option('mph_bale_last_seen',0);$migration=(int)get_option('mph_private_migration_checked',0);
        $cleanup=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key=%s",'_mph_private_cleanup_required'));
        $rows=array(
            array('ربات بله',$seen?'آخرین درخواست امضاشده دریافت شده؛ این زمان تضمین آنلاین‌بودن فعلی نیست.':'هنوز درخواست همگام‌سازی ثبت نشده است.',$seen),
            array('کاوه‌نگار / پیامک',$sms['connection']['message']??'اتصال هنوز بررسی نشده است.',(int)($sms['connection']['time']??0)),
            array('دسترسی شبکه زرین‌پال',$checked['gateway']['message']??'هنوز بررسی نشده؛ این آزمون پرداخت واقعی ایجاد نمی‌کند.',(int)($checked['gateway']['time']??0)),
            array('مرچنت زرین‌پال',MPH_Payment_Attempts::valid_merchant(MPH_Payments::get('zarinpal_merchant'))?'شناسه ثبت شده؛ فعال‌بودن پذیرندگی فقط در آزمون واقعی مشخص می‌شود.':'شناسه معتبر ثبت نشده است.',0),
            array('پیوست‌های خصوصی',$cleanup?'پاک‌سازی نسخه عمومی '.$cleanup.' فایل نیازمند بررسی دسترسی هاست است.':'صف پاک‌سازی خطای شناخته‌شده‌ای ندارد؛ مهاجرت فایل‌های قدیمی مرحله‌ای است.',$migration),
        );
        $html='<section class="mph-section mph-service-health"><h3>سلامت اتصال‌ها</h3><div class="mph-health-grid">';
        foreach($rows as $r)$html.='<article><h4>'.esc_html($r[0]).'</h4><p>'.esc_html($r[1]).'</p><small>'.esc_html($r[2]?'آخرین بررسی: '.wp_date('Y/m/d H:i',$r[2]):'بدون بررسی تأییدشده').'</small></article>';
        $html.='</div><form data-mph-action="mph_service_health"><button type="submit" class="mph-secondary">بررسی شبکه و نگهداری پیوست‌ها</button><div class="mph-message"></div></form><p>این بررسی پیامک ارسال نمی‌کند و مبلغی از حساب کسر نمی‌کند.</p></section>';
        $settings=MPH_Payments::settings();
        $html.='<section class="mph-section"><h3>تنظیمات درگاه</h3><form data-mph-action="mph_payment_settings" class="mph-form"><label>Merchant ID زرین‌پال<input name="zarinpal_merchant" type="password" autocomplete="new-password" dir="ltr" placeholder="برای حفظ کلید فعلی خالی بگذارید"></label><label><input type="checkbox" name="zarinpal_sandbox" value="1" '.checked(!empty($settings['zarinpal_sandbox']),true,false).'> حالت آزمایشی زرین‌پال</label><label>API Key آی‌دی‌پی<input name="idpay_api_key" type="password" autocomplete="new-password" dir="ltr" placeholder="برای حفظ کلید فعلی خالی بگذارید"></label><label><input type="checkbox" name="idpay_sandbox" value="1" '.checked(!empty($settings['idpay_sandbox']),true,false).'> حالت آزمایشی آی‌دی‌پی</label><button class="mph-primary" type="submit">ذخیره تنظیمات درگاه</button><div class="mph-message"></div></form></section>';
        return $html.self::audit_log();
    }
    public static function check() {
        MPH_Helpers::verify_ajax();if(!self::allowed())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        if(!MPH_Security::allow('health_check',2,MINUTE_IN_SECONDS,'u:'.get_current_user_id()))wp_send_json_error(array('message'=>'کمی بعد دوباره بررسی کنید.'),429);
        $url=MPH_Payments::get('zarinpal_sandbox')?'https://sandbox.zarinpal.com/pg/v4/payment/request.json':'https://payment.zarinpal.com/pg/v4/payment/request.json';
        $response=wp_remote_head($url,array('timeout'=>8,'redirection'=>0,'sslverify'=>true));$code=is_wp_error($response)?0:wp_remote_retrieve_response_code($response);
        $ok=in_array($code,array(200,400,404,405,422),true);
        update_option('mph_portal_health_v28',array('gateway'=>array('time'=>time(),'ok'=>$ok,'message'=>$ok?'ارتباط HTTPS برقرار شد؛ صحت مرچنت و تراکنش واقعی در این آزمون بررسی نمی‌شود.':'ارتباط در این بررسی تأیید نشد؛ دسترسی شبکه میزبان را بررسی کنید.')),false);
        MPH_Private_Files::migrate();
        wp_send_json_success(array('message'=>'نتیجه بررسی ثبت شد.','html'=>MPH_Backup::portal_card().self::render()));
    }
    public static function save_payment() {
        MPH_Helpers::verify_ajax();if(!self::allowed())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        $result=MPH_Payments::persist(wp_unslash($_POST));
        if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),400);
        wp_send_json_success(array('message'=>'تنظیمات درگاه ذخیره و بازخوانی شد.','html'=>MPH_Backup::portal_card().self::render()));
    }
    public static function audit_log() {
        if(!self::allowed())return '';
        global $wpdb;
        $rows=$wpdb->get_results("SELECT created_at,user_id,event,details FROM {$wpdb->prefix}mph_security_log WHERE event IN ('manager_record_saved','manager_roles_updated','course_progress_saved','course_progress_deleted','certificate_issued','certificate_deleted','receipt_approved','receipt_rejected','course_lifecycle','bale_bot_admin_added','bale_bot_admin_removed') ORDER BY id DESC LIMIT 60");
        $html='<section class="mph-section"><h3>آخرین اقدامات مدیران</h3><div class="mph-table-scroll"><table><thead><tr><th>زمان</th><th>مدیر</th><th>عملیات</th><th>جزئیات</th></tr></thead><tbody>';
        $labels=array('manager_record_saved'=>'ذخیره رکورد','manager_roles_updated'=>'تغییر نقش','course_progress_saved'=>'ثبت پیشرفت','course_progress_deleted'=>'حذف پیشرفت','certificate_issued'=>'صدور گواهی','certificate_deleted'=>'حذف گواهی','receipt_approved'=>'تأیید فیش','receipt_rejected'=>'رد فیش','course_lifecycle'=>'حذف / بایگانی دوره','bale_bot_admin_added'=>'افزودن مدیر ربات','bale_bot_admin_removed'=>'حذف مدیر ربات');
        foreach((array)$rows as $r){$user=get_userdata($r->user_id);$html.='<tr><td>'.esc_html($r->created_at).' UTC</td><td>'.esc_html($user?MPH_Helpers::display_name($user):'سیستم').'</td><td>'.esc_html($labels[$r->event]??$r->event).'</td><td>'.esc_html($r->details).'</td></tr>';}
        if(!$rows)$html.='<tr><td colspan="4">هنوز رویدادی ثبت نشده است.</td></tr>';
        return $html.'</tbody></table></div></section>';
    }
}
