<?php
defined('ABSPATH') || exit;

final class MPH_Payouts {
    const POST_TYPE = 'mph_staff_payout';
    const CARD_META = 'mph_payout_card';
    const OWNER_META = 'mph_payout_card_owner';
    const BANK_META = 'mph_payout_bank';

    public static function init() {
        add_action('init', array(__CLASS__, 'register_type'));
        add_action('wp_ajax_mph_staff_payout_save', array(__CLASS__, 'ajax_save'));
    }

    public static function register_type() {
        register_post_type(self::POST_TYPE, array(
            'label'=>'واریزی مدرس و درمانگر','public'=>false,'show_ui'=>false,
            'supports'=>array('title','author'),'capability_type'=>'post','map_meta_cap'=>true,
        ));
    }

    public static function is_staff($user = null) {
        $user = $user instanceof WP_User ? $user : ($user ? get_user_by('id', absint($user)) : wp_get_current_user());
        return $user instanceof WP_User && (MPH_Helpers::has_role('mph_instructor',$user) || MPH_Helpers::has_role('mph_therapist',$user));
    }

    public static function profile_fields($user) {
        $user = $user instanceof WP_User ? $user : get_user_by('id',absint($user));
        if (!$user || !self::is_staff($user)) return '';
        $card=MPH_Security::get_user_meta($user->ID,self::CARD_META);$owner=MPH_Security::get_user_meta($user->ID,self::OWNER_META);$bank=MPH_Security::get_user_meta($user->ID,self::BANK_META);
        ob_start(); ?><div class="mph-payout-bank-fields"><div class="mph-section-heading"><div><small class="mph-eyebrow">اطلاعات تسویه</small><h4>حساب بانکی واریز درآمد</h4><p>مدیر واریزی‌های ثبت‌شده را فقط به همین شماره کارت اعلامی متصل می‌کند.</p></div><span class="dashicons dashicons-money-alt"></span></div><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('شماره کارت ۱۶ رقمی'); ?><input name="payout_card" value="<?php echo esc_attr($card); ?>" inputmode="numeric" maxlength="19" autocomplete="cc-number" dir="ltr" placeholder="6037 9912 3456 7890"></label><label><?php echo MPH_Helpers::required('نام صاحب کارت'); ?><input name="payout_card_owner" value="<?php echo esc_attr($owner); ?>" maxlength="100" placeholder="مطابق حساب بانکی"></label><label>نام بانک <small>(اختیاری)</small><input name="payout_bank" value="<?php echo esc_attr($bank); ?>" maxlength="60" placeholder="مثلاً بانک ملی"></label></div><p class="mph-payout-security"><span class="dashicons dashicons-shield-alt"></span> شماره کارت فقط برای ثبت تسویه توسط مدیران مجاز استفاده می‌شود.</p></div><?php return ob_get_clean();
    }

    public static function save_profile_card($user_id) {
        $user=get_user_by('id',absint($user_id));if(!$user||!self::is_staff($user))return true;
        $card=self::normalize_card(MPH_Helpers::posted('payout_card'));
        $owner=MPH_Helpers::posted('payout_card_owner');$bank=MPH_Helpers::posted('payout_bank');
        if($card===''&&$owner===''){delete_user_meta($user->ID,self::CARD_META);delete_user_meta($user->ID,self::OWNER_META);delete_user_meta($user->ID,self::BANK_META);return true;}
        if(!$card||!$owner)return new WP_Error('payout_card','شماره کارت و نام صاحب کارت را با هم کامل کنید.');
        if(!self::valid_card($card))return new WP_Error('payout_card','شماره کارت واردشده معتبر نیست؛ ۱۶ رقم کارت را بررسی کنید.');
        MPH_Security::update_user_meta($user->ID,self::CARD_META,$card);MPH_Security::update_user_meta($user->ID,self::OWNER_META,$owner);MPH_Security::update_user_meta($user->ID,self::BANK_META,$bank);MPH_Security::audit('payout_profile_updated','encrypted_fields=3',$user->ID);return true;
    }

    public static function render_user($user_id = 0, $embedded = false) {
        // لیست واریزی فقط در منوی مستقل «واریزی‌های من» نمایش داده می‌شود.
        if ($embedded) return '';
        $user_id=$user_id?absint($user_id):get_current_user_id();$user=get_user_by('id',$user_id);
        if(!$user||get_current_user_id()!==$user_id&&!self::can_manage())return'<div class="mph-empty">دسترسی ندارید.</div>';
        $items=self::records($user_id);$total=0;foreach($items as$item)$total+=(float)get_post_meta($item->ID,'_mph_payout_amount',true);
        ob_start(); ?><section class="mph-payout-history <?php echo $embedded?'is-embedded':'mph-section'; ?>"><div class="mph-section-heading"><div><small class="mph-eyebrow">دفتر شفاف تسویه</small><h3>واریزی‌های من</h3><p>تاریخ، مبلغ، کد پیگیری و توضیح هر واریز ثبت‌شده توسط مدیر</p></div><span class="dashicons dashicons-list-view"></span></div><div class="mph-payout-summary"><article><small>جمع کل واریزی</small><b><?php echo wp_kses_post(self::amount($total)); ?></b></article><article><small>تعداد واریز</small><b><?php echo absint(count($items)); ?></b></article><article><small>کارت فعال</small><b dir="ltr"><?php echo esc_html(self::mask_card(MPH_Security::get_user_meta($user_id,self::CARD_META))); ?></b></article></div><div class="mph-payout-list"><?php if(!$items): ?><div class="mph-empty"><span class="dashicons dashicons-money-alt"></span><p>هنوز واریزی‌ای برای شما ثبت نشده است.</p></div><?php endif;foreach($items as$item):$manager=get_user_by('id',absint(get_post_meta($item->ID,'_mph_payout_manager',true))); ?><article><span class="mph-payout-icon dashicons dashicons-yes-alt"></span><div><small><?php echo esc_html(get_post_meta($item->ID,'_mph_payout_jdate',true)); ?> · ثبت توسط <?php echo esc_html($manager?MPH_Helpers::display_name($manager):'مدیر'); ?></small><h4><?php echo wp_kses_post(self::amount(get_post_meta($item->ID,'_mph_payout_amount',true))); ?></h4><?php if(get_post_meta($item->ID,'_mph_payout_note',true)): ?><p><?php echo esc_html(get_post_meta($item->ID,'_mph_payout_note',true)); ?></p><?php endif; ?></div><div class="mph-payout-track"><small>کد پیگیری</small><b dir="ltr"><?php echo esc_html(get_post_meta($item->ID,'_mph_payout_tracking',true)); ?></b><em dir="ltr"><?php echo esc_html(self::mask_card(get_post_meta($item->ID,'_mph_payout_card',true))); ?></em></div></article><?php endforeach; ?></div></section><?php return ob_get_clean();
    }

    public static function render_manager() {
        if(!self::can_manage())return'<div class="mph-empty">دسترسی مدیریت لازم است.</div>';
        $staff=get_users(array('role__in'=>array('mph_instructor','tutor_instructor','mph_therapist'),'orderby'=>'display_name','order'=>'ASC'));
        $items=self::records();$today=MPH_Helpers::gregorian_to_jalali_date(current_time('Y-m-d'));$total=0;foreach($items as$item)$total+=(float)get_post_meta($item->ID,'_mph_payout_amount',true);
        ob_start(); ?><section class="mph-section mph-payout-manager"><div class="mph-section-heading"><div><small class="mph-eyebrow">ثبت تسویه مجموعه</small><h3>واریز مدرس و درمانگر</h3><p>پرداخت را بر اساس شماره کارت اعلامی شخص ثبت کنید تا در کارتابل او قابل مشاهده باشد.</p></div><span class="dashicons dashicons-money-alt"></span></div><div class="mph-payout-summary"><article><small>جمع واریزی ثبت‌شده</small><b><?php echo wp_kses_post(self::amount($total)); ?></b></article><article><small>تعداد تراکنش</small><b><?php echo absint(count($items)); ?></b></article><article><small>افراد دارای شماره کارت</small><b><?php echo absint(count(array_filter($staff,function($user){return(bool)MPH_Security::get_user_meta($user->ID,self::CARD_META);}))); ?></b></article></div>
        <form class="mph-form mph-payout-form" data-mph-action="mph_staff_payout_save"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('مدرس یا درمانگر'); ?><select name="recipient_id" required><option value="">انتخاب کنید</option><?php foreach($staff as$user):$card=MPH_Security::get_user_meta($user->ID,self::CARD_META); ?><option value="<?php echo absint($user->ID); ?>" <?php disabled(!$card); ?>><?php echo esc_html(MPH_Helpers::display_name($user).' — '.self::role_label($user).' — '.($card?self::group_card($card):'بدون شماره کارت')); ?></option><?php endforeach; ?></select><small>افراد بدون شماره کارت تا تکمیل پروفایل قابل انتخاب نیستند.</small></label><label><?php echo MPH_Helpers::required('مبلغ واریز'); ?><input name="payout_amount" inputmode="decimal" required placeholder="بدون محدودیت مبلغ"></label><label class="mph-jalali-field"><?php echo MPH_Helpers::required('تاریخ شمسی واریز'); ?><input type="text" name="payout_jdate" value="<?php echo esc_attr($today); ?>" inputmode="numeric" autocomplete="off" dir="ltr" maxlength="10" required placeholder="1405/06/02" data-mph-jalali-input><small>مثال: ۱۴۰۵/۰۶/۰۲؛ ورود ۸ رقم پیوسته هم مجاز است.</small></label><label>کد پیگیری بانکی <small>(اختیاری)</small><input name="payout_tracking" dir="ltr" maxlength="80" placeholder="در صورت خالی‌بودن خودکار ساخته می‌شود"></label></div><label>توضیحات <small>(اختیاری)</small><textarea name="payout_note" rows="3" maxlength="500" placeholder="مثلاً تسویه دوره مرداد یا جلسات هفته اول"></textarea></label><button class="mph-primary" type="submit"><span class="dashicons dashicons-saved"></span> ثبت قطعی واریز</button><div class="mph-message"></div></form>
        <div class="mph-payout-admin-list"><h4>آخرین واریزی‌ها</h4><?php if(!$items): ?><div class="mph-empty">هنوز واریزی ثبت نشده است.</div><?php endif;foreach($items as$item):$recipient=get_user_by('id',absint(get_post_meta($item->ID,'_mph_payout_recipient',true))); ?><article><div><?php echo get_avatar($recipient?$recipient->ID:0,46); ?><span><b><?php echo esc_html($recipient?MPH_Helpers::display_name($recipient):'کاربر حذف‌شده'); ?></b><small><?php echo esc_html(get_post_meta($item->ID,'_mph_payout_jdate',true).' · '.self::role_label($recipient)); ?></small></span></div><strong><?php echo wp_kses_post(self::amount(get_post_meta($item->ID,'_mph_payout_amount',true))); ?></strong><span dir="ltr"><?php echo esc_html(self::group_card(get_post_meta($item->ID,'_mph_payout_card',true))); ?></span><em dir="ltr"><?php echo esc_html(get_post_meta($item->ID,'_mph_payout_tracking',true)); ?></em></article><?php endforeach; ?></div></section><?php return ob_get_clean();
    }

    public static function ajax_save() {
        MPH_Helpers::verify_ajax();if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        $recipient_id=absint($_POST['recipient_id']??0);$recipient=get_user_by('id',$recipient_id);if(!$recipient||!self::is_staff($recipient))wp_send_json_error(array('message'=>'مدرس یا درمانگر معتبر نیست.'));
        $card=self::normalize_card(MPH_Security::get_user_meta($recipient_id,self::CARD_META));if(!$card||!self::valid_card($card))wp_send_json_error(array('message'=>'شماره کارت معتبر در پروفایل این شخص ثبت نشده است.'));
        $raw=MPH_Helpers::normalize_digits(MPH_Helpers::posted('payout_amount'));$raw=str_replace(array(',','،','٬',' '),'',$raw);$amount=function_exists('wc_format_decimal')?wc_format_decimal($raw):preg_replace('/[^0-9.]/','',$raw);if($amount===''||!is_numeric($amount)||(float)$amount<=0)wp_send_json_error(array('message'=>'مبلغ واریز معتبر نیست.'));
        $jdate=MPH_Helpers::jalali_date(MPH_Helpers::posted('payout_jdate'));if(!$jdate)wp_send_json_error(array('message'=>'تاریخ شمسی معتبر نیست؛ نمونه صحیح: ۱۴۰۵/۰۶/۰۲'));
        $gdate=MPH_Helpers::jalali_to_gregorian_date($jdate);if($gdate>current_time('Y-m-d'))wp_send_json_error(array('message'=>'تاریخ واریز نمی‌تواند در آینده باشد.'));$tracking=trim(MPH_Helpers::posted('payout_tracking'));if($tracking==='')$tracking='MPH-'.strtoupper(wp_generate_password(10,false,false));
        $duplicate=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'publish','numberposts'=>1,'fields'=>'ids','meta_key'=>'_mph_payout_tracking','meta_value'=>$tracking));if($duplicate)wp_send_json_error(array('message'=>'این کد پیگیری قبلاً ثبت شده است.'));
        $lock='mph_staff_payout_'.get_current_user_id();if(get_transient($lock))wp_send_json_error(array('message'=>'یک واریز در حال ثبت است؛ چند ثانیه صبر کنید.'),429);set_transient($lock,1,10);
        $post_id=wp_insert_post(array('post_type'=>self::POST_TYPE,'post_status'=>'publish','post_author'=>get_current_user_id(),'post_title'=>'واریز '.MPH_Helpers::display_name($recipient).' — '.$jdate),true);if(is_wp_error($post_id)){delete_transient($lock);wp_send_json_error(array('message'=>$post_id->get_error_message()));}
        foreach(array('recipient'=>$recipient_id,'manager'=>get_current_user_id(),'amount'=>$amount,'currency'=>function_exists('get_woocommerce_currency')?get_woocommerce_currency():'','jdate'=>$jdate,'gdate'=>$gdate,'tracking'=>$tracking,'note'=>MPH_Helpers::posted('payout_note','textarea'),'card'=>MPH_Security::encrypt($card),'card_owner'=>MPH_Security::encrypt(MPH_Security::get_user_meta($recipient_id,self::OWNER_META)),'bank'=>MPH_Security::encrypt(MPH_Security::get_user_meta($recipient_id,self::BANK_META)))as$key=>$value)update_post_meta($post_id,'_mph_payout_'.$key,$value);
        MPH_Tickets::create_system_notification($recipient_id,'واریز جدید ثبت شد','مبلغ '.wp_strip_all_tags(self::amount($amount)).' در تاریخ '.$jdate.' با کد پیگیری '.$tracking.' برای شما ثبت شد.','payment');MPH_Helpers::audit('staff_payout','recipient='.$recipient_id.';amount='.$amount.';tracking='.$tracking);
        wp_send_json_success(array('message'=>'واریز ثبت و به شخص اطلاع داده شد.','html'=>self::render_manager()));
    }

    private static function records($recipient_id = 0) {$args=array('post_type'=>self::POST_TYPE,'post_status'=>'publish','numberposts'=>300,'meta_key'=>'_mph_payout_gdate','orderby'=>'meta_value','order'=>'DESC');if($recipient_id)$args['meta_query']=array(array('key'=>'_mph_payout_recipient','value'=>absint($recipient_id)));return get_posts($args);}
    private static function normalize_card($value){return preg_replace('/\D+/','',MPH_Helpers::normalize_digits(MPH_Security::decrypt($value)));}
    private static function valid_card($card){if(!preg_match('/^\d{16}$/',$card)||preg_match('/^(\d)\1{15}$/',$card))return false;$sum=0;for($i=0;$i<16;$i++){$value=absint($card[$i])*(($i%2)===0?2:1);$sum+=$value>9?$value-9:$value;}return($sum%10)===0;}
    private static function group_card($card){$card=self::normalize_card($card);return strlen($card)===16?implode(' ',str_split($card,4)):'ثبت نشده';}
    private static function mask_card($card){$card=self::normalize_card($card);return strlen($card)===16?'**** **** **** '.substr($card,-4):'ثبت نشده';}
    private static function amount($value){return function_exists('wc_price')?wc_price((float)$value):number_format_i18n((float)$value).' واحد فروشگاه';}
    private static function role_label($user){if(!$user)return'نامشخص';return MPH_Helpers::has_role('mph_therapist',$user)?'درمانگر':'مدرس';}
    private static function can_manage(){return is_user_logged_in()&&(current_user_can('manage_options')||current_user_can('mph_manage_portal')||MPH_Helpers::has_role('mph_manager'));}
}
