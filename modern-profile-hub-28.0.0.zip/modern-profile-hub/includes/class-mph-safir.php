<?php
defined('ABSPATH') || exit;

/**
 * اتصال OTP افزونه به سفیر و انتقال مدیریت پیام همگانی به ربات مستقل بله.
 */
final class MPH_Safir {
    const OPTION = 'mph_safir_settings';
    const SCHEMA = 'mph_safir_schema';

    public static function init() {
        add_action('admin_post_mph_safir_settings', array(__CLASS__, 'save_settings'));
    }

    public static function install() {
        self::migrate_old_settings();
        if(get_option(self::SCHEMA)!=='2.0')update_option(self::SCHEMA,'2.0',false);
    }

    private static function migrate_old_settings() {
        if (get_option(self::OPTION, null) !== null) return;
        $old = get_option('mph_bale_settings', array());
        $settings = array(
            'api_access_key' => sanitize_text_field($old['safir_key'] ?? ''),
            'bot_id' => (string) absint($old['safir_bot_id'] ?? 0),
        );
        update_option(self::OPTION, $settings, false);
    }

    public static function settings() {
        return wp_parse_args(get_option(self::OPTION, array()), array('api_access_key'=>'','bot_id'=>'','bot_admin_url'=>''));
    }

    private static function api_key() {
        if (defined('MPH_SAFIR_API_KEY') && MPH_SAFIR_API_KEY) return (string) MPH_SAFIR_API_KEY;
        $settings = self::settings(); return trim((string) $settings['api_access_key']);
    }

    private static function bot_id() {
        if (defined('MPH_SAFIR_BOT_ID') && MPH_SAFIR_BOT_ID) return absint(MPH_SAFIR_BOT_ID);
        $settings = self::settings(); return absint($settings['bot_id']);
    }

    public static function ready() { return self::api_key() !== '' && self::bot_id() > 0; }
    public static function bot_admin_url() {
        $settings=self::settings();
        return esc_url_raw((string)($settings['bot_admin_url']??''));
    }
    private static function can_manage() { return current_user_can('manage_options') || current_user_can('mph_manage_portal') || MPH_Helpers::has_role('mph_manager'); }

    public static function admin_page() {
        if (!current_user_can('manage_options')) wp_die('دسترسی کافی ندارید.');
        self::install(); $settings=self::settings(); ?>
        <div class="wrap mph-admin" dir="rtl">
            <header class="mph-admin-head"><span class="dashicons dashicons-email-alt"></span><div><h1>سفیر بله</h1><p>تنظیم OTP و لینک انتقال مدیر به ربات بله</p></div></header>
            <?php if(!empty($_GET['updated'])): ?><div class="notice notice-success is-dismissible"><p>تنظیمات سفیر ذخیره شد.</p></div><?php endif; ?>
            <section class="mph-admin-box mph-bale-admin-summary"><div><b><?php echo self::ready()?'فعال':'ناقص'; ?></b><span>وضعیت OTP سفیر</span></div><div><b>ربات مستقل</b><span>مدیریت پیام همگانی</span></div><div><b>بدون ارسال سایت</b><span>انتقال مستقیم به بله</span></div></section>
            <form class="mph-admin-box" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="mph_safir_settings"><?php wp_nonce_field('mph_safir_settings'); ?>
                <h2>اطلاعات سرویس سفیر</h2><p>کلید از پنل کسب‌وکار بله دریافت می‌شود. خالی گذاشتن فیلد کلید، مقدار قبلی را حفظ می‌کند.</p>
                <div class="mph-admin-grid"><label>Api Access Key<input type="password" name="api_access_key" autocomplete="new-password" placeholder="<?php echo self::api_key()?'کلید ثبت شده است':'کلید سرویس سفیر'; ?>"></label><label>Bot ID عددی<input type="number" name="bot_id" value="<?php echo esc_attr($settings['bot_id']); ?>" min="1" inputmode="numeric"></label></div>
                <label>لینک پنل مدیریت ربات بله<input type="url" name="bot_admin_url" value="<?php echo esc_attr($settings['bot_admin_url']); ?>" placeholder="https://ble.ir/your_bot"></label>
                <div class="mph-admin-note"><b>پیام همگانی:</b><p>کارت «پیام همگانی» داخل پنل مدیر فقط این لینک را باز می‌کند و هیچ پیام یا فایلی در سایت ارسال یا صف‌بندی نمی‌شود.</p></div>
                <button class="button button-primary button-hero">ذخیره و فعال‌سازی</button>
            </form>
        </div><?php
    }

    public static function save_settings() {
        if (!current_user_can('manage_options')) wp_die('دسترسی کافی ندارید.');
        check_admin_referer('mph_safir_settings'); $settings=self::settings();
        $key=MPH_Helpers::posted('api_access_key','raw'); if($key!=='')$settings['api_access_key']=trim(preg_replace('/[\r\n\t]+/','',$key));
        $settings['bot_id']=(string)absint($_POST['bot_id']??0);$settings['bot_admin_url']=esc_url_raw(MPH_Helpers::posted('bot_admin_url','raw'));update_option(self::OPTION,$settings,false);
        wp_safe_redirect(add_query_arg(array('page'=>'mph-safir','updated'=>1),admin_url('admin.php'))); exit;
    }

    public static function render_manager() {
        if(!self::can_manage())return'<section class="mph-section mph-error-box">دسترسی به پیام همگانی ندارید.</section>';
        $url=self::bot_admin_url();if(!$url)return'<section class="mph-section mph-bot-redirect"><span class="dashicons dashicons-warning"></span><h3>لینک ربات تنظیم نشده است</h3><p>مدیر اصلی سایت باید از «پروفایل مدرن ← سفیر بله» لینک پنل مدیریت ربات را ثبت کند.</p></section>';
        return'<section class="mph-section mph-bot-redirect"><span class="dashicons dashicons-buddicons-pm"></span><h3>مدیریت پیام همگانی در ربات بله</h3><p>ارسال پیام فقط داخل ربات انجام می‌شود و اطلاعات پیام به سایت برنمی‌گردد.</p><a class="mph-primary" href="'.esc_url($url).'" rel="noopener">باز کردن ربات بله</a></section>';
    }

    private static function normalize_phone($phone){$phone=MPH_Helpers::phone($phone);return$phone?'98'.substr($phone,1):'';}
    private static function send($phone,$message_data,$request_id='') {
        if(!self::ready())return new WP_Error('not_configured','سفیر تنظیم نشده است.');$phone=self::normalize_phone($phone);if(!$phone)return new WP_Error('invalid_phone','شماره تلفن معتبر نیست.');$payload=array('request_id'=>$request_id?:wp_generate_uuid4(),'bot_id'=>self::bot_id(),'phone_number'=>$phone,'message_data'=>$message_data);$response=wp_remote_post('https://safir.bale.ai/api/v3/send_message',array('timeout'=>25,'headers'=>array('api-access-key'=>self::api_key(),'Content-Type'=>'application/json'),'body'=>wp_json_encode($payload),'data_format'=>'body'));if(is_wp_error($response))return new WP_Error('remote_error','ارتباط با سفیر برقرار نشد.');$status=wp_remote_retrieve_response_code($response);$decoded=json_decode(wp_remote_retrieve_body($response),true);if($status===429)return new WP_Error('rate_limit','محدودیت سرعت سفیر فعال شده است.');if(!empty($decoded['error_data'])){$error=is_array($decoded['error_data'])&&isset($decoded['error_data'][0])?$decoded['error_data'][0]:$decoded['error_data'];$code=absint($error['code']??0);$map=array(3=>'rate_limit',8=>'invalid_phone',17=>'not_bale_user',20=>'payment_required',21=>'contact_limit');return new WP_Error($map[$code]??'safir_error',sanitize_text_field($error['description']??'ارسال ناموفق بود.'));}if(empty($decoded['message_id']))return new WP_Error('safir_error','پاسخ معتبر از سفیر دریافت نشد.');return true;
    }

    public static function send_otp_code($phone,$code){return self::send($phone,array('otp_message'=>array('otp'=>(string)$code)),wp_generate_uuid4());}

    public static function start_otp($user, $purpose = 'recovery') {
        if (!($user instanceof WP_User)) return new WP_Error('user_missing','حساب کاربری پیدا نشد.');
        $phone=MPH_Helpers::phone(get_user_meta($user->ID,'mph_phone',true));
        if (!$phone) $phone=MPH_Helpers::phone(get_user_meta($user->ID,'billing_phone',true));
        if (!$phone) return new WP_Error('phone_missing','شماره تلفن حساب معتبر نیست.');
        if (!in_array($purpose,array('login','recovery'),true)) return new WP_Error('otp_purpose','نوع درخواست معتبر نیست.');
        $rate='mph_otp_rate_'.md5($phone); $hour='mph_otp_hour_'.md5($phone);
        // The SQL advisory lock is released automatically even if the PHP worker crashes.
        global $wpdb; $lock='mph_otp_send_'.md5($phone);
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!=='1') return new WP_Error('otp_wait','درخواست قبلی در حال ارسال است.');
        try {
            if (get_transient($rate)) return new WP_Error('otp_wait','برای ارسال مجدد یک دقیقه صبر کنید.');
            $counter=get_transient($hour);
            // Read legacy integer counters without extending the new fixed one-hour window.
            $count=is_array($counter)?absint($counter['count']??0):absint($counter);
            $until=is_array($counter)?absint($counter['expires']??0):time()+HOUR_IN_SECONDS;
            if ($until<=time()) { $count=0; $until=time()+HOUR_IN_SECONDS; }
            if ($count>=5) return new WP_Error('otp_limit','تعداد درخواست بیش از حد مجاز است. بعداً تلاش کنید.');
            set_transient($rate,1,MINUTE_IN_SECONDS);
            set_transient($hour,array('count'=>$count+1,'expires'=>$until),max(1,$until-time()));
            $code=(string)random_int(100000,999999); $flow=bin2hex(random_bytes(24));
            $sent=class_exists('MPH_SMS')&&MPH_SMS::enabled()?MPH_SMS::send_otp($phone,$code):self::send_otp_code($phone,$code);
            if (is_wp_error($sent)) return $sent;
            $stored=set_transient('mph_otp_'.hash('sha256',$flow),array('user_id'=>$user->ID,'phone'=>$phone,'hash'=>wp_hash_password($code),'attempts'=>0,'purpose'=>$purpose,'expires'=>time()+5*MINUTE_IN_SECONDS),5*MINUTE_IN_SECONDS);
            if (!$stored) return new WP_Error('otp_storage','ثبت کد ورود ممکن نشد؛ کمی بعد دوباره تلاش کنید.');
            return $flow;
        } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock)); }
    }

    public static function consume_otp($flow, $phone, $code, $purpose = 'recovery') {
        $flow=(string)$flow; $phone=MPH_Helpers::phone($phone);
        $code=trim(MPH_Helpers::normalize_digits((string)$code));
        if (!preg_match('/^[a-f0-9]{48}$/D',$flow) || !$phone || !preg_match('/^\\d{6}$/D',$code)) return new WP_Error('otp_input','کد شش‌رقمی یا درخواست معتبر نیست.');
        $key='mph_otp_'.hash('sha256',$flow);
        global $wpdb; $lock='mph_otp_use_'.substr(hash('sha256',$flow),0,40);
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!=='1') return new WP_Error('otp_busy','درخواست تأیید قبلی در حال پردازش است.');
        try {
            $data=get_transient($key);
            if (!is_array($data) || empty($data['expires']) || $data['expires']<=time() || !hash_equals((string)$data['phone'],$phone) || ($data['purpose']??'')!==$purpose) return new WP_Error('otp_expired','رمز منقضی یا نامعتبر است؛ دوباره درخواست کد بدهید.');
            $attempts=absint($data['attempts'])+1;
            if ($attempts>5) { delete_transient($key); return new WP_Error('otp_attempts','تعداد تلاش‌ها بیش از حد مجاز شد.'); }
            if (!wp_check_password($code,$data['hash'])) {
                $data['attempts']=$attempts;
                if ($attempts>=5) delete_transient($key);
                else set_transient($key,$data,max(1,$data['expires']-time()));
                return new WP_Error('otp_wrong','رمز یک‌بارمصرف نادرست است.');
            }
            if (!delete_transient($key)) return new WP_Error('otp_storage','ثبت مصرف کد ممکن نشد؛ دوباره درخواست کد بدهید.');
            $user=get_user_by('id',absint($data['user_id']));
            return $user?:new WP_Error('user_missing','حساب کاربری پیدا نشد.');
        } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock)); }
    }
}
