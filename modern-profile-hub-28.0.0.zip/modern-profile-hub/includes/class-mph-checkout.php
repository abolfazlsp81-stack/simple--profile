<?php
defined('ABSPATH') || exit;

/** Creates a repeatable order snapshot without emptying the account's cart. */
final class MPH_Checkout {
    public static function gateways() {
        if (!function_exists('WC') || !WC()->payment_gateways()) return array();
        $result=array();
        foreach (WC()->payment_gateways()->get_available_payment_gateways() as $id=>$gateway) if (!in_array($id,array('bacs','cheque','cod'),true)) $result[$id]=$gateway;
        return $result;
    }

    public static function gateway_select() {
        $html='<label class="mph-gateway-select">درگاه پرداخت<select name="gateway_id">';
        foreach (self::gateways() as $id=>$gateway) $html.='<option value="'.esc_attr($id).'">'.esc_html(wp_strip_all_tags($gateway->get_title())).'</option>';
        return $html.'</select></label>';
    }

    public static function submit($user,$billing,$kind='online',$gateway_id='',$upload=null) {
        return MPH_Operation_Lock::run('checkout:'.$user->ID,function() use ($user,$billing,$kind,$gateway_id,$upload) {
            MPH_Shared_Cart::sync();$cart=WC()->cart;
            $canonical=MPH_Shared_Cart::read($user->ID);$snapshot=MPH_Shared_Cart::snapshot();
            if (!$snapshot) return new WP_Error('mph_empty_cart','سبد خرید خالی است یا انتخاب فعلی قابل خرید نیست.');
            if (count($snapshot)!==count($canonical['items'])) return new WP_Error('mph_unavailable','یک انتخاب فعلاً قابل خرید نیست؛ موارد مشخص‌شده در سبد را بررسی کنید.');
            $cart->calculate_totals();
            $signature=array('items'=>$snapshot,'total'=>(string)$cart->get_total('edit'),'coupons'=>$cart->get_applied_coupons(),'kind'=>$kind,'currency'=>get_woocommerce_currency());
            $fingerprint=hash('sha256',wp_json_encode($signature));
            $orders=wc_get_orders(array('customer_id'=>$user->ID,'limit'=>20,'meta_key'=>'_mph_checkout_fingerprint','meta_value'=>$fingerprint,'orderby'=>'date','order'=>'DESC'));
            foreach ($orders as $candidate) {
                if ($candidate->is_paid()) return self::response($candidate,'سفارش قبلاً پرداخت شده است.');
                if ($candidate->get_meta(MPH_Commerce::RECEIPT_STATUS)==='pending') return self::response($candidate,'فیش این سفارش قبلاً ثبت شده و در انتظار بررسی است.');
                if ($candidate->has_status(array('pending','failed')) && (float)$candidate->get_total()===(float)$cart->get_total('edit')) {
                    $holds=MPH_Appointment_Cart::ensure_holds($candidate);
                    if (is_wp_error($holds)) return $holds;
                    if ($kind==='online') return self::pay($candidate,$gateway_id);
                }
            }
            $file_id=0;
            if ($kind==='receipt') {
                if (!is_callable($upload)) return new WP_Error('mph_receipt_missing','فایل فیش را انتخاب کنید.');
                $file_id=call_user_func($upload);
                if (is_wp_error($file_id)) return $file_id;
            }
            $order=wc_create_order(array('customer_id'=>$user->ID,'created_via'=>'modern-profile-hub'));
            if (is_wp_error($order)) {if($file_id)wp_delete_attachment($file_id,true);return new WP_Error('mph_order_create','ساخت سفارش انجام نشد؛ سبد شما محفوظ است.');}
            try {
                $order->update_meta_data('_mph_checkout_fingerprint',$fingerprint);
                $order->update_meta_data('_mph_cart_snapshot',$snapshot);
                $order->set_address($billing,'billing');$order->set_currency(get_woocommerce_currency());
                $appointment_ids=array();
                foreach ($cart->get_cart() as $wc_key=>$row) {
                    $entry=$canonical['items'][$row['mph_shared_key']];$product=$row['data'];
                    if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) throw new Exception('محصول اکنون قابل خرید نیست.');
                    $appointment_id=0;
                    if ($entry['kind']==='appointment') {
                        $appointment_id=MPH_Appointment_Cart::reserve($entry,$order,$row['mph_shared_key']);
                        if (is_wp_error($appointment_id)) throw new Exception($appointment_id->get_error_message());
                        $appointment_ids[]=$appointment_id;$order->update_meta_data('_mph_appointment_ids',$appointment_ids);
                        $order->update_meta_data(MPH_Appointments::ORDER_META,$appointment_ids[0]);$order->save();
                    } elseif ($entry['kind']==='course') {
                        if (get_post_status($entry['course_id'])!=='publish') throw new Exception('این دوره برای خرید جدید در دسترس نیست.');
                        $capacity=MPH_Growth::capacity_status($product->get_id());
                        if (!empty($capacity['full'])) throw new Exception('ظرفیت دوره تکمیل شده است.');
                    }
                    $args=array('variation'=>$row['variation']??array());
                    if ($appointment_id) $args+=array('subtotal'=>(float)$entry['price'],'total'=>(float)$entry['price']);
                    $item_id=$order->add_product($product,1,$args);
                    if (!$item_id) throw new Exception('افزودن انتخاب به سفارش انجام نشد.');
                    $item=$order->get_item($item_id);
                    MPH_Shared_Cart::copy_line($item,$wc_key,$row,$order);
                    MPH_Courses::sync_order_item_meta($item,$product);
                    if ($appointment_id) {$item->set_name($entry['label']);$item->add_meta_data(MPH_Appointments::ORDER_META,$appointment_id,true);}
                    $item->save();
                }
                foreach ($cart->get_applied_coupons() as $code) {$applied=$order->apply_coupon($code);if(is_wp_error($applied))throw new Exception('کد تخفیف دیگر قابل استفاده نیست؛ سبد را بررسی کنید.');}
                $order->calculate_totals();
                $order->set_status('pending');$order->save();
                // Never send a different total from what the customer just reviewed.
                if (abs((float)$order->get_total()-(float)$cart->get_total('edit'))>0.01) throw new Exception('جمع سفارش تغییر کرده است؛ صورتحساب را دوباره بررسی کنید.');
                MPH_Payment_Attempts::event($order,'order_created','سفارش ثبت شد؛ انتخاب‌ها تا پرداخت در سبد باقی می‌مانند.');
                MPH_Growth::track_checkout($order);
                if (!$order->needs_payment()) {
                    $order->payment_complete();$order->update_status('completed','خرید رایگان ثبت شد.');
                    return self::response($order,'خرید رایگان ثبت شد.');
                }
                if ($kind==='receipt') {
                    $order->set_payment_method('bacs');$order->set_payment_method_title('فیش واریزی');
                    $order->update_meta_data(MPH_Commerce::RECEIPT_META,'yes');$order->update_meta_data(MPH_Commerce::RECEIPT_STATUS,'pending');$order->update_meta_data(MPH_Commerce::RECEIPT_FILE,$file_id);
                    $order->set_status('on-hold','فیش واریزی در انتظار بررسی مدیر است.');$order->save();
                    wp_update_post(array('ID'=>$file_id,'post_parent'=>$order->get_id()));
                    foreach($appointment_ids as $id) update_post_meta($id,'_mph_appointment_status','pending_receipt');
                    $secured=MPH_Private_Files::protect($file_id,'receipt',$order->get_id(),$user->ID);
                    if(is_wp_error($secured))throw new Exception($secured->get_error_message());
                    MPH_Payment_Attempts::event($order,'receipt_received','فیش دریافت شد و در انتظار بررسی مدیر است.');
                    return self::response($order,'فیش دریافت شد؛ سفارش و اقلام سبد محفوظ‌اند.');
                }
                return self::pay($order,$gateway_id);
            } catch (Throwable $error) {
                $fresh=wc_get_order($order->get_id());
                if ($fresh && $fresh->is_paid()) return self::response($fresh,'پرداخت ثبت شده است؛ نتیجه فعال‌سازی را در سوابق سفارش بررسی کنید.');
                MPH_Appointment_Cart::abandon_order($order);
                $order->update_status('failed','ساخت صورتحساب کامل نشد.');
                if ($file_id) wp_delete_attachment($file_id,true);
                MPH_Security::audit('checkout_failed','order='.$order->get_id().';code=checkout_build',$user->ID);
                return new WP_Error('mph_checkout','سفارش تکمیل نشد: '.$error->getMessage().' — سبد خرید محفوظ است.');
            }
        },120);
    }

    public static function pay($order,$gateway_id='') {
        if ($order->is_paid()) return self::response($order,'پرداخت قبلاً تأیید شده است.');
        if (!$order->needs_payment()) return new WP_Error('mph_order_state','این سفارش اکنون قابل پرداخت نیست.');
        if ($order->get_meta('_mph_payment_review')) return new WP_Error('mph_review','پرداخت نیازمند بررسی مدیر است؛ دوباره پرداخت نکنید.');
        if (MPH_Payment_Attempts::rows($order) && $order->get_payment_method()==='mph_zarinpal') $gateway_id='mph_zarinpal';
        $gateways=self::gateways();
        if (!$gateway_id) $gateway_id=key($gateways);
        if (!$gateway_id || !isset($gateways[$gateway_id])) return new WP_Error('mph_gateway','درگاه انتخابی در دسترس نیست؛ تنظیمات درگاه را بررسی کنید.');
        $order->set_payment_method($gateways[$gateway_id]);$order->save();
        $response=$gateways[$gateway_id]->process_payment($order->get_id());
        if (($response['result']??'')!=='success' || empty($response['redirect'])) return self::response($order,'درخواست درگاه کامل نشد؛ در صفحه نتیجه، وضعیت و امکان تلاش مجدد را بررسی کنید.');
        return array('message'=>'در حال انتقال به درگاه امن…','redirect'=>esc_url_raw($response['redirect']),'order_id'=>$order->get_id(),'cartStage'=>'payment');
    }

    public static function response($order,$message) {return array('message'=>$message,'order_id'=>$order->get_id(),'redirect'=>MPH_Payment_Result::url($order),'cartStage'=>'payment');}
}
