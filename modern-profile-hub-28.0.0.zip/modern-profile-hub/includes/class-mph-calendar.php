<?php
defined('ABSPATH') || exit;

final class MPH_Calendar {
    const POST_TYPE = 'mph_edu_event';
    const SYNC_HOOK = 'mph_calendar_sync_batch';
    const SYNC_STATE = 'mph_calendar_course_sync_state';

    public static function init() {
        add_action('init', array(__CLASS__, 'register_type'));
        add_action('init', array(__CLASS__, 'maybe_schedule_existing'), 99);
        add_action(self::SYNC_HOOK, array(__CLASS__, 'maybe_sync_existing'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
        add_action('admin_init', array(__CLASS__, 'save_admin'));
        add_action('save_post', array(__CLASS__, 'sync_saved_course'), 30, 3);
        add_action('before_delete_post', array(__CLASS__, 'delete_course_event'));
        add_action('wp_trash_post', array(__CLASS__, 'delete_course_event'));
        add_action('untrashed_post', array(__CLASS__, 'restore_course_event'));
        add_action('woocommerce_update_product', array(__CLASS__, 'sync_product_course'), 30);
        add_action('wp_ajax_mph_calendar_delete_event', array(__CLASS__, 'ajax_delete_event'));
        add_shortcode('mph_educational_calendar', array(__CLASS__, 'shortcode'));
        add_shortcode('تقویم_آموزشی', array(__CLASS__, 'shortcode'));
    }

    public static function register_type() {
        register_post_type(self::POST_TYPE, array('label' => 'رویدادهای آموزشی', 'public' => false, 'show_ui' => false, 'supports' => array('title', 'editor', 'author')));
    }

    public static function register_assets() {
        wp_register_style('mph-yekanbakh', MPH_URL . 'assets/css/yekanbakh.css', array(), MPH_VERSION);
        wp_register_style('mph-calendar-release', MPH_URL . 'assets/css/calendar-release.css', array('dashicons','mph-yekanbakh'), MPH_VERSION);
        wp_register_script('mph-calendar', MPH_URL . 'assets/js/calendar.js', array(), MPH_VERSION, true);
    }

    public static function shortcode($atts = array()) {
        wp_enqueue_style('dashicons');
        wp_enqueue_style('mph-calendar-release');
        wp_enqueue_script('mph-calendar');
        $atts = shortcode_atts(array('title' => 'تقویم آموزشی'), $atts, 'mph_educational_calendar');
        $events = self::events();
        $id = 'mph-calendar-' . wp_rand(1000, 999999);
        ob_start(); ?>
        <section id="<?php echo esc_attr($id); ?>" class="mph-edu-calendar" dir="rtl">
            <header class="mph-calendar-head">
                <div class="mph-calendar-brand"><span class="dashicons dashicons-calendar-alt"></span><div><small>برنامه‌ریزی آموزش</small><h2><?php echo esc_html($atts['title']); ?></h2><p data-calendar-current>کلاس‌ها، کارگاه‌ها و دوره‌های پیش‌رو</p></div></div>
                <div class="mph-calendar-head-side"><div class="mph-calendar-metrics"><span><b data-calendar-event-count>۰</b> رویداد</span><span><b data-calendar-occasion-count>۰</b> مناسبت</span></div><div class="mph-calendar-nav"><button type="button" data-calendar-prev aria-label="ماه قبل">‹</button><select data-calendar-month aria-label="انتخاب ماه"></select><select data-calendar-year aria-label="انتخاب سال"></select><button type="button" data-calendar-next aria-label="ماه بعد">›</button></div></div>
            </header>
            <div class="mph-calendar-legend"><span><i class="is-course"></i> دوره</span><span><i class="is-workshop"></i> کارگاه</span><span><i class="is-class"></i> کلاس</span><span><i class="is-holiday"></i> تعطیل رسمی/جمعه</span><button type="button" data-calendar-today>امروز</button></div>
            <div class="mph-calendar-layout">
                <div class="mph-calendar-board"><div class="mph-calendar-weekdays"><span>شنبه</span><span>یکشنبه</span><span>دوشنبه</span><span>سه‌شنبه</span><span>چهارشنبه</span><span>پنجشنبه</span><span>جمعه</span></div><div class="mph-calendar-grid" data-calendar-grid aria-live="polite"></div><div class="mph-calendar-empty" data-calendar-empty hidden>در این ماه رویداد آموزشی ثبت نشده است.</div></div>
                <aside class="mph-calendar-agenda"><header><div><small>برنامه ماه</small><h3>دوره‌ها و رویدادهای آموزشی</h3></div><span data-calendar-agenda-count>۰</span></header><div data-calendar-agenda></div></aside>
            </div>
            <div class="mph-calendar-event-popover" data-calendar-popover hidden></div>
            <div class="mph-occasion-columns">
                <section><header><span class="dashicons dashicons-flag"></span><h3>مناسبت‌های ملی</h3></header><ul data-national-occasions></ul></section>
                <section><header><span class="dashicons dashicons-admin-site-alt3"></span><h3>مناسبت‌های جهانی</h3></header><ul data-global-occasions></ul></section>
            </div>
            <script type="application/json" class="mph-calendar-data"><?php echo wp_json_encode(array(
                'events' => $events,
                'fallbackUrl' => MPH_Helpers::account_page_url(),
                'management' => self::can_delete_event() ? array(
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('mph_calendar_delete_event'),
                ) : null,
            ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
        </section>
        <?php return ob_get_clean();
    }

    public static function is_shortcode_page() {
        if (!is_singular()) return false;
        $post = get_queried_object();
        if (!($post instanceof WP_Post)) return false;
        $content = (string) $post->post_content;
        return has_shortcode($content, 'mph_educational_calendar') || has_shortcode($content, 'تقویم_آموزشی');
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) return;
        $events = get_posts(array('post_type' => self::POST_TYPE, 'post_status' => 'publish', 'numberposts' => 100, 'orderby' => 'meta_value', 'meta_key' => '_mph_event_jdate', 'order' => 'ASC'));
        $courses = self::courses();
        settings_errors('mph-calendar'); ?>
        <div class="wrap mph-admin" dir="rtl">
            <header class="mph-admin-head"><span class="dashicons dashicons-calendar-alt"></span><div><h1>تقویم آموزشی</h1><p>تعریف کلاس، کارگاه یا دوره برای نمایش در شورت‌کد تقویم</p></div></header>
            <div class="mph-admin-note"><b>شورت‌کد:</b> <code>[mph_educational_calendar]</code> <span>یا</span> <code>[تقویم_آموزشی]</code></div>
            <div class="mph-admin-split">
                <form method="post" class="mph-admin-box">
                    <?php wp_nonce_field('mph_calendar_admin', 'mph_calendar_nonce'); ?>
                    <h2>رویداد آموزشی جدید</h2>
                    <div class="mph-admin-grid">
                        <label>عنوان رویداد<input name="event_title" required placeholder="مثلاً کارگاه مدیریت فروش"></label>
                        <label>نوع<select name="event_type" required><option value="course">دوره</option><option value="workshop">کارگاه</option><option value="class">کلاس</option></select></label>
                        <label>تاریخ شمسی<input name="event_jdate" required placeholder="۱۴۰۵/۰۶/۲۰" dir="ltr"></label>
                        <label>اتصال به دوره موجود<select name="event_course"><option value="">بدون اتصال</option><?php foreach ($courses as $course) : ?><option value="<?php echo absint($course->ID); ?>"><?php echo esc_html($course->post_title); ?></option><?php endforeach; ?></select></label>
                        <label>لینک ثبت‌نام <small>(اختیاری)</small><input type="url" name="event_url" placeholder="https://..."></label>
                        <label>ساعت <small>(اختیاری)</small><input type="time" name="event_time"></label>
                    </div>
                    <label>توضیحات<textarea name="event_description" rows="4" placeholder="مدرس، مدت، ظرفیت یا توضیحات مهم"></textarea></label>
                    <button class="button button-primary" name="mph_save_event" value="1">افزودن به تقویم</button>
                </form>
                <section class="mph-admin-box">
                    <div class="mph-builder-head"><div><h2>رویدادهای ثبت‌شده</h2><p><?php echo count($events); ?> مورد</p></div></div>
                    <div class="mph-table-wrap"><table class="widefat striped"><thead><tr><th>عنوان</th><th>نوع</th><th>تاریخ</th><th>ساعت</th><th>عملیات</th></tr></thead><tbody>
                    <?php if (!$events) : ?><tr><td colspan="5">هنوز رویدادی ثبت نشده است.</td></tr><?php endif; ?>
                    <?php foreach ($events as $event) : ?><tr><td><b><?php echo esc_html($event->post_title); ?></b><?php if(get_post_meta($event->ID,'_mph_event_auto',true)==='yes'): ?> <small class="mph-status">خودکار</small><?php endif; ?></td><td><?php echo esc_html(self::type_label(get_post_meta($event->ID, '_mph_event_type', true))); ?></td><td dir="ltr"><?php echo esc_html(get_post_meta($event->ID, '_mph_event_jdate', true)); ?></td><td><?php echo esc_html(get_post_meta($event->ID, '_mph_event_time', true) ?: '—'); ?></td><td><?php if(self::can_delete_event()): ?><form method="post" class="mph-inline-form" onsubmit="return confirm('فقط از تقویم حذف شود؟ اصل دوره باقی می‌ماند.')"><?php wp_nonce_field('mph_calendar_admin', 'mph_calendar_nonce'); ?><button class="button-link-delete" name="mph_delete_event" value="<?php echo absint($event->ID); ?>">حذف فقط از تقویم</button></form><?php else: ?><span aria-label="فقط سوپرادمین مجاز است">—</span><?php endif; ?></td></tr><?php endforeach; ?>
                    </tbody></table></div>
                </section>
            </div>
        </div><?php
    }

    public static function save_admin() {
        if (!current_user_can('manage_options') || empty($_POST['mph_calendar_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mph_calendar_nonce'])), 'mph_calendar_admin')) return;
        if (isset($_POST['mph_delete_event'])) {
            $id = absint($_POST['mph_delete_event']);
            if (!self::can_delete_event()) {add_settings_error('mph-calendar', 'forbidden', 'فقط سوپرادمین اجازه حذف از تقویم را دارد.', 'error');return;}
            if (self::delete_event_only($id)) add_settings_error('mph-calendar', 'deleted', 'رویداد فقط از تقویم آموزشی حذف شد؛ اصل دوره باقی است.', 'success');
            else add_settings_error('mph-calendar', 'missing', 'رویداد معتبر پیدا نشد.', 'error');
            return;
        }
        if (!isset($_POST['mph_save_event'])) return;
        $title = MPH_Helpers::posted('event_title');
        $type = MPH_Helpers::posted('event_type', 'key');
        $jdate = self::normalize_jdate(MPH_Helpers::posted('event_jdate'));
        if (!$title || !in_array($type, array('course', 'workshop', 'class'), true) || !$jdate) {add_settings_error('mph-calendar', 'invalid', 'عنوان، نوع و تاریخ شمسی معتبر را وارد کنید.', 'error');return;}
        $course_id = absint($_POST['event_course'] ?? 0);
        $url = esc_url_raw(MPH_Helpers::posted('event_url'));
        if (!$url && $course_id) $url = get_permalink($course_id);
        $id = wp_insert_post(array('post_type' => self::POST_TYPE, 'post_status' => 'publish', 'post_title' => $title, 'post_content' => MPH_Helpers::posted('event_description', 'textarea'), 'post_author' => get_current_user_id()));
        if (is_wp_error($id) || !$id) {add_settings_error('mph-calendar', 'failed', 'ثبت رویداد انجام نشد.', 'error');return;}
        update_post_meta($id, '_mph_event_type', $type);
        update_post_meta($id, '_mph_event_jdate', $jdate);
        update_post_meta($id, '_mph_event_course_id', $course_id);
        update_post_meta($id, '_mph_event_url', $url);
        update_post_meta($id, '_mph_event_time', preg_replace('/[^0-9:]/', '', MPH_Helpers::posted('event_time')));
        if ($course_id) delete_post_meta($course_id, '_mph_calendar_hidden');
        add_settings_error('mph-calendar', 'saved', 'رویداد به تقویم اضافه شد.', 'success');
    }

    public static function ajax_delete_event() {
        check_ajax_referer('mph_calendar_delete_event', 'nonce');
        if (!self::can_delete_event()) wp_send_json_error(array('message'=>'فقط سوپرادمین اجازه حذف از تقویم را دارد.'), 403);
        $event_id = absint($_POST['event_id'] ?? 0);
        $course_id = absint(get_post_meta($event_id, '_mph_event_course_id', true));
        if (!self::delete_event_only($event_id)) wp_send_json_error(array('message'=>'رویداد آموزشی معتبر پیدا نشد.'), 404);
        MPH_Security::audit('calendar_event_removed', 'event='.$event_id.';calendar_only=1');
        wp_send_json_success(array('message'=>'رویداد فقط از تقویم آموزشی حذف شد و اصل دوره دست‌نخورده باقی ماند.','eventId'=>$event_id,'courseId'=>$course_id));
    }

    public static function maybe_schedule_existing() {
        if (!MPH_Tutor::active() || get_option('mph_calendar_course_sync_version') === MPH_VERSION) return;
        if (!wp_next_scheduled(self::SYNC_HOOK)) wp_schedule_single_event(time() + 15, self::SYNC_HOOK);
    }

    /** همگام‌سازی دوره‌های قدیمی در دسته‌های کوچک و بدون فشار روی درخواست کاربر. */
    public static function maybe_sync_existing() {
        if (!MPH_Tutor::active() || get_option('mph_calendar_course_sync_version') === MPH_VERSION) return;
        global $wpdb;
        $state = get_option(self::SYNC_STATE, array());
        if (!is_array($state) || ($state['version'] ?? '') !== MPH_VERSION) $state = array('version'=>MPH_VERSION, 'cursor'=>0);
        $cursor = absint($state['cursor'] ?? 0);
        $post_type = sanitize_key(tutor()->course_post_type);
        $limit = 20;
        $courses = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE ID > %d AND post_type = %s AND post_status IN ('publish','draft','pending','trash') ORDER BY ID ASC LIMIT %d",
            $cursor,
            $post_type,
            $limit
        ));
        foreach ((array)$courses as $course_id) self::sync_course(absint($course_id));
        if (count((array)$courses) < $limit) {
            update_option('mph_calendar_course_sync_version', MPH_VERSION, false);
            delete_option(self::SYNC_STATE);
            return;
        }
        update_option(self::SYNC_STATE, array('version'=>MPH_VERSION, 'cursor'=>absint(end($courses))), false);
        if (!wp_next_scheduled(self::SYNC_HOOK)) wp_schedule_single_event(time() + 15, self::SYNC_HOOK);
    }

    public static function sync_saved_course($post_id, $post, $update) {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id) || !MPH_Tutor::active()) return;
        if (!$post instanceof WP_Post || $post->post_type !== tutor()->course_post_type) return;
        self::sync_course($post_id);
    }

    public static function sync_product_course($product_id) {
        if (!class_exists('MPH_Courses')) return;
        $course_id = absint(get_post_meta($product_id, MPH_Courses::COURSE_META, true));
        if ($course_id) self::sync_course($course_id);
    }

    public static function delete_course_event($post_id) {
        if (!MPH_Tutor::active() || get_post_type($post_id) !== tutor()->course_post_type) return;
        self::delete_linked_events($post_id);
    }

    public static function restore_course_event($post_id) {
        if (!MPH_Tutor::active() || get_post_type($post_id) !== tutor()->course_post_type) return;
        self::sync_course($post_id);
    }

    public static function sync_course($course_id) {
        $course_id = absint($course_id);
        if (!$course_id || !MPH_Tutor::active()) return false;
        $course = get_post($course_id);
        if (get_post_meta($course_id, '_mph_calendar_hidden', true) === 'yes') {
            self::delete_linked_events($course_id);
            return false;
        }
        if (!$course || $course->post_type !== tutor()->course_post_type || $course->post_status !== 'publish') {
            self::delete_linked_events($course_id);
            return false;
        }
        $schedule = self::course_schedule($course);
        if (!$schedule['date']) return false;
        $existing = get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'any','numberposts'=>-1,'fields'=>'ids','meta_key'=>'_mph_event_course_id','meta_value'=>$course_id,'orderby'=>'ID','order'=>'ASC'));
        $event_id = absint($existing[0] ?? 0);
        $payload = array(
            'post_type'=>self::POST_TYPE,
            'post_status'=>'publish',
            'post_title'=>$course->post_title,
            'post_content'=>$course->post_excerpt ?: wp_trim_words(wp_strip_all_tags($course->post_content), 32),
            'post_author'=>$course->post_author ?: get_current_user_id(),
        );
        if ($event_id) $payload['ID'] = $event_id;
        $saved = $event_id ? wp_update_post($payload, true) : wp_insert_post($payload, true);
        if (is_wp_error($saved) || !$saved) return false;
        $event_id = absint($saved);
        update_post_meta($event_id, '_mph_event_type', 'course');
        update_post_meta($event_id, '_mph_event_jdate', $schedule['date']);
        update_post_meta($event_id, '_mph_event_time', $schedule['time']);
        update_post_meta($event_id, '_mph_event_course_id', $course_id);
        update_post_meta($event_id, '_mph_event_url', get_permalink($course_id) ?: MPH_Helpers::account_page_url());
        update_post_meta($event_id, '_mph_event_auto', 'yes');
        foreach (array_slice($existing, 1) as $duplicate_id) wp_delete_post(absint($duplicate_id), true);
        return $event_id;
    }

    private static function delete_linked_events($course_id) {
        $events = get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'any','numberposts'=>-1,'fields'=>'ids','meta_key'=>'_mph_event_course_id','meta_value'=>absint($course_id)));
        foreach ($events as $event_id) wp_delete_post(absint($event_id), true);
    }

    private static function can_delete_event() {
        return is_user_logged_in() && is_super_admin(get_current_user_id());
    }

    private static function delete_event_only($event_id) {
        $event_id = absint($event_id);
        if (!$event_id || get_post_type($event_id) !== self::POST_TYPE) return false;
        $course_id = absint(get_post_meta($event_id, '_mph_event_course_id', true));
        if ($course_id) {
            update_post_meta($course_id, '_mph_calendar_hidden', 'yes');
            self::delete_linked_events($course_id);
            return true;
        }
        return (bool) wp_delete_post($event_id, true);
    }

    private static function course_schedule($course) {
        $date = trim((string) get_post_meta($course->ID, '_mph_course_calendar_date', true));
        $time = preg_replace('/[^0-9:]/', '', (string) get_post_meta($course->ID, '_mph_course_calendar_time', true));
        $start = '';
        if (class_exists('MPH_Courses') && function_exists('wc_get_product')) {
            $map = (array) get_post_meta($course->ID, MPH_Courses::PRODUCTS_META, true);
            $product = !empty($map['inperson']) ? wc_get_product(absint($map['inperson'])) : false;
            if ($product) $start = trim((string) $product->get_meta('_mph_inperson_start'));
        }
        if (!$date && $start) $date = substr($start, 0, 10);
        if (!$time && $start) $time = substr($start, 11, 5);
        if (!$date) $date = get_post_time('Y-m-d', false, $course);
        if (!$time) $time = get_post_time('H:i', false, $course);
        if (preg_match('/^14\d{2}[\/-]\d{1,2}[\/-]\d{1,2}$/', $date)) $jdate = self::normalize_jdate($date);
        elseif (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $date, $match)) {
            $jalali = self::gregorian_to_jalali(absint($match[1]), absint($match[2]), absint($match[3]));
            $jdate = sprintf('%04d/%02d/%02d', $jalali[0], $jalali[1], $jalali[2]);
        } else $jdate = '';
        return array('date'=>$jdate,'time'=>preg_match('/^\d{2}:\d{2}$/',$time)?$time:'');
    }

    private static function gregorian_to_jalali($gy, $gm, $gd) {
        $gdm=array(0,31,59,90,120,151,181,212,243,273,304,334);
        $gy2=$gm>2?$gy+1:$gy;
        $days=355666+(365*$gy)+(int)floor(($gy2+3)/4)-(int)floor(($gy2+99)/100)+(int)floor(($gy2+399)/400)+$gd+$gdm[$gm-1];
        $jy=-1595+33*(int)floor($days/12053);$days%=12053;
        $jy+=4*(int)floor($days/1461);$days%=1461;
        if($days>365){$jy+=(int)floor(($days-1)/365);$days=($days-1)%365;}
        if($days<186){$jm=1+(int)floor($days/31);$jd=1+($days%31);}else{$jm=7+(int)floor(($days-186)/30);$jd=1+(($days-186)%30);}
        return array($jy,$jm,$jd);
    }

    private static function events() {
        $posts = get_posts(array('post_type' => self::POST_TYPE, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'meta_value', 'meta_key' => '_mph_event_jdate', 'order' => 'ASC'));
        $events = array();
        foreach ($posts as $post) {
            $course_id = absint(get_post_meta($post->ID, '_mph_event_course_id', true));
            $url = get_post_meta($post->ID, '_mph_event_url', true);
            if (!$url && $course_id) $url = get_permalink($course_id);
            $events[] = array(
                'id' => $post->ID,
                'courseId' => $course_id,
                'title' => $post->post_title,
                'description' => wp_strip_all_tags($post->post_content),
                'date' => get_post_meta($post->ID, '_mph_event_jdate', true),
                'time' => get_post_meta($post->ID, '_mph_event_time', true),
                'type' => get_post_meta($post->ID, '_mph_event_type', true) ?: 'course',
                'typeLabel' => self::type_label(get_post_meta($post->ID, '_mph_event_type', true)),
                'url' => $url ?: MPH_Helpers::account_page_url(),
            );
        }
        return $events;
    }

    private static function courses() {
        if (!MPH_Tutor::active()) return array();
        return get_posts(array('post_type' => tutor()->course_post_type, 'post_status' => array('publish', 'draft', 'pending'), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC'));
    }

    private static function normalize_jdate($date) {
        $date = strtr((string) $date, array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','-'=>'/'));
        if (!preg_match('/^(14\d{2})\/(\d{1,2})\/(\d{1,2})$/', $date, $m)) return '';
        $year = absint($m[1]);$month=absint($m[2]);$day=absint($m[3]);
        if ($year < 1400 || $year > 1500 || $month < 1 || $month > 12) return '';
        $leap = self::is_jalali_leap($year);
        $max = $month <= 6 ? 31 : ($month <= 11 ? 30 : ($leap ? 30 : 29));
        if ($day < 1 || $day > $max) return '';
        return sprintf('%04d/%02d/%02d', $year, $month, $day);
    }

    private static function is_jalali_leap($year) {
        $a = self::jalali_to_gregorian($year, 1, 1);
        $b = self::jalali_to_gregorian($year + 1, 1, 1);
        $first = gmmktime(0, 0, 0, $a[1], $a[2], $a[0]);
        $next = gmmktime(0, 0, 0, $b[1], $b[2], $b[0]);
        return (($next - $first) / DAY_IN_SECONDS) === 366.0;
    }

    private static function jalali_to_gregorian($jy, $jm, $jd) {
        $jy += 1595;
        $days = -355668 + (365 * $jy) + (int) floor($jy / 33) * 8 + (int) floor((($jy % 33) + 3) / 4) + $jd;
        $days += $jm < 7 ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186;
        $gy = 400 * (int) floor($days / 146097);$days %= 146097;
        if ($days > 36524) {$gy += 100 * (int) floor(--$days / 36524);$days %= 36524;if ($days >= 365) $days++;}
        $gy += 4 * (int) floor($days / 1461);$days %= 1461;
        if ($days > 365) {$gy += (int) floor(($days - 1) / 365);$days = ($days - 1) % 365;}
        $gd = $days + 1;$sal = array(0,31,(($gy % 4 === 0 && $gy % 100 !== 0) || $gy % 400 === 0) ? 29 : 28,31,30,31,30,31,31,30,31,30,31);$gm = 1;
        while ($gm <= 12 && $gd > $sal[$gm]) {$gd -= $sal[$gm];$gm++;}
        return array($gy,$gm,$gd);
    }

    private static function type_label($type) {$labels=array('course'=>'دوره','workshop'=>'کارگاه','class'=>'کلاس');return $labels[$type]??'دوره';}
}
