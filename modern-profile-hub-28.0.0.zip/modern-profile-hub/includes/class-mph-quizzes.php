<?php
defined('ABSPATH') || exit;

/**
 * ویرایشگر فارسی و درون‌صفحه‌ای آزمون‌های Tutor LMS.
 * آزمون به‌صورت tutor_quiz و سؤال/پاسخ در جدول‌های رسمی Tutor نگهداری می‌شود.
 */
final class MPH_Quizzes {
    const SCORE_MODE_META = '_mph_quiz_score_mode_v26';
    const MAX_SCORE_META = '_mph_quiz_max_score_v26';

    public static function init() {
        add_action('wp_ajax_mph_quiz_create', array(__CLASS__, 'ajax_create'));
        add_action('wp_ajax_mph_quiz_save', array(__CLASS__, 'ajax_save'));
        add_action('wp_ajax_mph_quiz_editor', array(__CLASS__, 'ajax_editor'));
        add_action('wp_ajax_mph_quiz_question_save', array(__CLASS__, 'ajax_question_save'));
        add_action('wp_ajax_mph_quiz_question_delete', array(__CLASS__, 'ajax_question_delete'));
        add_action('wp_ajax_mph_quiz_question_move', array(__CLASS__, 'ajax_question_move'));
        add_action('wp_ajax_mph_quiz_attempts', array(__CLASS__, 'ajax_attempts'));
        add_action('wp_ajax_mph_quiz_review_open', array(__CLASS__, 'ajax_review_open'));
        add_action('wp_ajax_mph_quiz_review_save', array(__CLASS__, 'ajax_review_save'));
    }

    public static function render() {
        if (!self::can_teach()) return '<div class="mph-empty">دسترسی مدرس ندارید.</div>';
        if (!MPH_Tutor::active()) return '<div class="mph-empty mph-tutor-warning"><p>برای مدیریت آزمون‌ها Tutor LMS را فعال کنید.</p></div>';
        if (!self::tables_ready()) return '<div class="mph-empty mph-tutor-warning"><p>جدول سؤال‌های Tutor پیدا نشد. یک‌بار Tutor LMS را غیرفعال و دوباره فعال کنید.</p></div>';
        $quizzes = self::quizzes();
        $courses = self::courses();
        $attempt_counts = self::attempt_counts(wp_list_pluck($quizzes, 'ID'));
        ob_start(); ?>
        <section class="mph-section mph-quizzes">
            <div class="mph-section-heading">
                <div><h3>مدیریت آزمون‌ها</h3><p>ساخت آزمون و ویرایش سؤال‌ها بدون خروج از کارتابل مدرس</p></div>
                <button type="button" class="mph-primary" data-toggle-quiz-form><span class="dashicons dashicons-plus-alt2"></span> آزمون جدید</button>
            </div>
            <form class="mph-form mph-quiz-form" data-quiz-form data-mph-action="mph_quiz_create" hidden>
                <?php echo self::quiz_fields(null, $courses); ?>
                <button class="mph-primary" type="submit">ساخت آزمون و ورود به ویرایشگر</button><div class="mph-message"></div>
            </form>
            <div class="mph-quiz-filters"><button type="button" class="is-active" data-quiz-filter="all">همه</button><button type="button" data-quiz-filter="past">گذشته</button><button type="button" data-quiz-filter="current">در حال برگزاری</button><button type="button" data-quiz-filter="future">آینده</button></div>
            <div class="mph-tutor-table"><table><thead><tr><th>آزمون</th><th>دوره</th><th>زمان برگزاری</th><th>وضعیت</th><th>شرکت‌کنندگان</th><th>عملیات</th></tr></thead><tbody>
            <?php if (!$quizzes): ?><tr><td colspan="6">آزمونی برای دوره‌های شما وجود ندارد.</td></tr><?php endif; ?>
            <?php foreach ($quizzes as $quiz): $status=self::status($quiz);$attempts=absint($attempt_counts[$quiz->ID]??0); ?>
                <tr data-quiz-row="<?php echo esc_attr($status); ?>"><td><b><?php echo esc_html($quiz->post_title); ?></b><small><?php echo self::question_count($quiz->ID); ?> سؤال</small></td><td><?php echo esc_html(get_the_title(self::course_id($quiz))); ?></td><td><?php echo esc_html(self::schedule($quiz)); ?></td><td><span class="mph-quiz-status is-<?php echo esc_attr($status); ?>"><?php echo esc_html(self::status_label($status)); ?></span></td><td><?php echo absint($attempts); ?> نفر</td><td><div class="mph-table-actions">
                    <?php if ($attempts>0): ?><form data-mph-action="mph_quiz_attempts"><input type="hidden" name="quiz_id" value="<?php echo absint($quiz->ID); ?>"><button class="mph-secondary" type="submit">بررسی نتایج و نمره‌دهی</button><div class="mph-message"></div></form><?php endif; ?>
                    <form data-mph-action="mph_quiz_editor"><input type="hidden" name="quiz_id" value="<?php echo absint($quiz->ID); ?>"><button class="mph-primary mph-quiz-edit-button" type="submit"><span class="dashicons dashicons-edit"></span> ویرایش آزمون و سؤال‌ها</button><div class="mph-message"></div></form>
                </div></td></tr>
            <?php endforeach; ?></tbody></table></div>
            <div class="mph-quiz-note"><span class="dashicons dashicons-database"></span><p>این رابط داخل افزونه اجرا می‌شود؛ آزمون، سؤال‌ها، پاسخ‌ها و تنظیمات همچنان در ساختار داده Tutor LMS ذخیره می‌شوند.</p></div>
        </section><?php
        return ob_get_clean();
    }

    private static function quiz_fields($quiz, $courses) {
        $settings = $quiz ? self::quiz_settings($quiz->ID) : self::default_settings();
        $course_id = $quiz ? self::course_id($quiz) : 0;
        $start = $quiz ? self::input_datetime(get_post_meta($quiz->ID, '_mph_quiz_start', true)) : '';
        $end = $quiz ? self::input_datetime(get_post_meta($quiz->ID, '_mph_quiz_end', true)) : '';
        $time = $settings['time_limit']['time_value'] ?? 30;
        $time_type = $settings['time_limit']['time_type'] ?? 'minutes';
        $score_mode = $quiz ? self::score_mode($quiz->ID) : 'percent';
        $max_score = $quiz ? self::max_score($quiz->ID) : 20;
        ob_start(); ?>
        <?php if($quiz): ?><input type="hidden" name="quiz_id" value="<?php echo absint($quiz->ID); ?>"><?php endif; ?>
        <div class="mph-field-grid"><label><?php echo MPH_Helpers::required('عنوان آزمون'); ?><input name="quiz_title" value="<?php echo esc_attr($quiz?$quiz->post_title:''); ?>" maxlength="200" required></label><label><?php echo MPH_Helpers::required('دوره'); ?><select name="quiz_course" required><option value="">انتخاب دوره</option><?php foreach($courses as$course): ?><option value="<?php echo absint($course->ID); ?>" <?php selected($course_id,$course->ID); ?>><?php echo esc_html($course->post_title); ?></option><?php endforeach; ?></select></label></div>
        <label>توضیحات آزمون<textarea name="quiz_description" rows="3"><?php echo esc_textarea($quiz?$quiz->post_content:''); ?></textarea></label>
        <div class="mph-field-grid"><label>شروع آزمون<input type="datetime-local" name="quiz_start" value="<?php echo esc_attr($start); ?>"></label><label>پایان آزمون<input type="datetime-local" name="quiz_end" value="<?php echo esc_attr($end); ?>"></label></div>
        <div class="mph-quiz-advanced">
            <label>مقدار زمان<input type="number" name="quiz_time" min="0" value="<?php echo esc_attr($time); ?>"></label>
            <label>واحد زمان<select name="quiz_time_type"><option value="minutes" <?php selected($time_type,'minutes'); ?>>دقیقه</option><option value="hours" <?php selected($time_type,'hours'); ?>>ساعت</option><option value="days" <?php selected($time_type,'days'); ?>>روز</option><option value="weeks" <?php selected($time_type,'weeks'); ?>>هفته</option></select></label>
            <label>تعداد تلاش<input type="number" name="quiz_attempts" min="0" value="<?php echo esc_attr($settings['attempts_allowed']??1); ?>"><small>صفر یعنی بدون محدودیت</small></label>
            <label>نمره قبولی (درصد)<input type="number" name="quiz_pass" min="0" max="100" value="<?php echo esc_attr($settings['passing_grade']??60); ?>"></label>
            <label>حداکثر سؤال برای پاسخ<input type="number" name="quiz_max_questions" min="0" value="<?php echo esc_attr($settings['max_questions_for_answer']??10); ?>"><small>صفر یعنی همه سؤال‌ها</small></label>
            <label>ترتیب سؤال‌ها<select name="quiz_order"><option value="rand" <?php selected($settings['questions_order']??'rand','rand'); ?>>تصادفی</option><option value="sort_asc" <?php selected($settings['questions_order']??'rand','sort_asc'); ?>>ترتیب ساخته‌شده</option><option value="sort_desc" <?php selected($settings['questions_order']??'rand','sort_desc'); ?>>ترتیب معکوس</option></select></label>
            <label>بازخورد پاسخ<select name="quiz_feedback"><option value="default" <?php selected($settings['feedback_mode']??'default','default'); ?>>پیش‌فرض</option><option value="retry" <?php selected($settings['feedback_mode']??'default','retry'); ?>>امکان تلاش دوباره</option><option value="reveal" <?php selected($settings['feedback_mode']??'default','reveal'); ?>>نمایش پاسخ صحیح</option></select></label>
            <label>حداکثر نویسه پاسخ کوتاه<input type="number" name="quiz_short_limit" min="20" value="<?php echo esc_attr($settings['short_answer_characters_limit']??200); ?>"></label>
            <label>حداکثر نویسه پاسخ تشریحی<input type="number" name="quiz_open_limit" min="50" value="<?php echo esc_attr($settings['open_ended_answer_characters_limit']??500); ?>"></label>
        </div>
        <div class="mph-quiz-checks"><label><input type="checkbox" name="quiz_auto_start" value="1" <?php checked(!empty($settings['quiz_auto_start'])); ?>> شروع خودکار آزمون</label><label><input type="checkbox" name="quiz_hide_time" value="1" <?php checked(!empty($settings['hide_quiz_time_display'])); ?>> مخفی‌کردن زمان آزمون</label></div>
        <fieldset class="mph-quiz-score-mode" data-quiz-score-mode>
            <legend><?php echo MPH_Helpers::required('روش محاسبه نمره'); ?></legend>
            <p>فقط یکی از دو روش برای این آزمون اجرا می‌شود.</p>
            <div class="mph-quiz-checks">
                <label><input type="radio" name="quiz_score_mode" value="percent" <?php checked($score_mode,'percent'); ?>> درصد از ۱۰۰</label>
                <label><input type="radio" name="quiz_score_mode" value="points" <?php checked($score_mode,'points'); ?>> نمره عددی با سقف دلخواه</label>
            </div>
            <label class="mph-quiz-max-score">سقف نمره عددی<input type="number" name="quiz_max_score" min="0.01" max="100000" step="0.01" value="<?php echo esc_attr(self::number($max_score)); ?>" <?php disabled($score_mode!=='points'); ?>><small>در حالت درصدی، سقف به‌صورت ثابت ۱۰۰ است.</small></label>
        </fieldset>
        <?php return ob_get_clean();
    }

    private static function editor($quiz) {
        $questions = self::questions($quiz->ID);
        ob_start(); ?>
        <section class="mph-section mph-quiz-editor" data-quiz-editor="<?php echo absint($quiz->ID); ?>">
            <div class="mph-section-heading"><div><h3>ویرایش آزمون: <?php echo esc_html($quiz->post_title); ?></h3><p>تنظیمات و سؤال‌ها در همین صفحه ذخیره می‌شوند.</p></div><button type="button" class="mph-secondary" data-panel="teacher_exams"><span class="dashicons dashicons-arrow-right-alt"></span> بازگشت به آزمون‌ها</button></div>
            <div class="mph-quiz-settings"><details><summary>تنظیمات کامل آزمون</summary><form class="mph-form" data-mph-action="mph_quiz_save"><?php echo self::quiz_fields($quiz,self::courses()); ?><button class="mph-primary" type="submit">ذخیره تنظیمات آزمون</button><div class="mph-message"></div></form></details></div>
            <div class="mph-question-toolbar"><div><h3>سؤال‌های آزمون</h3><p><?php echo count($questions); ?> سؤال ثبت شده است.</p></div><button type="button" class="mph-primary" data-new-question><span class="dashicons dashicons-plus-alt2"></span> سؤال جدید</button></div>
            <article class="mph-question-card mph-new-question-card" data-question-card hidden><?php echo self::question_form($quiz->ID,null); ?></article>
            <div class="mph-question-list">
                <?php if(!$questions): ?><div class="mph-question-empty"><span class="dashicons dashicons-editor-help"></span><p>هنوز سؤالی ساخته نشده است؛ «سؤال جدید» را بزنید.</p></div><?php endif; ?>
                <?php foreach($questions as$index=>$question): ?><article class="mph-question-card" data-question-card data-question-id="<?php echo absint($question->question_id); ?>"><div class="mph-question-summary"><span class="mph-question-number"><?php echo $index+1; ?></span><div><h4><?php echo esc_html($question->question_title); ?></h4><small><?php echo esc_html(self::type_label($question->question_type)); ?> · <?php echo esc_html(self::number($question->question_mark)); ?> نمره</small></div><div class="mph-question-actions"><button type="button" class="mph-secondary" data-edit-question>ویرایش</button><form data-mph-action="mph_quiz_question_move"><input type="hidden" name="quiz_id" value="<?php echo absint($quiz->ID); ?>"><input type="hidden" name="question_id" value="<?php echo absint($question->question_id); ?>"><button type="submit" name="direction" value="up" class="mph-secondary" title="بالا">↑</button><button type="submit" name="direction" value="down" class="mph-secondary" title="پایین">↓</button><div class="mph-message"></div></form><form data-mph-action="mph_quiz_question_delete" data-confirm="این سؤال و پاسخ‌های آن حذف شود؟"><input type="hidden" name="quiz_id" value="<?php echo absint($quiz->ID); ?>"><input type="hidden" name="question_id" value="<?php echo absint($question->question_id); ?>"><button class="mph-danger" type="submit">حذف</button><div class="mph-message"></div></form></div></div><?php echo self::question_form($quiz->ID,$question); ?></article><?php endforeach; ?>
            </div>
        </section><?php return ob_get_clean();
    }

    private static function question_form($quiz_id, $question=null) {
        $question_id=$question?absint($question->question_id):0;$type=$question?$question->question_type:'single_choice';$settings=$question?maybe_unserialize($question->question_settings):array();if(!is_array($settings))$settings=array();$answers=$question?self::answers($question_id):array();if(!$answers&&$type==='true_false')$answers=array((object)array('answer_id'=>0,'answer_title'=>'درست','is_correct'=>1,'answer_two_gap_match'=>'','image_id'=>0),(object)array('answer_id'=>0,'answer_title'=>'نادرست','is_correct'=>0,'answer_two_gap_match'=>'','image_id'=>0));
        ob_start(); ?><form class="mph-form mph-question-editor-form" data-mph-action="mph_quiz_question_save"><input type="hidden" name="quiz_id" value="<?php echo absint($quiz_id); ?>"><input type="hidden" name="question_id" value="<?php echo $question_id; ?>"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('متن سؤال'); ?><input name="question_title" value="<?php echo esc_attr($question?$question->question_title:''); ?>" maxlength="1000" required></label><label><?php echo MPH_Helpers::required('نوع سؤال'); ?><select name="question_type" data-question-type><?php foreach(self::types()as$key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($type,$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label></div><label>توضیحات سؤال<textarea name="question_description" rows="3"><?php echo esc_textarea($question?$question->question_description:''); ?></textarea></label><div class="mph-field-grid"><label>نمره سؤال<input type="number" name="question_mark" min="0" step="0.01" value="<?php echo esc_attr($question?self::number($question->question_mark):1); ?>"></label><label>توضیح پاسخ صحیح<textarea name="answer_explanation" rows="2"><?php echo esc_textarea($question?$question->answer_explanation:''); ?></textarea></label></div><div class="mph-quiz-checks"><label><input type="checkbox" name="answer_required" value="1" <?php checked(!isset($settings['answer_required'])||!empty($settings['answer_required'])); ?>> پاسخ الزامی</label><label><input type="checkbox" name="randomize_answers" value="1" <?php checked(!empty($settings['randomize_question'])); ?>> ترتیب تصادفی پاسخ‌ها</label></div><div class="mph-question-answers" data-question-answers><div class="mph-builder-head"><div><h4>پاسخ‌ها و گزینه‌ها</h4><p data-answer-help>گزینه‌ها را وارد و پاسخ صحیح را مشخص کنید.</p></div><button type="button" class="mph-secondary" data-add-answer>＋ افزودن پاسخ</button></div><div class="mph-question-answer-list" data-answer-list><?php foreach($answers as$n=>$answer)echo self::answer_row($n,$answer,$type); ?></div></div><div class="mph-question-form-actions"><button class="mph-primary" type="submit"><?php echo $question?'ذخیره تغییرات سؤال':'افزودن سؤال'; ?></button><button type="button" class="mph-secondary" data-cancel-question>انصراف</button></div><div class="mph-message"></div></form><?php return ob_get_clean();
    }

    private static function answer_row($index,$answer,$type) {
        $image_id=absint($answer->image_id??0);$image=$image_id?wp_get_attachment_image_url($image_id,'thumbnail'):'';
        ob_start(); ?><div class="mph-question-answer" data-answer-row><span class="mph-answer-order"><?php echo $index+1; ?></span><input type="hidden" name="answer_id[<?php echo $index; ?>]" value="<?php echo absint($answer->answer_id??0); ?>"><input type="text" name="answer_title[<?php echo $index; ?>]" value="<?php echo esc_attr($answer->answer_title??''); ?>" placeholder="متن پاسخ"><input class="mph-answer-match" type="text" name="answer_match[<?php echo $index; ?>]" value="<?php echo esc_attr($answer->answer_two_gap_match??''); ?>" placeholder="جفت متناظر / جواب‌های مجاز"><label class="mph-answer-correct"><input type="checkbox" name="answer_correct[<?php echo $index; ?>]" value="1" <?php checked(!empty($answer->is_correct)); ?>> پاسخ صحیح</label><span class="mph-answer-image"><input type="hidden" name="answer_image[<?php echo $index; ?>]" value="<?php echo $image_id; ?>" data-answer-image-id><span data-answer-image-preview><?php if($image): ?><img src="<?php echo esc_url($image); ?>" alt=""><?php endif; ?></span><button type="button" class="mph-secondary" data-answer-media>تصویر</button></span><button type="button" class="mph-danger" data-remove-answer>×</button></div><?php return ob_get_clean();
    }

    public static function ajax_create(){self::save_quiz(false);}
    public static function ajax_save(){self::save_quiz(true);}
    private static function save_quiz($editing) {
        MPH_Helpers::verify_ajax();nocache_headers();
        if(!self::can_teach()||!MPH_Tutor::active())wp_send_json_error(array('message'=>'Tutor LMS یا دسترسی مدرس موجود نیست.'),403);
        $quiz_id=absint($_POST['quiz_id']??0);$quiz=$quiz_id?get_post($quiz_id):null;
        if($quiz_id&&!self::owns_quiz($quiz))wp_send_json_error(array('message'=>'آزمون معتبر نیست یا دسترسی ویرایش ندارید.'),403);
        $title=MPH_Helpers::posted('quiz_title');$course_id=absint($_POST['quiz_course']??0);
        if(!$title||!self::owns_course($course_id))wp_send_json_error(array('message'=>'عنوان و دوره معتبر را انتخاب کنید.'));
        $score_mode=MPH_Helpers::posted('quiz_score_mode','key');if(!in_array($score_mode,array('percent','points'),true))$score_mode='percent';
        $max_score=(float)($_POST['quiz_max_score']??20);if($score_mode==='points'&&($max_score<=0||$max_score>100000))wp_send_json_error(array('message'=>'سقف نمره عددی باید بیشتر از صفر و حداکثر ۱۰۰٬۰۰۰ باشد.'));
        $topic=self::ensure_topic($course_id);if(!$topic)wp_send_json_error(array('message'=>'ساخت سرفصل آزمون در Tutor انجام نشد.'));
        $post_data=array('post_type'=>self::quiz_post_type(),'post_status'=>'publish','post_parent'=>$topic,'post_author'=>$quiz?$quiz->post_author:get_current_user_id(),'post_title'=>$title,'post_content'=>MPH_Helpers::posted('quiz_description','textarea'));
        if($quiz){$post_data['ID']=$quiz_id;$saved=wp_update_post($post_data,true);}else{$saved=wp_insert_post($post_data,true);}
        if(is_wp_error($saved)||!$saved)wp_send_json_error(array('message'=>is_wp_error($saved)?$saved->get_error_message():'ذخیره آزمون انجام نشد.'));
        $quiz_id=absint($saved);$settings=self::posted_settings();update_post_meta($quiz_id,'tutor_quiz_option',$settings);update_post_meta($quiz_id,'_tutor_quiz_settings',$settings);
        update_post_meta($quiz_id,self::SCORE_MODE_META,$score_mode);update_post_meta($quiz_id,self::MAX_SCORE_META,$score_mode==='points'?$max_score:100);
        $start=self::datetime('quiz_start');$end=self::datetime('quiz_end');if($start)update_post_meta($quiz_id,'_mph_quiz_start',$start);else delete_post_meta($quiz_id,'_mph_quiz_start');if($end)update_post_meta($quiz_id,'_mph_quiz_end',$end);else delete_post_meta($quiz_id,'_mph_quiz_end');
        $quiz=get_post($quiz_id);wp_send_json_success(array('message'=>$editing?'تنظیمات آزمون در Tutor ذخیره شد.':'آزمون ساخته شد؛ سؤال‌ها را همین‌جا اضافه کنید.','html'=>self::editor($quiz)));
    }

    public static function ajax_editor(){MPH_Helpers::verify_ajax();nocache_headers();$quiz=get_post(absint($_POST['quiz_id']??0));if(!self::owns_quiz($quiz))wp_send_json_error(array('message'=>'آزمون پیدا نشد یا دسترسی ویرایش ندارید.'),403);wp_send_json_success(array('message'=>'ویرایشگر آزمون باز شد.','html'=>self::editor($quiz)));}

    public static function ajax_question_save(){
        MPH_Helpers::verify_ajax();nocache_headers();global$wpdb;
        $quiz=get_post(absint($_POST['quiz_id']??0));if(!self::owns_quiz($quiz)||!self::tables_ready())wp_send_json_error(array('message'=>'آزمون یا جدول سؤال‌های Tutor در دسترس نیست.'),403);
        $question_id=absint($_POST['question_id']??0);$title=MPH_Helpers::posted('question_title');$type=MPH_Helpers::posted('question_type','key');if(!$title||!isset(self::types()[$type]))wp_send_json_error(array('message'=>'متن و نوع سؤال را کامل کنید.'));
        $questions=self::questions_table();$answers_table=self::answers_table();
        if($question_id){$belongs=absint($wpdb->get_var($wpdb->prepare("SELECT quiz_id FROM {$questions} WHERE question_id=%d",$question_id)));if($belongs!==absint($quiz->ID))wp_send_json_error(array('message'=>'سؤال متعلق به این آزمون نیست.'),403);}
        $settings=array('answer_required'=>isset($_POST['answer_required'])?1:0,'randomize_question'=>isset($_POST['randomize_answers'])?1:0);
        $question_data=array('quiz_id'=>$quiz->ID,'question_title'=>$title,'question_description'=>MPH_Helpers::posted('question_description','textarea'),'answer_explanation'=>MPH_Helpers::posted('answer_explanation','textarea'),'question_type'=>$type,'question_mark'=>max(0,(float)($_POST['question_mark']??1)),'question_settings'=>maybe_serialize($settings));
        if(!$question_id)$question_data['question_order']=1+absint($wpdb->get_var($wpdb->prepare("SELECT MAX(question_order) FROM {$questions} WHERE quiz_id=%d",$quiz->ID)));
        $wpdb->query('START TRANSACTION');
        $ok=$question_id?$wpdb->update($questions,$question_data,array('question_id'=>$question_id),array('%d','%s','%s','%s','%s','%f','%s'),array('%d')):$wpdb->insert($questions,$question_data,array('%d','%s','%s','%s','%s','%f','%s','%d'));
        if($ok===false){$wpdb->query('ROLLBACK');wp_send_json_error(array('message'=>'ذخیره سؤال انجام نشد: '.$wpdb->last_error));}
        if(!$question_id)$question_id=absint($wpdb->insert_id);
        $answer_result=self::save_answers($question_id,$type,$answers_table);
        if(is_wp_error($answer_result)){$wpdb->query('ROLLBACK');wp_send_json_error(array('message'=>$answer_result->get_error_message()));}
        $wpdb->query('COMMIT');
        do_action('mph_tutor_quiz_question_saved',$question_id,$quiz->ID);
        wp_send_json_success(array('message'=>'سؤال و پاسخ‌ها در Tutor ذخیره شد.','html'=>self::editor(get_post($quiz->ID))));
    }

    private static function save_answers($question_id,$type,$table){global$wpdb;
        $no_answers=in_array($type,array('short_answer','open_ended'),true);$existing=array_map('absint',$wpdb->get_col($wpdb->prepare("SELECT answer_id FROM {$table} WHERE belongs_question_id=%d",$question_id)));
        if($no_answers){if($existing)$wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE belongs_question_id=%d",$question_id));return true;}
        $ids=(array)($_POST['answer_id']??array());$titles=(array)($_POST['answer_title']??array());$matches=(array)($_POST['answer_match']??array());$images=(array)($_POST['answer_image']??array());$correct=(array)($_POST['answer_correct']??array());
        if($type==='true_false'&&!$titles)$titles=array('درست','نادرست');$keep=array();$single_correct_used=false;$saved=0;
        foreach($titles as$n=>$raw_title){$title=sanitize_text_field(wp_unslash($raw_title));$match=sanitize_text_field(wp_unslash($matches[$n]??''));$image_id=absint($images[$n]??0);if($title===''&&$match===''&&!$image_id)continue;$answer_id=absint($ids[$n]??0);if($answer_id&&!in_array($answer_id,$existing,true))$answer_id=0;$is_correct=isset($correct[$n])?1:0;if(in_array($type,array('single_choice','true_false'),true)){if($single_correct_used)$is_correct=0;if($is_correct)$single_correct_used=true;}if(in_array($type,array('fill_in_the_blank','ordering','matching','image_answering','image_matching'),true))$is_correct=1;
            $data=array('belongs_question_id'=>$question_id,'belongs_question_type'=>$type,'answer_title'=>$title,'is_correct'=>$is_correct,'image_id'=>$image_id,'answer_two_gap_match'=>$match,'answer_view_format'=>in_array($type,array('image_answering','image_matching'),true)?'image':'text','answer_settings'=>maybe_serialize(array()),'answer_order'=>$saved+1);
            $formats=array('%d','%s','%s','%d','%d','%s','%s','%s','%d');$result=$answer_id?$wpdb->update($table,$data,array('answer_id'=>$answer_id),$formats,array('%d')):$wpdb->insert($table,$data,$formats);if($result===false)return new WP_Error('mph_quiz_answer','ذخیره پاسخ انجام نشد: '.$wpdb->last_error);if(!$answer_id)$answer_id=absint($wpdb->insert_id);$keep[]=$answer_id;$saved++;
        }
        if(!$saved)return new WP_Error('mph_quiz_answer_required','برای این نوع سؤال حداقل یک پاسخ وارد کنید.');
        if(in_array($type,array('single_choice','multiple_choice','true_false'),true)){if(!array_filter($correct))return new WP_Error('mph_quiz_correct_required','حداقل یک پاسخ صحیح را مشخص کنید.');}
        $remove=array_values(array_diff($existing,$keep));if($remove){$placeholders=implode(',',array_fill(0,count($remove),'%d'));$deleted=$wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE answer_id IN ({$placeholders})",...$remove));if($deleted===false)return new WP_Error('mph_quiz_answer_delete','حذف پاسخ‌های قدیمی انجام نشد.');}
        return true;
    }

    public static function ajax_question_delete(){MPH_Helpers::verify_ajax();global$wpdb;$quiz=get_post(absint($_POST['quiz_id']??0));$question_id=absint($_POST['question_id']??0);if(!self::owns_quiz($quiz)||!$question_id)wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$belongs=absint($wpdb->get_var($wpdb->prepare("SELECT quiz_id FROM ".self::questions_table()." WHERE question_id=%d",$question_id)));if($belongs!==absint($quiz->ID))wp_send_json_error(array('message'=>'سؤال متعلق به این آزمون نیست.'));$wpdb->query('START TRANSACTION');$wpdb->delete(self::answers_table(),array('belongs_question_id'=>$question_id),array('%d'));$ok=$wpdb->delete(self::questions_table(),array('question_id'=>$question_id),array('%d'));if($ok===false){$wpdb->query('ROLLBACK');wp_send_json_error(array('message'=>'حذف سؤال انجام نشد.'));}$wpdb->query('COMMIT');self::normalize_order($quiz->ID);wp_send_json_success(array('message'=>'سؤال حذف شد.','html'=>self::editor($quiz)));}

    public static function ajax_question_move(){MPH_Helpers::verify_ajax();global$wpdb;$quiz=get_post(absint($_POST['quiz_id']??0));$question_id=absint($_POST['question_id']??0);$direction=MPH_Helpers::posted('direction','key');if(!self::owns_quiz($quiz)||!in_array($direction,array('up','down'),true))wp_send_json_error(array('message'=>'درخواست جابه‌جایی معتبر نیست.'));$rows=self::questions($quiz->ID);$ids=array_map(function($row){return absint($row->question_id);},$rows);$index=array_search($question_id,$ids,true);if($index===false)wp_send_json_error(array('message'=>'سؤال پیدا نشد.'));$other=$direction==='up'?$index-1:$index+1;if(isset($ids[$other])){$tmp=$ids[$index];$ids[$index]=$ids[$other];$ids[$other]=$tmp;foreach($ids as$order=>$id)$wpdb->update(self::questions_table(),array('question_order'=>$order+1),array('question_id'=>$id),array('%d'),array('%d'));}wp_send_json_success(array('message'=>'ترتیب سؤال‌ها ذخیره شد.','html'=>self::editor($quiz)));}

    public static function ajax_attempts() {
        MPH_Helpers::verify_ajax();
        if (!self::can_teach() || !MPH_Tutor::active()) wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        $quiz=get_post(absint($_POST['quiz_id']??0));
        if (!self::owns_quiz($quiz)) wp_send_json_error(array('message'=>'آزمون پیدا نشد.'));
        wp_send_json_success(array('message'=>'لیست شرکت‌کنندگان باز شد.','html'=>self::attempts_panel($quiz)));
    }

    private static function attempts_panel($quiz) {
        global $wpdb;
        $table=self::attempts_table();
        if (!self::table_exists($table)) return '<section class="mph-section"><div class="mph-empty">جدول تلاش‌های Tutor پیدا نشد.</div></section>';
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE quiz_id=%d ORDER BY attempt_id DESC LIMIT 200",$quiz->ID));
        $settings=self::quiz_settings($quiz->ID);$passing=max(0,min(100,(float)($settings['passing_grade']??60)));
        $mode=self::score_mode($quiz->ID);$maximum=self::max_score($quiz->ID);
        ob_start(); ?>
        <section class="mph-section mph-quiz-attempt-panel">
            <div class="mph-section-heading"><div><h3>نمره‌دهی: <?php echo esc_html($quiz->post_title); ?></h3><p>روش نمره‌دهی: <?php echo esc_html($mode==='points'?'نمره عددی از '.self::number($maximum):'درصد از ۱۰۰'); ?> · پاسخ کاربر قابل ویرایش نیست.</p></div><button type="button" class="mph-secondary" data-panel="teacher_exams">بازگشت</button></div>
            <div class="mph-tutor-table"><table><thead><tr><th>کاربر</th><th>شروع</th><th>پایان</th><th>نمره</th><th>نتیجه</th><th>دفعات بازبینی</th><th>عملیات</th></tr></thead><tbody>
            <?php if(!$rows): ?><tr><td colspan="7">کسی در این آزمون شرکت نکرده است.</td></tr><?php endif; ?>
            <?php foreach($rows as$row):
                $user=get_user_by('id',absint($row->user_id??0));$display=self::display_score($row,$quiz->ID);$percent=self::attempt_percent($row,$quiz->ID);$history=self::review_history(absint($row->attempt_id??0));$review_count=count($history); ?>
                <tr>
                    <td><?php echo esc_html($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده'); ?></td>
                    <td><?php echo esc_html(self::attempt_date($row->attempt_started_at??'')); ?></td>
                    <td><?php echo esc_html(self::attempt_date($row->attempt_ended_at??'')); ?></td>
                    <td><b><?php echo esc_html(self::number($display)); ?></b> از <?php echo esc_html(self::number($mode==='points'?$maximum:100)); ?></td>
                    <td><span class="mph-quiz-status <?php echo $percent>=$passing?'is-current':'is-past'; ?>"><?php echo $percent>=$passing?'قبول':'نیازمند بررسی'; ?></span></td>
                    <td><?php echo absint($review_count); ?> از ۳</td>
                    <td><form data-mph-action="mph_quiz_review_open"><input type="hidden" name="attempt_id" value="<?php echo absint($row->attempt_id??0); ?>"><button class="mph-primary" type="submit"><?php echo $review_count?'بازبینی پاسخ‌ها':'بررسی و نمره‌دهی'; ?></button><div class="mph-message"></div></form></td>
                </tr>
            <?php endforeach; ?></tbody></table></div>
        </section><?php return ob_get_clean();
    }

    public static function ajax_review_open() {
        MPH_Helpers::verify_ajax();nocache_headers();
        $attempt=self::attempt(absint($_POST['attempt_id']??0));$quiz=$attempt?get_post(absint($attempt->quiz_id??0)):null;
        if(!$attempt||!self::owns_quiz($quiz))wp_send_json_error(array('message'=>'تلاش آزمون پیدا نشد یا دسترسی ندارید.'),403);
        wp_send_json_success(array('message'=>'پاسخ‌ها در حالت فقط‌خواندنی باز شد.','html'=>self::review_panel($quiz,$attempt)));
    }

    public static function ajax_review_save() {
        MPH_Helpers::verify_ajax();nocache_headers();global$wpdb;
        $attempt=self::attempt(absint($_POST['attempt_id']??0));$quiz=$attempt?get_post(absint($attempt->quiz_id??0)):null;
        if(!$attempt||!self::owns_quiz($quiz))wp_send_json_error(array('message'=>'تلاش آزمون پیدا نشد یا دسترسی ندارید.'),403);
        $attempt_id=absint($attempt->attempt_id??0);$history=self::review_history($attempt_id);
        if(count($history)>=3)wp_send_json_error(array('message'=>'سقف سه نوبت بازبینی برای این تلاش تکمیل شده است.'));
        $mode=self::score_mode($quiz->ID);$maximum=$mode==='points'?self::max_score($quiz->ID):100;
        $score=isset($_POST['review_score'])?(float)wp_unslash($_POST['review_score']):-1;
        if($score<0||$score>$maximum)wp_send_json_error(array('message'=>'نمره باید بین صفر و '.self::number($maximum).' باشد.'));
        $total=max(0,(float)($attempt->total_marks??0));$earned=$maximum>0?round($total*$score/$maximum,4):0;
        $table=self::attempts_table();$columns=$wpdb->get_col("SHOW COLUMNS FROM {$table}",0);$data=array('earned_marks'=>$earned);$formats=array('%f');
        if(in_array('is_manually_reviewed',$columns,true)){$data['is_manually_reviewed']=1;$formats[]='%d';}
        $saved=$wpdb->update($table,$data,array('attempt_id'=>$attempt_id),$formats,array('%d'));
        if($saved===false)wp_send_json_error(array('message'=>'ذخیره نمره در Tutor انجام نشد: '.$wpdb->last_error));
        $history[]=array('score'=>$score,'mode'=>$mode,'maximum'=>$maximum,'teacher'=>get_current_user_id(),'date'=>current_time('mysql'));
        update_option(self::review_option($attempt_id),$history,false);
        do_action('mph_quiz_attempt_reviewed',$attempt_id,$quiz->ID,$score,$mode,count($history));
        $fresh=self::attempt($attempt_id);
        wp_send_json_success(array('message'=>'نمره ذخیره شد؛ '.(3-count($history)).' نوبت بازبینی باقی مانده است.','html'=>self::review_panel($quiz,$fresh)));
    }

    private static function review_panel($quiz,$attempt) {
        $attempt_id=absint($attempt->attempt_id??0);$user=get_user_by('id',absint($attempt->user_id??0));$history=self::review_history($attempt_id);
        $mode=self::score_mode($quiz->ID);$maximum=$mode==='points'?self::max_score($quiz->ID):100;$score=self::display_score($attempt,$quiz->ID);$locked=count($history)>=3;
        $answers=self::attempt_answers($attempt_id);$questions=array();foreach(self::questions($quiz->ID)as$question)$questions[absint($question->question_id)]=$question;
        ob_start(); ?>
        <section class="mph-section mph-quiz-review">
            <div class="mph-section-heading"><div><h3>بازبینی پاسخ‌های <?php echo esc_html($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده'); ?></h3><p><?php echo esc_html($quiz->post_title); ?> · بازبینی <?php echo count($history); ?> از ۳</p></div><form data-mph-action="mph_quiz_attempts"><input type="hidden" name="quiz_id" value="<?php echo absint($quiz->ID); ?>"><button class="mph-secondary" type="submit">بازگشت به شرکت‌کنندگان</button><div class="mph-message"></div></form></div>
            <div class="mph-quiz-readonly-note">پاسخ‌های کاربر فقط برای مشاهده هستند و در هیچ مرحله‌ای تغییر نمی‌کنند.</div>
            <div class="mph-quiz-review-answers">
                <?php if(!$answers): ?><div class="mph-empty">پاسخی برای این تلاش در جدول Tutor ثبت نشده است.</div><?php endif; ?>
                <?php foreach($answers as$index=>$answer):$question_id=absint($answer->question_id??0);$question=$questions[$question_id]??null; ?>
                    <article class="mph-quiz-review-answer">
                        <header><span><?php echo $index+1; ?></span><h4><?php echo esc_html($question?$question->question_title:'سؤال حذف‌شده #'.$question_id); ?></h4></header>
                        <div class="mph-quiz-given-answer"><b>پاسخ کاربر</b><p><?php echo esc_html(self::answer_display($answer,$question_id)); ?></p></div>
                        <footer><span>نمره سؤال: <?php echo esc_html(self::number($answer->question_mark??($question->question_mark??0))); ?></span><span>نمره کسب‌شده: <?php echo esc_html(self::number($answer->achieved_mark??0)); ?></span><?php if(property_exists($answer,'is_correct')): ?><span class="<?php echo !empty($answer->is_correct)?'is-correct':'is-wrong'; ?>"><?php echo !empty($answer->is_correct)?'صحیح':'نیازمند بررسی'; ?></span><?php endif; ?></footer>
                    </article>
                <?php endforeach; ?>
            </div>
            <form class="mph-form mph-quiz-review-score" data-mph-action="mph_quiz_review_save">
                <input type="hidden" name="attempt_id" value="<?php echo $attempt_id; ?>">
                <label>نمره نهایی (از <?php echo esc_html(self::number($maximum)); ?>)<input type="number" name="review_score" min="0" max="<?php echo esc_attr(self::number($maximum)); ?>" step="0.01" value="<?php echo esc_attr(self::number($score)); ?>" required <?php disabled($locked); ?>></label>
                <button class="mph-primary" type="submit" <?php disabled($locked); ?>><?php echo $locked?'سقف بازبینی تکمیل شده':'ثبت نمره و بازبینی'; ?></button><div class="mph-message"></div>
            </form>
            <?php if($history): ?><div class="mph-quiz-review-history"><h4>تاریخچه تغییر نمره</h4><ol><?php foreach(array_reverse($history)as$item):$teacher=get_user_by('id',absint($item['teacher']??0)); ?><li><b><?php echo esc_html(self::number($item['score']??0).' از '.self::number($item['maximum']??100)); ?></b><span><?php echo esc_html(self::attempt_date($item['date']??'')); ?> · <?php echo esc_html($teacher?MPH_Helpers::display_name($teacher):'مدرس'); ?></span></li><?php endforeach; ?></ol></div><?php endif; ?>
        </section><?php return ob_get_clean();
    }

    private static function attempt($attempt_id) {global$wpdb;$table=self::attempts_table();if(!$attempt_id||!self::table_exists($table))return null;return$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE attempt_id=%d",$attempt_id));}
    private static function attempt_answers($attempt_id) {global$wpdb;$table=self::attempt_answers_table();if(!self::table_exists($table))return array();return$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE quiz_attempt_id=%d ORDER BY attempt_answer_id ASC",$attempt_id));}
    private static function answer_display($attempt_answer,$question_id) {
        // Tutor LMS has used different answer columns across releases. Prefer
        // given_answer (current schema), then fall back to legacy fields without
        // mistaking an empty/zero answer_id for the student's written response.
        $raw='';foreach(array('given_answer','answer_id','answer_title','answer')as$field){if(!property_exists($attempt_answer,$field))continue;$candidate=$attempt_answer->$field;if($candidate===null||$candidate===''||$candidate===array()||($field==='answer_id'&&(string)$candidate==='0'))continue;$raw=$candidate;break;}
        $options=array();foreach(self::answers($question_id)as$answer)$options[(string)$answer->answer_id]=(string)($answer->answer_title?:$answer->answer_two_gap_match);
        $value=maybe_unserialize($raw);if(is_string($value)){ $json=json_decode($value,true);if(json_last_error()===JSON_ERROR_NONE&&is_array($json))$value=$json;else{$parts=preg_split('/\s*[,|]\s*/u',$value,-1,PREG_SPLIT_NO_EMPTY);if(count($parts)>1&&!array_diff(array_map('strval',$parts),array_keys($options)))$value=$parts;}}
        if(is_object($value))$value=(array)$value;$values=is_array($value)?$value:array($value);
        $labels=array();array_walk_recursive($values,function($item)use(&$labels,$options){$key=(string)$item;$labels[]=isset($options[$key])?$options[$key]:wp_strip_all_tags((string)$item);});
        $labels=array_values(array_filter(array_map('trim',$labels),function($item){return$item!=='';}));return$labels?implode('، ',$labels):'بدون پاسخ';
    }
    private static function attempts_table(){global$wpdb;return$wpdb->prefix.'tutor_quiz_attempts';}
    private static function attempt_answers_table(){global$wpdb;return$wpdb->prefix.'tutor_quiz_attempt_answers';}
    private static function review_option($attempt_id){return'mph_quiz_review_v26_'.absint($attempt_id);}
    private static function review_history($attempt_id){$value=get_option(self::review_option($attempt_id),array());return is_array($value)?array_slice($value,0,3):array();}
    private static function score_mode($quiz_id){$mode=get_post_meta($quiz_id,self::SCORE_MODE_META,true);return in_array($mode,array('percent','points'),true)?$mode:'percent';}
    private static function max_score($quiz_id){$maximum=(float)get_post_meta($quiz_id,self::MAX_SCORE_META,true);return$maximum>0?$maximum:100;}
    private static function attempt_percent($attempt,$quiz_id){$history=self::review_history(absint($attempt->attempt_id??0));if($history){$last=end($history);$max=max(.01,(float)($last['maximum']??100));return max(0,min(100,(float)($last['score']??0)/$max*100));}$total=(float)($attempt->total_marks??0);return$total>0?max(0,min(100,(float)($attempt->earned_marks??0)/$total*100)):0;}
    private static function display_score($attempt,$quiz_id){$history=self::review_history(absint($attempt->attempt_id??0));if($history){$last=end($history);return(float)($last['score']??0);}$percent=self::attempt_percent($attempt,$quiz_id);return self::score_mode($quiz_id)==='points'?$percent*self::max_score($quiz_id)/100:$percent;}

    private static function posted_settings(){return array('time_limit'=>array('time_value'=>max(0,absint($_POST['quiz_time']??30)),'time_type'=>in_array(MPH_Helpers::posted('quiz_time_type','key'),array('minutes','hours','days','weeks'),true)?MPH_Helpers::posted('quiz_time_type','key'):'minutes'),'attempts_allowed'=>max(0,absint($_POST['quiz_attempts']??1)),'passing_grade'=>max(0,min(100,absint($_POST['quiz_pass']??60))),'feedback_mode'=>in_array(MPH_Helpers::posted('quiz_feedback','key'),array('default','retry','reveal'),true)?MPH_Helpers::posted('quiz_feedback','key'):'default','max_questions_for_answer'=>max(0,absint($_POST['quiz_max_questions']??10)),'questions_order'=>in_array(MPH_Helpers::posted('quiz_order','key'),array('rand','sort_asc','sort_desc'),true)?MPH_Helpers::posted('quiz_order','key'):'rand','quiz_auto_start'=>isset($_POST['quiz_auto_start'])?1:0,'hide_quiz_time_display'=>isset($_POST['quiz_hide_time'])?1:0,'short_answer_characters_limit'=>max(20,absint($_POST['quiz_short_limit']??200)),'open_ended_answer_characters_limit'=>max(50,absint($_POST['quiz_open_limit']??500)));}
    private static function default_settings(){return array('time_limit'=>array('time_value'=>30,'time_type'=>'minutes'),'attempts_allowed'=>1,'passing_grade'=>60,'feedback_mode'=>'default','max_questions_for_answer'=>10,'questions_order'=>'rand','quiz_auto_start'=>0,'hide_quiz_time_display'=>0,'short_answer_characters_limit'=>200,'open_ended_answer_characters_limit'=>500);}
    private static function quiz_settings($quiz_id){$stored=get_post_meta($quiz_id,'tutor_quiz_option',true);if(!is_array($stored))$stored=get_post_meta($quiz_id,'_tutor_quiz_settings',true);return is_array($stored)?array_replace_recursive(self::default_settings(),$stored):self::default_settings();}
    private static function types(){return array('true_false'=>'درست / نادرست','single_choice'=>'تک‌گزینه‌ای','multiple_choice'=>'چندگزینه‌ای','fill_in_the_blank'=>'جای خالی','short_answer'=>'پاسخ کوتاه','open_ended'=>'تشریحی','ordering'=>'مرتب‌سازی','matching'=>'تطبیقی','image_answering'=>'پاسخ تصویری','image_matching'=>'تطبیق تصویری');}
    private static function type_label($type){$types=self::types();return$types[$type]??$type;}
    private static function quizzes(){$course_ids=wp_list_pluck(self::courses(),'ID');if(!$course_ids)return array();$topic_ids=get_posts(array('post_type'=>'topics','post_status'=>'any','post_parent__in'=>$course_ids,'numberposts'=>-1,'fields'=>'ids'));return get_posts(array('post_type'=>self::quiz_post_type(),'post_status'=>array('publish','draft','future'),'post_parent__in'=>array_merge($course_ids,$topic_ids),'numberposts'=>-1,'orderby'=>'date','order'=>'DESC'));}
    private static function courses(){if(!MPH_Tutor::active())return array();$args=array('post_type'=>tutor()->course_post_type,'post_status'=>array('publish','draft','pending','future'),'numberposts'=>-1,'orderby'=>'title','order'=>'ASC');if(!current_user_can('manage_options'))$args['author']=get_current_user_id();return get_posts($args);}
    private static function questions($quiz_id){global$wpdb;return$wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::questions_table()." WHERE quiz_id=%d ORDER BY question_order ASC,question_id ASC",$quiz_id));}
    private static function answers($question_id){global$wpdb;return$wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::answers_table()." WHERE belongs_question_id=%d ORDER BY answer_order ASC,answer_id ASC",$question_id));}
    private static function question_count($quiz_id){global$wpdb;return absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".self::questions_table()." WHERE quiz_id=%d",$quiz_id)));}
    private static function normalize_order($quiz_id){global$wpdb;foreach(self::questions($quiz_id)as$n=>$question)$wpdb->update(self::questions_table(),array('question_order'=>$n+1),array('question_id'=>$question->question_id),array('%d'),array('%d'));}
    private static function questions_table(){global$wpdb;return$wpdb->prefix.'tutor_quiz_questions';}
    private static function answers_table(){global$wpdb;return$wpdb->prefix.'tutor_quiz_question_answers';}
    private static function tables_ready(){return self::table_exists(self::questions_table())&&self::table_exists(self::answers_table());}
    private static function table_exists($table){global$wpdb;return$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))===$table;}
    private static function quiz_post_type(){return MPH_Tutor::active()&&!empty(tutor()->quiz_post_type)?tutor()->quiz_post_type:'tutor_quiz';}
    private static function ensure_topic($course_id){$topics=get_posts(array('post_type'=>'topics','post_status'=>'any','post_parent'=>$course_id,'numberposts'=>1,'fields'=>'ids','orderby'=>'menu_order','order'=>'ASC'));if($topics)return absint($topics[0]);$id=wp_insert_post(array('post_type'=>'topics','post_status'=>'publish','post_parent'=>$course_id,'post_author'=>get_current_user_id(),'post_title'=>'آزمون‌ها'),true);return is_wp_error($id)?0:absint($id);}
    private static function course_id($quiz){if(!$quiz)return 0;$parent=get_post($quiz->post_parent);if(!$parent)return 0;if(MPH_Tutor::active()&&$parent->post_type===tutor()->course_post_type)return$parent->ID;if($parent->post_type==='topics')return absint($parent->post_parent);return 0;}
    private static function owns_course($id){$post=get_post($id);return$post&&MPH_Tutor::active()&&$post->post_type===tutor()->course_post_type&&(current_user_can('manage_options')||absint($post->post_author)===get_current_user_id());}
    private static function owns_quiz($quiz){return$quiz&&$quiz->post_type===self::quiz_post_type()&&self::owns_course(self::course_id($quiz));}
    private static function status($quiz){$now=current_time('timestamp');$start=strtotime((string)get_post_meta($quiz->ID,'_mph_quiz_start',true));$end=strtotime((string)get_post_meta($quiz->ID,'_mph_quiz_end',true));if($end&&$now>$end)return'past';if($start&&$now<$start)return'future';return'current';}
    private static function schedule($quiz){$start=get_post_meta($quiz->ID,'_mph_quiz_start',true);$end=get_post_meta($quiz->ID,'_mph_quiz_end',true);if(!$start&&!$end)return'بدون محدودیت زمانی';return($start?date_i18n('Y/m/d H:i',strtotime($start)):'—').' تا '.($end?date_i18n('Y/m/d H:i',strtotime($end)):'—');}
    private static function status_label($status){$labels=array('past'=>'پایان‌یافته','current'=>'در حال برگزاری','future'=>'آینده');return$labels[$status]??$status;}
    private static function attempt_counts($quiz_ids){global$wpdb;$ids=array_values(array_filter(array_map('absint',(array)$quiz_ids)));if(!$ids)return array();$table=$wpdb->prefix.'tutor_quiz_attempts';if(!self::table_exists($table))return array();$placeholders=implode(',',array_fill(0,count($ids),'%d'));$rows=$wpdb->get_results($wpdb->prepare("SELECT quiz_id,COUNT(*) AS total FROM {$table} WHERE quiz_id IN ({$placeholders}) GROUP BY quiz_id",...$ids));$map=array();foreach($rows as$row)$map[absint($row->quiz_id)]=absint($row->total);return$map;}
    private static function attempt_url($attempt_id){return add_query_arg('view_quiz_attempt_id',$attempt_id,MPH_Tutor::dashboard_url('quiz-attempts'));}
    private static function datetime($key){$value=MPH_Helpers::posted($key);if(!$value)return'';$stamp=strtotime($value);return$stamp?wp_date('Y-m-d H:i:s',$stamp):'';}
    private static function input_datetime($value){$stamp=strtotime((string)$value);return$stamp?wp_date('Y-m-d\TH:i',$stamp):'';}
    private static function attempt_date($value){$stamp=strtotime((string)$value);return$stamp?date_i18n('Y/m/d H:i',$stamp):'—';}
    private static function number($value){return rtrim(rtrim(number_format((float)$value,2,'.',''),'0'),'.');}
    private static function can_teach(){return is_user_logged_in()&&(MPH_Helpers::has_role('mph_instructor')||current_user_can('manage_options'));}
}
