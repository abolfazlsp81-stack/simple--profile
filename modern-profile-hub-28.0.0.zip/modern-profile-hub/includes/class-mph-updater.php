<?php
defined('ABSPATH') || exit;
final class MPH_Updater {
    public static function init(){add_filter('pre_set_site_transient_update_plugins',array(__CLASS__,'check'));}
    public static function check($transient){
        if(!is_object($transient))return$transient;$url=esc_url_raw((string)get_option('mph_update_manifest_url',''));if(!$url||wp_parse_url($url,PHP_URL_SCHEME)!=='https')return$transient;$cache=get_transient('mph_update_manifest');
        if(!is_array($cache)){$response=wp_remote_get($url,array('timeout'=>10,'redirection'=>2,'sslverify'=>true,'headers'=>array('Accept'=>'application/json')));if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200)return$transient;$cache=json_decode(wp_remote_retrieve_body($response),true);if(!is_array($cache))return$transient;set_transient('mph_update_manifest',$cache,6*HOUR_IN_SECONDS);}
        $version=sanitize_text_field($cache['version']??'');$package=esc_url_raw($cache['package']??'');if(!$version||!$package||wp_parse_url($package,PHP_URL_SCHEME)!=='https'||version_compare($version,MPH_VERSION,'<='))return$transient;$plugin=plugin_basename(MPH_FILE);$transient->response[$plugin]=(object)array('slug'=>'modern-profile-hub','plugin'=>$plugin,'new_version'=>$version,'package'=>$package,'url'=>esc_url_raw($cache['homepage']??home_url('/')),'requires'=>sanitize_text_field($cache['requires']??'6.2'),'requires_php'=>sanitize_text_field($cache['requires_php']??'7.4'),'tested'=>sanitize_text_field($cache['tested']??''));return$transient;
    }
}
