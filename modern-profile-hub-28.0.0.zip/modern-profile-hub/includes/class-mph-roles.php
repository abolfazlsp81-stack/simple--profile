<?php
defined('ABSPATH') || exit;

final class MPH_Roles {
    const POST_TYPE = 'mph_role_request';

    public static function init() {
        add_action('init',array(__CLASS__,'register_type'));
        add_action('wp_ajax_mph_role_request',array(__CLASS__,'submit'));
    }

    public static function register_type() {
        register_post_type(self::POST_TYPE,array('label'=>'درخواست نقش','public'=>false,'show_ui'=>false,'supports'=>array('author','editor')));
    }

    public static function available($user = null) {
        $user=$user?:wp_get_current_user();$roles=array();
        if(!MPH_Helpers::has_role('mph_instructor',$user))$roles['instructor']='مدرس';
        if(!MPH_Helpers::has_role('mph_therapist',$user))$roles['therapist']='درمانگر';
        if(!MPH_Helpers::has_role('mph_manager',$user))$roles['manager']='مدیر مجموعه';
        return $roles;
    }

    public static function pending_roles($user_id = 0) {
        $user_id = $user_id ?: get_current_user_id();
        if (!$user_id) return array();
        $requests = get_posts(array(
            'post_type' => self::POST_TYPE,
            'post_status' => 'pending',
            'author' => absint($user_id),
            'numberposts' => -1,
            'fields' => 'ids',
        ));
        $roles = array();
        foreach ($requests as $request_id) {
            $role = sanitize_key(get_post_meta($request_id, 'mph_requested_role', true));
            if ($role) $roles[$role] = absint($request_id);
        }
        return $roles;
    }

    public static function pending_count($user_id = 0) {
        return count(self::pending_roles($user_id));
    }

    public static function render_form() {
        $roles = self::available();
        $pending = self::pending_roles();
        $requestable = array_diff_key($roles, $pending);
        ob_start(); ?>
        <section class="mph-section mph-role-request-box">
            <div class="mph-role-request-hero">
                <span class="dashicons dashicons-groups"></span>
                <div><small>ارتقای دسترسی حساب</small><h3>درخواست نقش جدید</h3><p>نقش جدید به همین حساب اضافه می‌شود و نام کاربری و رمز شما تغییر نمی‌کند.</p></div>
            </div>
            <?php if ($pending) : ?>
                <div class="mph-role-pending"><b>درخواست‌های در حال بررسی</b><div><?php foreach ($pending as $role => $request_id) : ?><span><i></i><?php echo esc_html(self::label($role)); ?><small>#<?php echo absint($request_id); ?></small></span><?php endforeach; ?></div></div>
            <?php endif; ?>
            <?php if (!$roles) : ?>
                <div class="mph-empty"><span class="dashicons dashicons-yes-alt"></span><p>تمام نقش‌های قابل‌دسترسی برای حساب شما فعال هستند.</p></div>
                <button class="mph-secondary mph-role-back" type="button" data-cancel-role-request>بازگشت به کارتابل</button>
            <?php elseif (!$requestable) : ?>
                <div class="mph-role-info"><span class="dashicons dashicons-clock"></span><p>درخواست نقش‌های باقیمانده ثبت شده و منتظر بررسی مدیر است.</p></div>
                <button class="mph-secondary mph-role-back" type="button" data-cancel-role-request>بازگشت به کارتابل</button>
            <?php else : ?>
                <form class="mph-form mph-role-request-form" data-mph-action="mph_role_request">
                    <label><?php echo MPH_Helpers::required('نقش درخواستی'); ?><select name="requested_role" required><option value="">انتخاب نقش</option><?php foreach($requestable as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                    <label>توضیحات <small>(اختیاری)</small><textarea name="request_message" maxlength="1500" placeholder="برای بررسی بهتر، تجربه یا دلیل درخواست خود را کوتاه بنویسید"></textarea></label>
                    <div class="mph-role-info"><span class="dashicons dashicons-shield-alt"></span><p>پس از تأیید مدیر، نقش به انتخابگر کنار نام کاربری اضافه و نتیجه در تیکت‌های شما اعلام می‌شود.</p></div>
                    <div class="mph-form-actions"><button class="mph-primary" type="submit"><span class="dashicons dashicons-saved"></span> ارسال درخواست</button><button class="mph-secondary" type="button" data-cancel-role-request>انصراف و بازگشت</button></div>
                    <div class="mph-message" aria-live="polite"></div>
                </form>
            <?php endif; ?>
        </section>
        <?php return ob_get_clean();
    }

    public static function submit() {
        MPH_Helpers::verify_ajax();if(!is_user_logged_in())wp_send_json_error(array('message'=>'ابتدا وارد شوید.'),401);
        $role=MPH_Helpers::posted('requested_role','key');$available=self::available();if(!isset($available[$role]))wp_send_json_error(array('message'=>'نقش انتخاب‌شده معتبر نیست.'));
        $existing=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'pending','author'=>get_current_user_id(),'meta_key'=>'mph_requested_role','meta_value'=>$role,'numberposts'=>1));if($existing)wp_send_json_error(array('message'=>'درخواست این نقش قبلاً ارسال شده و در انتظار بررسی است.'));
        $id=wp_insert_post(array('post_type'=>self::POST_TYPE,'post_status'=>'pending','post_author'=>get_current_user_id(),'post_title'=>'درخواست '.$available[$role],'post_content'=>MPH_Helpers::posted('request_message','textarea')));
        if(is_wp_error($id)||!$id)wp_send_json_error(array('message'=>'ثبت درخواست انجام نشد.'));update_post_meta($id,'mph_requested_role',$role);update_post_meta($id,'mph_request_status','pending');wp_send_json_success(array('message'=>'درخواست شما ثبت شد و پس از بررسی مدیر اطلاع‌رسانی می‌شود.','refreshSession'=>true));
    }

    public static function approve($request_id) {
        $post=get_post($request_id);if(!$post||$post->post_type!==self::POST_TYPE)return false;$role=get_post_meta($request_id,'mph_requested_role',true);$user=new WP_User($post->post_author);
        if($role==='instructor')MPH_Tutor::approve_instructor($user->ID);elseif($role==='therapist')$user->add_role('mph_therapist');elseif($role==='manager')$user->add_role('mph_manager');else return false;
        update_post_meta($request_id,'mph_request_status','approved');wp_update_post(array('ID'=>$request_id,'post_status'=>'publish'));$label=self::label($role);MPH_Tickets::create_system_notification($user->ID,'تأیید نقش کاربری','حساب کاربری شما برای نقش «'.$label.'» تأیید شد. اکنون می‌توانید از بخش تغییر نقش وارد کارتابل مربوطه شوید.','role');return true;
    }

    public static function reject($request_id) {$post=get_post($request_id);if(!$post||$post->post_type!==self::POST_TYPE)return false;$role=get_post_meta($request_id,'mph_requested_role',true);$label=self::label($role);update_post_meta($request_id,'mph_request_status','rejected');wp_update_post(array('ID'=>$request_id,'post_status'=>'draft'));MPH_Tickets::create_system_notification($post->post_author,'نتیجه درخواست نقش','درخواست شما برای نقش «'.$label.'» در این مرحله تأیید نشد. برای دریافت توضیحات می‌توانید یک تیکت پشتیبانی ثبت کنید.','role');return true;}

    public static function label($role) {$labels=array('instructor'=>'مدرس','therapist'=>'درمانگر','manager'=>'مدیر مجموعه');return $labels[sanitize_key($role)]??'نقش کاربری';}
}
