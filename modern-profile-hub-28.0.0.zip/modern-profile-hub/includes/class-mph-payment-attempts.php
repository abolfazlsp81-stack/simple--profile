<?php
defined('ABSPATH') || exit;

/** Every authority keeps its original amount, environment and verification result. */
final class MPH_Payment_Attempts {
    const META = '_mph_payment_attempts_v28';

    public static function valid_merchant($value) {
        return (bool)preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', trim((string)$value));
    }

    public static function rows($order) {
        $rows = $order->get_meta(self::META);
        $rows = is_array($rows) ? $rows : array();
        $legacy = (string)$order->get_meta('_mph_gateway_token');
        if (!$rows && $legacy && $order->get_payment_method()==='mph_zarinpal') {
            $rows[$legacy] = array('amount'=>(int)$order->get_meta('_mph_gateway_amount'),'currency'=>(string)$order->get_meta('_mph_gateway_currency'),'sandbox'=>(bool)MPH_Payments::get('zarinpal_sandbox'),'created'=>0,'state'=>'pending','credential'=>MPH_Security::encrypt((string)MPH_Payments::get('zarinpal_merchant')));
        }
        return $rows;
    }

    public static function request($order_id) {
        return MPH_Operation_Lock::run('payment:'.absint($order_id), function() use ($order_id) {
            $order = wc_get_order($order_id);
            if (!$order || !$order->needs_payment() || $order->is_paid()) return new WP_Error('mph_not_payable','این سفارش قابل پرداخت مجدد نیست.');
            $merchant = trim((string)MPH_Payments::get('zarinpal_merchant'));
            if (!self::valid_merchant($merchant)) return new WP_Error('mph_merchant','مرچنت زرین‌پال باید یک شناسه معتبر ۳۶ کاراکتری باشد.');
            $amount = MPH_Payments::amount($order,'IRR');
            if (is_wp_error($amount)) return $amount;
            $sandbox = (bool)MPH_Payments::get('zarinpal_sandbox');
            $host = self::host($sandbox);
            $rows = self::rows($order);
            foreach (array_reverse($rows, true) as $authority=>$row) {
                if (($row['state']??'')==='pending' && (int)$row['amount']===$amount && !empty($row['created']) && time()-(int)$row['created']<600 && (bool)$row['sandbox']===$sandbox && hash_equals($merchant, (string)MPH_Security::decrypt($row['credential']??''))) {
                    return array('result'=>'success','redirect'=>$host.'/pg/StartPay/'.rawurlencode($authority));
                }
                if (in_array($row['state']??'',array('verifying','unknown','review'),true)) return new WP_Error('mph_payment_unknown','نتیجه تلاش قبلی هنوز مشخص نیست. ابتدا «بررسی وضعیت پرداخت» را بزنید.');
            }
            $response = MPH_Payments::post_json($host.'/pg/v4/payment/request.json', array(
                'merchant_id'=>$merchant,'amount'=>$amount,'currency'=>'IRR',
                'description'=>'پرداخت سفارش #'.$order->get_order_number(),
                'callback_url'=>add_query_arg('mph_order',$order->get_id(),WC()->api_request_url('MPH_Gateway_Zarinpal')),
                'metadata'=>array_filter(array('mobile'=>$order->get_billing_phone(),'email'=>$order->get_billing_email(),'order_id'=>(string)$order->get_id())),
            ));
            if (is_wp_error($response)) return new WP_Error('mph_gateway_network','اتصال به زرین‌پال برقرار نشد؛ سبد شما محفوظ است.');
            $authority = (string)($response['data']['authority']??'');
            if ((int)($response['data']['code']??0)!==100 || !preg_match('/^[A-Za-z0-9]{20,100}$/D',$authority)) return new WP_Error('mph_gateway_request',self::message($response));
            $rows[$authority] = array('amount'=>$amount,'currency'=>'IRR','sandbox'=>$sandbox,'created'=>time(),'state'=>'pending','credential'=>MPH_Security::encrypt($merchant));
            $order->update_meta_data(self::META,$rows);
            $order->update_meta_data('_mph_gateway_token',$authority);
            $order->update_meta_data('_mph_gateway_amount',$amount);
            $order->update_meta_data('_mph_gateway_currency','IRR');
            $order->set_payment_method('mph_zarinpal');
            $order->save();
            self::event($order,'payment_started','درخواست پرداخت به زرین‌پال ارسال شد.');
            return array('result'=>'success','redirect'=>$host.'/pg/StartPay/'.rawurlencode($authority));
        });
    }

    public static function verify($order_id, $authority, $status = 'OK') {
        return MPH_Operation_Lock::run('payment:'.absint($order_id),function() use ($order_id,$authority,$status) {
            $order = wc_get_order($order_id);
            if (!$order || $order->get_payment_method()!=='mph_zarinpal') return new WP_Error('mph_order','سفارش معتبر نیست.');
            $rows = self::rows($order);
            if (!$authority || !isset($rows[$authority])) return new WP_Error('mph_authority','شناسه پرداخت با سفارش مطابقت ندارد.');
            $row = $rows[$authority];
            if ($order->is_paid()) return array('paid'=>true,'reference'=>(string)$order->get_transaction_id());
            if ($status!=='OK' && !in_array($row['state']??'',array('unknown','verifying','review'),true)) {
                if (($row['state']??'')!=='paid') $rows[$authority]['state']='cancelled';
                $order->update_meta_data(self::META,$rows);$order->save();
                self::event($order,'payment_cancelled','پرداخت توسط کاربر لغو شد یا درگاه آن را نپذیرفت.');
                return new WP_Error('mph_cancelled','پرداخت کامل نشد؛ اقلام سبد شما محفوظ است.');
            }
            $merchant = MPH_Security::decrypt($row['credential']??'');
            if (!$merchant || (int)($row['amount']??0)<=0) return new WP_Error('mph_payment_meta','اطلاعات تلاش پرداخت ناقص است؛ با پشتیبانی تماس بگیرید.');
            $rows[$authority]['state']='verifying';$order->update_meta_data(self::META,$rows);$order->save();
            $response = MPH_Payments::post_json(self::host(!empty($row['sandbox'])).'/pg/v4/payment/verify.json',array('merchant_id'=>$merchant,'amount'=>(int)$row['amount'],'authority'=>$authority));
            $code = is_wp_error($response) ? 0 : (int)($response['data']['code']??$response['errors']['code']??0);
            $reference = is_wp_error($response) ? '' : (string)($response['data']['ref_id']??'');
            $rows[$authority]['checked']=time();
            if (!is_wp_error($response) && in_array($code,array(100,101),true) && preg_match('/^[0-9]+$/D',$reference) && (float)$reference>0) {
                $current_amount=MPH_Payments::amount($order,$row['currency']??'IRR');
                if (is_wp_error($current_amount) || (int)$current_amount!==(int)$row['amount']) {
                    $rows[$authority]['state']='review';$rows[$authority]['reference']=$reference;
                    $order->update_meta_data(self::META,$rows);$order->update_meta_data('_mph_payment_review',$reference);$order->save();
                    self::event($order,'payment_amount_review','وجه پرداخت شده با مبلغ فعلی سفارش متفاوت است؛ بررسی مدیر لازم است.');
                    return new WP_Error('mph_amount_changed','وجه دریافت شده است؛ مبلغ سفارش تغییر کرده و تأیید نهایی نیازمند بررسی مدیر است. دوباره پرداخت نکنید.');
                }
                $rows[$authority]['state']='paid';$rows[$authority]['reference']=$reference;
                $order->update_meta_data(self::META,$rows);$order->save();
                self::event($order,'payment_verified','پرداخت تأیید شد. کد پیگیری: '.$reference);
                $order->payment_complete($reference);
                return array('paid'=>true,'reference'=>$reference);
            }
            // Network failure and incomplete successful responses are uncertain, not failed payments.
            $unknown = is_wp_error($response) || $code===0 || in_array($code,array(100,101,-12,-50),true) || (int)($response['_http_code']??0)>=500;
            $rows[$authority]['state']=$unknown?'unknown':'failed';
            $order->update_meta_data(self::META,$rows);$order->save();
            self::event($order,$unknown?'payment_unknown':'payment_failed',$unknown?'نتیجه پرداخت در انتظار بررسی مجدد است.':'درگاه پرداخت را تأیید نکرد.');
            return new WP_Error($unknown?'mph_payment_unknown':'mph_payment_failed',$unknown?'نتیجه پرداخت هنوز مشخص نیست؛ دوباره پرداخت نکنید و وضعیت را بررسی کنید.':self::message($response));
        });
    }

    public static function reconcile($order) {
        $rows=array_filter(self::rows($order),function($row){return !in_array($row['state']??'',array('cancelled','failed','review'),true);});
        if (!$rows) return new WP_Error('mph_not_verified','پرداخت تأیید نشده است.');
        // One network request per pass; the least recently checked attempt goes first.
        uasort($rows,function($a,$b){return (int)($a['checked']??0)<=>(int)($b['checked']??0);});
        return self::verify($order->get_id(),key($rows));
    }

    public static function event($order,$event,$message) {
        $events = $order->get_meta('_mph_order_events');$events=is_array($events)?$events:array();
        $last=end($events);
        if ($last && $last['event']===$event && $last['message']===$message) return;
        $events[]=array('time'=>time(),'event'=>$event,'message'=>$message);
        $order->update_meta_data('_mph_order_events',array_slice($events,-100));$order->save();
        if (class_exists('MPH_Security')) MPH_Security::audit($event,'order='.$order->get_id(),$order->get_customer_id());
    }

    private static function host($sandbox) {return $sandbox?'https://sandbox.zarinpal.com':'https://payment.zarinpal.com';}
    private static function message($response) {
        $code=(int)($response['errors']['code']??$response['data']['code']??0);
        $messages=array(-9=>'اطلاعات درخواست پرداخت معتبر نیست.',-10=>'مرچنت یا دسترسی پذیرنده معتبر نیست.',-11=>'پذیرندگی زرین‌پال هنوز فعال نیست.',-12=>'تعداد درخواست‌ها زیاد است؛ کمی بعد بررسی کنید.',-14=>'دامنه بازگشت با دامنه ثبت‌شده در زرین‌پال یکسان نیست.',-15=>'پذیرندگی زرین‌پال تعلیق شده است.',-51=>'پرداخت موفقی برای این شناسه ثبت نشده است.',-54=>'شناسه پرداخت نامعتبر است.');
        return $messages[$code]??'زرین‌پال پرداخت را تأیید نکرد؛ کد پاسخ: '.$code;
    }
}
