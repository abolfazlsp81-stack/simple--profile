<?php
defined('ABSPATH') || exit;

/** Export/import the plugin-owned database state as a portable ZIP package. */
final class MPH_Backup {
    const FORMAT = 1;
    const MAX_IMPORT_SIZE = 67108864;
    const DATA_FILE = 'modern-profile-hub-backup.json';
    const MANIFEST_FILE = 'manifest.json';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'), 90);
        add_action('wp_dashboard_setup', array(__CLASS__, 'dashboard_widget'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_post_mph_backup_export', array(__CLASS__, 'export'));
        add_action('admin_post_mph_backup_import', array(__CLASS__, 'import'));
    }

    public static function assets($hook) {
        if (!in_array((string)$hook, array('index.php', 'modern-profile-hub_page_mph-backup'), true) && strpos((string)$hook, 'mph-backup') === false) return;
        wp_enqueue_style('mph-yekanbakh', MPH_URL.'assets/css/yekanbakh.css', array(), MPH_VERSION);
        wp_enqueue_style('mph-admin-release', MPH_URL.'assets/css/admin-release.css', array('dashicons','mph-yekanbakh'), MPH_VERSION);
    }

    public static function menu() {
        add_submenu_page('mph', 'پشتیبان‌گیری', 'پشتیبان‌گیری', 'manage_options', 'mph-backup', array(__CLASS__, 'admin_page'));
    }

    public static function dashboard_widget() {
        if (self::can_manage()) wp_add_dashboard_widget('mph_backup_widget', 'پشتیبان‌گیری پروفایل مدرن', array(__CLASS__, 'widget_content'));
    }

    public static function admin_page() {
        if (!self::can_manage()) wp_die('دسترسی ندارید.', '', array('response'=>403));
        $notice = sanitize_text_field(wp_unslash($_GET['mph_backup_notice'] ?? ''));
        $type = sanitize_key(wp_unslash($_GET['mph_backup_type'] ?? ''));
        ?><div class="wrap mph-admin mph-backup-admin" dir="rtl"><header class="mph-admin-head"><span class="dashicons dashicons-database-export"></span><div><h1>پشتیبان‌گیری تنظیمات و داده‌های افزونه</h1><p>خروجی و بازیابی امن در قالب فایل ZIP</p></div></header><?php if($notice): ?><div class="notice notice-<?php echo $type==='error'?'error':'success'; ?> is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?><?php echo self::cards(admin_url('admin.php?page=mph-backup')); ?></div><?php
    }

    public static function widget_content() {
        echo '<div class="mph-admin mph-backup-widget" dir="rtl">'.self::cards(admin_url('index.php')).'</div>';
    }

    public static function portal_card() {
        if (!self::can_manage()) return '';
        $notice=sanitize_text_field(wp_unslash($_GET['mph_backup_notice']??''));$type=sanitize_key(wp_unslash($_GET['mph_backup_type']??''));
        $message=$notice?'<div class="mph-message '.($type==='error'?'is-error':'is-success').'">'.esc_html($notice).'</div>':'';
        return '<section class="mph-section mph-backup-portal"><div class="mph-section-heading"><div><h3>پشتیبان‌گیری سیستم</h3><p>تنظیمات و داده‌های اختصاصی افزونه را به ZIP تبدیل یا از ZIP بازیابی کنید.</p></div><span class="dashicons dashicons-database-export"></span></div>'.$message.self::cards(MPH_Helpers::account_page_url()).'</section>';
    }

    private static function cards($redirect) {
        $export = wp_nonce_url(admin_url('admin-post.php?action=mph_backup_export'), 'mph_backup_export');
        ob_start(); ?>
        <div class="mph-backup-grid">
            <article class="mph-backup-card"><span class="dashicons dashicons-download"></span><div><h3>دریافت نسخه پشتیبان</h3><p>تنظیمات mph، جدول‌های اختصاصی، نقش‌های افزونه، نوشته‌ها و متادیتای مرتبط در یک ZIP قرار می‌گیرند.</p><a class="button button-primary mph-primary" href="<?php echo esc_url($export); ?>">دریافت فایل ZIP</a></div></article>
            <article class="mph-backup-card"><span class="dashicons dashicons-upload"></span><div><h3>بازیابی نسخه پشتیبان</h3><p>فقط فایل ZIP ساخته‌شده توسط همین ابزار پذیرفته می‌شود. داده‌ها به‌صورت ادغام و به‌روزرسانی بازیابی می‌شوند.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" onsubmit="return confirm('اطلاعات موجود با محتوای نسخه پشتیبان ادغام و موارد همنام به‌روزرسانی شوند؟')"><?php wp_nonce_field('mph_backup_import'); ?><input type="hidden" name="action" value="mph_backup_import"><input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect); ?>"><input type="file" name="mph_backup_zip" accept="application/zip,.zip" required><button class="button button-primary mph-primary" type="submit">بررسی و بازیابی ZIP</button></form></div></article>
        </div><p class="description mph-backup-note"><span class="dashicons dashicons-shield-alt"></span> فایل پشتیبان شامل اطلاعات حساس تنظیمات است؛ آن را در فضای عمومی قرار ندهید. فایل‌های فیزیکی کتابخانه رسانه داخل ZIP کپی نمی‌شوند، اما شناسه و متادیتای وابسته حفظ می‌شود.</p>
        <?php return ob_get_clean();
    }

    public static function export() {
        if (!self::can_manage() || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'mph_backup_export')) wp_die('لینک معتبر نیست.', '', array('response'=>403));
        if (!class_exists('ZipArchive')) require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        $tmp = self::temp_dir();
        if (is_wp_error($tmp)) wp_die($tmp->get_error_message());
        $data = self::collect();
        $json = wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) { self::cleanup($tmp); wp_die('ساخت داده پشتیبان انجام نشد.'); }
        $manifest = wp_json_encode(array(
            'format'=>self::FORMAT,
            'plugin'=>'modern-profile-hub',
            'plugin_version'=>MPH_VERSION,
            'created_at'=>gmdate('c'),
            'site'=>home_url('/'),
            'data_file'=>self::DATA_FILE,
            'sha256'=>hash('sha256', $json),
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (file_put_contents($tmp.'/'.self::DATA_FILE, $json, LOCK_EX) === false || file_put_contents($tmp.'/'.self::MANIFEST_FILE, $manifest, LOCK_EX) === false) { self::cleanup($tmp); wp_die('نوشتن فایل پشتیبان انجام نشد.'); }
        $zip_path = $tmp . '/modern-profile-hub-backup-' . gmdate('Y-m-d-His') . '.zip';
        $created = self::create_zip($zip_path, $tmp.'/'.self::DATA_FILE, $tmp.'/'.self::MANIFEST_FILE);
        if (is_wp_error($created)) { self::cleanup($tmp); wp_die($created->get_error_message()); }
        while (ob_get_level()) ob_end_clean();
        nocache_headers();
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.sanitize_file_name(basename($zip_path)).'"');
        header('Content-Length: '.filesize($zip_path));
        readfile($zip_path);
        self::cleanup($tmp);
        exit;
    }

    public static function import() {
        if (!self::can_manage()) wp_die('دسترسی ندارید.', '', array('response'=>403));
        check_admin_referer('mph_backup_import');
        $redirect = self::redirect_target();
        if (empty($_FILES['mph_backup_zip']) || !is_array($_FILES['mph_backup_zip'])) self::redirect($redirect, 'فایل ZIP انتخاب نشده است.', 'error');
        $file = $_FILES['mph_backup_zip'];
        if (!empty($file['error']) || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) self::redirect($redirect, 'آپلود فایل پشتیبان کامل نشد.', 'error');
        if (absint($file['size'] ?? 0) > self::MAX_IMPORT_SIZE) self::redirect($redirect, 'حجم فایل پشتیبان بیش از ۶۴ مگابایت است.', 'error');
        $type = wp_check_filetype_and_ext($file['tmp_name'], sanitize_file_name($file['name'] ?? ''), array('zip'=>'application/zip'));
        if (empty($type['ext']) || $type['ext'] !== 'zip') self::redirect($redirect, 'فقط فایل ZIP معتبر پذیرفته می‌شود.', 'error');
        $package = self::read_zip($file['tmp_name']);
        if (is_wp_error($package)) self::redirect($redirect, $package->get_error_message(), 'error');
        $manifest = json_decode($package['manifest'], true);
        if (!is_array($manifest) || ($manifest['plugin'] ?? '') !== 'modern-profile-hub' || absint($manifest['format'] ?? 0) !== self::FORMAT) self::redirect($redirect, 'ساختار فایل پشتیبان معتبر نیست.', 'error');
        if (!hash_equals((string)($manifest['sha256'] ?? ''), hash('sha256', $package['data']))) self::redirect($redirect, 'صحت فایل پشتیبان تأیید نشد؛ فایل ناقص یا تغییر داده شده است.', 'error');
        $data = json_decode($package['data'], true);
        if (!is_array($data) || empty($data['schema']) || absint($data['schema']) !== self::FORMAT) self::redirect($redirect, 'داده قابل بازیابی در ZIP وجود ندارد.', 'error');
        $result = self::restore($data);
        if (is_wp_error($result)) self::redirect($redirect, $result->get_error_message(), 'error');
        MPH_Helpers::audit('backup_imported', 'options='.$result['options'].';tables='.$result['tables'].';posts='.$result['posts']);
        self::redirect($redirect, 'بازیابی کامل شد: '.$result['options'].' تنظیم، '.$result['tables'].' ردیف جدول و '.$result['posts'].' محتوای افزونه به‌روزرسانی شد.', 'success');
    }

    private static function collect() {
        global $wpdb;
        $option_like = $wpdb->esc_like('mph_') . '%';
        $options = $wpdb->get_results($wpdb->prepare("SELECT option_name,option_value,autoload FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name", $option_like), ARRAY_A);
        $table_like = $wpdb->esc_like($wpdb->prefix.'mph_') . '%';
        $table_names = (array)$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $table_like));
        $tables = array();
        foreach ($table_names as $table) {
            if (!self::safe_table($table)) continue;
            $tables[$table] = array('columns'=>(array)$wpdb->get_col('SHOW COLUMNS FROM `'.$table.'`', 0), 'rows'=>(array)$wpdb->get_results('SELECT * FROM `'.$table.'`', ARRAY_A));
        }
        $post_like = $wpdb->esc_like('mph_') . '%';
        $posts = (array)$wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->posts} WHERE post_type LIKE %s ORDER BY ID", $post_like), ARRAY_A);
        $post_ids = array_map('absint', wp_list_pluck($posts, 'ID'));
        $meta_where = "meta_key LIKE '_mph\\_%' OR meta_key LIKE 'mph\\_%'";
        if ($post_ids) $meta_where .= ' OR post_id IN ('.implode(',', $post_ids).')';
        $postmeta = (array)$wpdb->get_results("SELECT post_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE {$meta_where} ORDER BY meta_id", ARRAY_A);
        $cap_key = $wpdb->prefix.'capabilities';
        $usermeta = (array)$wpdb->get_results($wpdb->prepare("SELECT user_id,meta_key,meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE %s OR meta_key LIKE %s OR (meta_key=%s AND meta_value LIKE %s) ORDER BY umeta_id", $wpdb->esc_like('_mph_').'%', $wpdb->esc_like('mph_').'%', $cap_key, '%mph_%'), ARRAY_A);
        $external = array();
        $wc_meta = $wpdb->prefix.'wc_orders_meta';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wc_meta)) === $wc_meta) $external[$wc_meta] = (array)$wpdb->get_results("SELECT order_id,meta_key,meta_value FROM `{$wc_meta}` WHERE meta_key LIKE '_mph\\_%' OR meta_key LIKE 'mph\\_%' ORDER BY id", ARRAY_A);
        return array('schema'=>self::FORMAT,'plugin_version'=>MPH_VERSION,'table_prefix'=>$wpdb->prefix,'options'=>$options,'tables'=>$tables,'posts'=>$posts,'postmeta'=>$postmeta,'usermeta'=>$usermeta,'external_meta'=>$external);
    }

    private static function restore($data) {
        global $wpdb;
        $source_prefix=(string)($data['table_prefix']??$wpdb->prefix);
        if(!self::safe_table($source_prefix))$source_prefix=$wpdb->prefix;
        $stats = array('options'=>0,'tables'=>0,'posts'=>0);
        foreach ((array)($data['options'] ?? array()) as $row) {
            $name = sanitize_key($row['option_name'] ?? '');
            if (strpos($name, 'mph_') !== 0) continue;
            $ok = $wpdb->replace($wpdb->options, array('option_name'=>$name,'option_value'=>(string)($row['option_value'] ?? ''),'autoload'=>in_array(($row['autoload'] ?? 'no'),array('yes','no','auto','auto-on','auto-off'),true)?$row['autoload']:'no'), array('%s','%s','%s'));
            if ($ok !== false) { $stats['options']++; wp_cache_delete($name, 'options'); }
        }
        if (class_exists('MPH_Tickets')) MPH_Tickets::maybe_install();
        if (class_exists('MPH_Notices')) MPH_Notices::maybe_install();
        foreach ((array)($data['tables'] ?? array()) as $source_table=>$payload) {
            if(!self::safe_table($source_table))continue;
            $relative=strpos($source_table,$source_prefix)===0?substr($source_table,strlen($source_prefix)):'';
            if(strpos($relative,'mph_')!==0)continue;
            $table=$wpdb->prefix.$relative;
            if (!self::safe_table($table) || $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) continue;
            $columns = (array)$wpdb->get_col('SHOW COLUMNS FROM `'.$table.'`', 0);
            foreach ((array)($payload['rows'] ?? array()) as $row) {
                $clean = array_intersect_key((array)$row, array_flip($columns));
                if ($clean && $wpdb->replace($table, $clean) !== false) $stats['tables']++;
            }
        }
        $post_map = array();
        foreach ((array)($data['posts'] ?? array()) as $row) {
            $old_id = absint($row['ID'] ?? 0);$type = sanitize_key($row['post_type'] ?? '');
            if (!$old_id || strpos($type, 'mph_') !== 0) continue;
            $existing = get_post($old_id);
            $postarr = array_intersect_key((array)$row, array_flip(array('post_author','post_date','post_date_gmt','post_content','post_title','post_excerpt','post_status','comment_status','ping_status','post_password','post_name','to_ping','pinged','post_modified','post_modified_gmt','post_content_filtered','post_parent','menu_order','post_type','post_mime_type','comment_count')));
            $postarr['post_type'] = $type;
            if ($existing && strpos($existing->post_type, 'mph_') === 0) { $postarr['ID']=$old_id;$new_id=wp_update_post(wp_slash($postarr), true); }
            elseif (!$existing) { $postarr['import_id']=$old_id;$new_id=wp_insert_post(wp_slash($postarr), true); }
            else $new_id=wp_insert_post(wp_slash($postarr), true);
            if (!is_wp_error($new_id) && $new_id) { $post_map[$old_id]=absint($new_id);$stats['posts']++; }
        }
        $cleared = array();
        foreach ((array)($data['postmeta'] ?? array()) as $row) {
            $old_id=absint($row['post_id'] ?? 0);$post_id=$post_map[$old_id] ?? $old_id;$key=(string)($row['meta_key'] ?? '');
            if (!$post_id || !$key) continue;
            $plugin_post = isset($post_map[$old_id]);
            if (!$plugin_post && strpos($key,'_mph_')!==0 && strpos($key,'mph_')!==0) continue;
            $bucket=$post_id.'|'.$key;if(!isset($cleared[$bucket])){$wpdb->delete($wpdb->postmeta,array('post_id'=>$post_id,'meta_key'=>$key),array('%d','%s'));$cleared[$bucket]=1;}
            $wpdb->insert($wpdb->postmeta,array('post_id'=>$post_id,'meta_key'=>$key,'meta_value'=>(string)($row['meta_value'] ?? '')),array('%d','%s','%s'));
        }
        $cleared = array();
        foreach ((array)($data['usermeta'] ?? array()) as $row) {
            $user_id=absint($row['user_id'] ?? 0);$key=(string)($row['meta_key'] ?? '');if(!$user_id||!get_user_by('id',$user_id)||!$key)continue;
            if($key===$source_prefix.'capabilities')$key=$wpdb->prefix.'capabilities';
            if(strpos($key,'_mph_')!==0&&strpos($key,'mph_')!==0&&$key!==$wpdb->prefix.'capabilities')continue;
            if($key===$wpdb->prefix.'capabilities'){
                $incoming=maybe_unserialize((string)($row['meta_value']??''));if(!is_array($incoming))continue;
                $current=(array)get_user_meta($user_id,$key,true);$plugin_roles=array('mph_instructor','tutor_instructor','mph_therapist','mph_manager');
                foreach($plugin_roles as$role){unset($current[$role]);if(!empty($incoming[$role]))$current[$role]=true;}
                update_user_meta($user_id,$key,$current);continue;
            }
            $bucket=$user_id.'|'.$key;if(!isset($cleared[$bucket])){$wpdb->delete($wpdb->usermeta,array('user_id'=>$user_id,'meta_key'=>$key),array('%d','%s'));$cleared[$bucket]=1;}
            $wpdb->insert($wpdb->usermeta,array('user_id'=>$user_id,'meta_key'=>$key,'meta_value'=>(string)($row['meta_value'] ?? '')),array('%d','%s','%s'));
        }
        $external_cleared=array();
        foreach ((array)($data['external_meta'] ?? array()) as $source_table=>$rows) {
            if($source_table!==$source_prefix.'wc_orders_meta')continue;$table=$wpdb->prefix.'wc_orders_meta';
            if (!self::safe_table($table) || $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table)) !== $table) continue;
            foreach ((array)$rows as $row) {
                $order_id=absint($row['order_id'] ?? 0);$key=(string)($row['meta_key'] ?? '');if(!$order_id||(!$key)|| (strpos($key,'_mph_')!==0&&strpos($key,'mph_')!==0))continue;
                $bucket=$order_id.'|'.$key;if(!isset($external_cleared[$bucket])){$wpdb->delete($table,array('order_id'=>$order_id,'meta_key'=>$key),array('%d','%s'));$external_cleared[$bucket]=1;}
                $wpdb->insert($table,array('order_id'=>$order_id,'meta_key'=>$key,'meta_value'=>(string)($row['meta_value'] ?? '')),array('%d','%s','%s'));
            }
        }
        wp_cache_flush();
        return $stats;
    }

    private static function create_zip($path, $data_file, $manifest_file) {
        if (class_exists('ZipArchive')) {
            $zip=new ZipArchive();if($zip->open($path,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)return new WP_Error('zip','ساخت ZIP روی این سرور ممکن نیست.');
            $zip->addFile($data_file,self::DATA_FILE);$zip->addFile($manifest_file,self::MANIFEST_FILE);$zip->close();return true;
        }
        $zip=new PclZip($path);$result=$zip->create(array($data_file,$manifest_file),PCLZIP_OPT_REMOVE_ALL_PATH);return$result?true:new WP_Error('zip','کتابخانه ساخت ZIP در سرور در دسترس نیست.');
    }

    private static function read_zip($path) {
        if (class_exists('ZipArchive')) {
            $zip=new ZipArchive();if($zip->open($path)!==true)return new WP_Error('zip','فایل ZIP باز نشد.');
            if($zip->numFiles>20){$zip->close();return new WP_Error('zip','ZIP دارای فایل‌های غیرمنتظره است.');}
            for($i=0;$i<$zip->numFiles;$i++){$name=$zip->getNameIndex($i);if(strpos($name,'../')!==false||strpos($name,'\\')!==false||substr($name,0,1)==='/'){$zip->close();return new WP_Error('zip','مسیر ناامن در ZIP شناسایی شد.');}}
            $manifest=$zip->getFromName(self::MANIFEST_FILE);$data=$zip->getFromName(self::DATA_FILE);$zip->close();
        } else {
            require_once ABSPATH.'wp-admin/includes/class-pclzip.php';$zip=new PclZip($path);$list=$zip->extract(PCLZIP_OPT_BY_NAME,array(self::MANIFEST_FILE,self::DATA_FILE),PCLZIP_OPT_EXTRACT_AS_STRING);
            if(!is_array($list))return new WP_Error('zip','فایل ZIP باز نشد.');$manifest=false;$data=false;foreach($list as$item){if(($item['filename']??'')===self::MANIFEST_FILE)$manifest=$item['content']??false;if(($item['filename']??'')===self::DATA_FILE)$data=$item['content']??false;}
        }
        if(!is_string($manifest)||!is_string($data)||strlen($data)>self::MAX_IMPORT_SIZE)return new WP_Error('zip','فایل‌های لازم در ZIP وجود ندارند یا حجم داده نامعتبر است.');
        return array('manifest'=>$manifest,'data'=>$data);
    }

    private static function temp_dir() {
        $base=function_exists('get_temp_dir')?get_temp_dir():WP_CONTENT_DIR.'/';$path=trailingslashit($base).'mph-backup-'.wp_generate_password(16,false,false);
        return wp_mkdir_p($path)?$path:new WP_Error('tmp','ساخت پوشه موقت پشتیبان ممکن نیست.');
    }

    private static function cleanup($dir) {
        if(!is_string($dir)||strpos(basename($dir),'mph-backup-')!==0||!is_dir($dir))return;
        foreach((array)glob($dir.'/*')as$file)if(is_file($file))@unlink($file);
        @rmdir($dir);
    }

    private static function safe_table($table) {return is_string($table)&&preg_match('/^[A-Za-z0-9_]+$/',$table);}
    private static function can_manage() {return is_user_logged_in()&&(current_user_can('manage_options')||(class_exists('MPH_Manager')&&MPH_Manager::is_portal_super_admin()));}
    private static function redirect_target() {$fallback=admin_url('admin.php?page=mph-backup');return wp_validate_redirect(esc_url_raw(wp_unslash($_POST['redirect_to']??'')),$fallback);}
    private static function redirect($target,$message,$type) {$url=add_query_arg(array('mph_backup_notice'=>$message,'mph_backup_type'=>$type),$target);wp_safe_redirect($url);exit;}
}
