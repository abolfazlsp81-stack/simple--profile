<?php
defined('ABSPATH') || exit;

/** Server-side SMS gateway. Kavenegar contract: https://kavenegar.com/rest.html */
final class MPH_SMS {
    const OPTION = 'mph_sms_gateway_v1';
    const KEY_OPTION = 'mph_sms_api_key_v27';
    const STATUS_OPTION = 'mph_sms_status_v273';

    public static function init() {
        add_action('admin_post_mph_sms_settings', array(__CLASS__, 'save'));
        add_action('admin_post_mph_sms_test', array(__CLASS__, 'test'));
    }
    public static function providers() { return array('safir'=>'سفیر بله','kavenegar'=>'کاوه‌نگار','ippanel'=>'IPPanel'); }
    public static function settings() {
        return wp_parse_args((array)get_option(self::OPTION,array()),array('enabled'=>0,'provider'=>'safir','api_key'=>'','template'=>'','sender'=>'','otp'=>1,'order_paid'=>0,'receipt_status'=>0));
    }
    public static function enabled() { return !empty(self::settings()['enabled']); }
    private static function secret($s = null) {
        if (defined('MPH_SMS_API_KEY') && trim((string)MPH_SMS_API_KEY) !== '') return trim((string)MPH_SMS_API_KEY);
        $stored = MPH_Security::get_secret_option(self::KEY_OPTION,'');
        if ($stored !== '') return $stored;
        $s = is_array($s) ? $s : self::settings();
        return trim((string)($s['api_key'] ?? ''));
    }
    public static function ready_for_otp() {
        $s=self::settings();
        if (empty($s['enabled']) || empty($s['otp'])) return false;
        if ($s['provider']==='safir') return MPH_Safir::ready();
        if (!isset(self::providers()[$s['provider']]) || self::secret($s)==='') return false;
        return $s['provider']==='kavenegar' ? self::valid_template($s['template']) : trim($s['template'])!=='';
    }
    private static function valid_template($value) { return preg_match('/^[A-Za-z0-9-]{1,100}$/D',(string)$value)===1; }
    private static function record($kind,$ok,$message,$extra=array()) {
        $status=(array)get_option(self::STATUS_OPTION,array());
        $status[$kind]=array_merge(array('ok'=>(bool)$ok,'time'=>time(),'message'=>sanitize_text_field($message)),$extra);
        update_option(self::STATUS_OPTION,$status,false);
    }
    private static function failure($code,$message) {
        self::record('save',false,'ذخیره ناموفق بود: '.$message);
        return new WP_Error($code,$message);
    }

    /** Validation errors preserve the previous settings. No-op saves are successful. */
    public static function persist_settings($input) {
        $old=self::settings(); $old_key=self::secret($old);
        $provider=sanitize_key($input['provider']??'');
        if (!isset(self::providers()[$provider])) return self::failure('sms_provider','سرویس انتخاب‌شده معتبر نیست.');
        $submitted=preg_replace('/[\s\x{200B}-\x{200F}\x{FEFF}]+/u','',trim((string)($input['api_key']??'')));
        if (!is_string($submitted)) return self::failure('sms_key','فرمت کلید معتبر نیست.');
        if (defined('MPH_SMS_API_KEY') && trim((string)MPH_SMS_API_KEY)!=='' && $submitted!=='' && !hash_equals(trim((string)MPH_SMS_API_KEY),$submitted)) return self::failure('sms_constant','کلید در wp-config.php تعریف شده است؛ تعویض آن باید در همان فایل انجام شود.');
        $key=$submitted!==''?$submitted:$old_key;
        $s=array_merge($old,array('provider'=>$provider,'enabled'=>empty($input['enabled'])?0:1,'otp'=>empty($input['otp'])?0:1,'api_key'=>'','template'=>trim(sanitize_text_field($input['template']??'')),'sender'=>sanitize_text_field($input['sender']??''),'order_paid'=>empty($input['order_paid'])?0:1,'receipt_status'=>empty($input['receipt_status'])?0:1));
        if ($s['enabled'] && $provider!=='safir' && $key==='') return self::failure('sms_key','API Key وارد نشده است.');
        if ($s['enabled'] && $s['otp'] && $provider==='kavenegar' && !self::valid_template($s['template'])) return self::failure('sms_template','نام الگوی تأییدشده کاوه‌نگار را وارد کنید؛ نام انگلیسی بدون فاصله و زیرخط باشد.');
        if ($s['enabled'] && $s['otp'] && $provider==='ippanel' && ($s['template']==='' || $s['sender']==='')) return self::failure('sms_config','قالب و شماره فرستنده IPPanel کامل نیست.');
        if ($s['enabled'] && $s['otp'] && $provider==='safir' && !MPH_Safir::ready()) return self::failure('sms_config','تنظیمات سفیر بله کامل نیست.');
        $account=null;
        if ($provider==='kavenegar' && $s['enabled']) {
            $result=self::kavenegar_request($key,'account/info',array(),'GET');
            if (is_wp_error($result)) {
                self::record('connection',false,$result->get_error_message());
                return self::failure($result->get_error_code(),$result->get_error_message());
            }
            $account=isset($result['entries'][0])?$result['entries'][0]:$result['entries'];
            if (!is_array($account) || !isset($account['remaincredit']) || !is_numeric($account['remaincredit'])) return self::failure('sms_account','پاسخ اطلاعات حساب کاوه‌نگار ناقص بود؛ تنظیمات قبلی حفظ شد.');
        }
        $old_encrypted=get_option(self::KEY_OPTION,null);
        if ($key!=='' && !(defined('MPH_SMS_API_KEY') && trim((string)MPH_SMS_API_KEY)!=='')) {
            if (MPH_Security::encrypt($key)===$key) return self::failure('sms_crypto','رمزنگاری روی هاست فعال نیست؛ OpenSSL یا Sodium را فعال کنید.');
            MPH_Security::update_secret_option(self::KEY_OPTION,$key);
            if (!hash_equals($key,(string)MPH_Security::get_secret_option(self::KEY_OPTION,''))) return self::failure('sms_storage','ذخیره امن کلید در پایگاه داده ناموفق بود.');
        }
        update_option(self::OPTION,$s,false);
        if (get_option(self::OPTION)!==$s) {
            if ($old_encrypted===null) delete_option(self::KEY_OPTION); else update_option(self::KEY_OPTION,$old_encrypted,false);
            return self::failure('sms_storage','ثبت تنظیمات در پایگاه داده ناموفق بود.');
        }
        if ($old['provider']!==$provider || $old['template']!==$s['template'] || !hash_equals($old_key,$key)) {
            $status=(array)get_option(self::STATUS_OPTION,array()); unset($status['test']); update_option(self::STATUS_OPTION,$status,false);
        }
        $message='ذخیره موفق بود؛ تنظیمات OTP ثبت شد.';
        if ($account!==null) {
            self::record('connection',true,'اتصال حساب کاوه‌نگار تأیید شد.',array('credit_rial'=>(float)$account['remaincredit']));
            $message.=' اتصال حساب تأیید شد؛ برای بررسی قالب، ارسال آزمایشی را انجام دهید.';
        } else self::record('connection',false,'در این ذخیره، اتصال کاوه‌نگار آزمایش نشده است.');
        self::record('save',true,$message);
        MPH_Security::audit('sms_settings_updated','provider='.$provider.';enabled='.$s['enabled']);
        return $message;
    }
    public static function save() {
        if (!current_user_can('manage_options')) wp_die('دسترسی کافی ندارید.');
        check_admin_referer('mph_sms_settings');
        $result=self::persist_settings(wp_unslash($_POST));
        self::notice(is_wp_error($result)?'error':'success',is_wp_error($result)?'ذخیره ناموفق بود: '.$result->get_error_message():$result);
    }
    public static function test() {
        if (!current_user_can('manage_options')) wp_die('دسترسی کافی ندارید.');
        check_admin_referer('mph_sms_test');
        $phone=MPH_Helpers::phone(wp_unslash($_POST['test_phone']??''));
        if (!$phone) self::notice('error','شماره موبایل آزمون معتبر نیست.');
        $limit='mph_sms_test_'.get_current_user_id();
        if (get_transient($limit)) self::notice('error','برای آزمون بعدی یک دقیقه صبر کنید.');
        set_transient($limit,1,MINUTE_IN_SECONDS);
        $sent=self::send_otp($phone,(string)random_int(100000,999999));
        $message=is_wp_error($sent)?'ارسال آزمایشی ناموفق بود: '.$sent->get_error_message():'ارسال آزمایشی توسط سرویس پذیرفته شد؛ دریافت پیامک را روی تلفن بررسی کنید.';
        self::record('test',!is_wp_error($sent),$message,array('phone'=>substr($phone,0,4).'***'.substr($phone,-4)));
        self::notice(is_wp_error($sent)?'error':'success',$message);
    }
    public static function send_otp($phone,$code) {
        $s=self::settings();
        if (empty($s['enabled']) || empty($s['otp'])) return new WP_Error('sms_disabled','ارسال OTP فعال نیست.');
        $phone=MPH_Helpers::phone($phone); $code=MPH_Helpers::normalize_digits((string)$code);
        if (!$phone || !preg_match('/^\d{6}$/D',$code)) return new WP_Error('sms_input','شماره یا کد شش‌رقمی معتبر نیست.');
        if ($s['provider']==='safir') return MPH_Safir::send_otp_code($phone,$code);
        $key=self::secret($s);
        if ($key==='' || trim($s['template'])==='') return new WP_Error('sms_config','کلید API یا الگوی پیامک کامل نیست.');
        if ($s['provider']==='kavenegar') {
            if (!self::valid_template($s['template'])) return new WP_Error('sms_template','نام الگوی کاوه‌نگار معتبر نیست.');
            $result=self::kavenegar_request($key,'verify/lookup',array('receptor'=>$phone,'token'=>$code,'template'=>$s['template'],'type'=>'sms'),'POST');
            if (is_wp_error($result)) return $result;
            $entry=isset($result['entries'][0])?$result['entries'][0]:$result['entries'];
            if (!is_array($entry) || empty($entry['messageid']) || !is_numeric($entry['messageid']) || (float)$entry['messageid']<=0) return new WP_Error('sms_response','شناسه معتبر ارسال از کاوه‌نگار دریافت نشد.');
            if (isset($entry['status']) && in_array((int)$entry['status'],array(6,11,13,14,100),true)) return new WP_Error('sms_rejected','کاوه‌نگار پیامک را ناموفق اعلام کرد (وضعیت '.(int)$entry['status'].').');
            return true;
        }
        if ($s['provider']==='ippanel') {
            $response=wp_remote_post('https://edge.ippanel.com/v1/api/send',array('timeout'=>15,'redirection'=>0,'sslverify'=>true,'headers'=>array('Authorization'=>$key,'Content-Type'=>'application/json'),'body'=>wp_json_encode(array('sending_type'=>'pattern','from_number'=>$s['sender'],'code'=>$s['template'],'recipients'=>array('98'.substr($phone,1)),'params'=>array('code'=>$code))),'data_format'=>'body'));
            if (is_wp_error($response)) return new WP_Error('sms_network','ارتباط با سرویس پیامکی برقرار نشد.');
            $http=(int)wp_remote_retrieve_response_code($response); $body=json_decode(wp_remote_retrieve_body($response),true);
            if ($http<200 || $http>=300 || !is_array($body) || !empty($body['error']) || (isset($body['meta']['status']) && $body['meta']['status']===false)) return new WP_Error('sms_remote','ارسال توسط سرویس پیامکی تأیید نشد.');
            return true;
        }
        return new WP_Error('sms_provider','سرویس پیامکی معتبر نیست.');
    }
    private static function kavenegar_request($key,$method,$params,$verb) {
        $url='https://api.kavenegar.com/v1/'.rawurlencode($key).'/'.$method.'.json';
        $args=array('method'=>$verb,'timeout'=>15,'redirection'=>0,'sslverify'=>true,'headers'=>array('Accept'=>'application/json'),'limit_response_size'=>262144);
        if ($verb==='POST') $args['body']=$params;
        $response=wp_remote_request($url,$args);
        if (is_wp_error($response)) return new WP_Error('sms_network','ارتباط امن با کاوه‌نگار برقرار نشد؛ اتصال خروجی HTTPS و DNS هاست بررسی شود.');
        $http=(int)wp_remote_retrieve_response_code($response); $body=json_decode(wp_remote_retrieve_body($response),true);
        if (!is_array($body) || !isset($body['return']['status'])) return new WP_Error('sms_response','پاسخ سرویس قابل تشخیص نیست (HTTP '.$http.').');
        $status=(int)$body['return']['status'];
        if ($http<200 || $http>=300 || $status!==200) {
            $messages=array(400=>'پارامترهای درخواست ناقص است.',401=>'حساب کاوه‌نگار غیرفعال است.',403=>'کلید API معتبر نیست یا دسترسی آن مجاز نیست.',409=>'سرویس موقتاً پاسخگو نیست.',411=>'شماره گیرنده معتبر نیست.',412=>'شماره فرستنده معتبر نیست.',416=>'IP خروجی هاست با IP مجاز پنل کاوه‌نگار مطابقت ندارد.',418=>'اعتبار حساب کاوه‌نگار کافی نیست.',422=>'داده ارسالی معتبر نیست.',424=>'نام الگو اشتباه است یا هنوز تأیید نشده است.',426=>'سرویس اعتبارسنجی در پلن کاوه‌نگار شما فعال نیست.',428=>'کد برای تماس صوتی معتبر نیست.',429=>'IP هاست در کاوه‌نگار محدود شده است.',451=>'تعداد درخواست‌ها بیش از حد مجاز است؛ بعداً تلاش کنید.',501=>'حساب در حالت آزمایشی است؛ ارسال فقط به شماره مالک پنل مجاز است.',431=>'ساختار token معتبر نیست.',432=>'متن الگو باید شامل %token باشد.');
            $code=$status!==200?$status:$http;
            return new WP_Error('kavenegar_'.$code,'کاوه‌نگار '.$code.': '.($messages[$code]??'درخواست توسط سرویس رد شد؛ وضعیت پنل بررسی شود.'));
        }
        if (!isset($body['entries']) || !is_array($body['entries'])) return new WP_Error('sms_response','اطلاعات پاسخ کاوه‌نگار ناقص است.');
        return $body;
    }
    private static function notice($type,$message) {
        set_transient('mph_sms_notice_'.get_current_user_id(),array('type'=>$type,'message'=>$message),5*MINUTE_IN_SECONDS);
        wp_safe_redirect(add_query_arg(array('page'=>'mph-sms'),admin_url('admin.php'))); exit;
    }
    public static function admin_page() {
        if (!current_user_can('manage_options')) wp_die('دسترسی کافی ندارید.');
        $s=self::settings(); $status=(array)get_option(self::STATUS_OPTION,array());
        $notice=get_transient('mph_sms_notice_'.get_current_user_id()); delete_transient('mph_sms_notice_'.get_current_user_id());
        $rows=array('سرویس'=>self::providers()[$s['provider']]??$s['provider'],'مرکز پیامک'=>$s['enabled']?'فعال':'غیرفعال','OTP ورود و بازیابی'=>$s['otp']?'فعال':'غیرفعال','کلید API'=>self::secret($s)!==''?'ثبت شده؛ محرمانه':'ثبت نشده','منبع کلید'=>defined('MPH_SMS_API_KEY')&&MPH_SMS_API_KEY?'wp-config.php':'تنظیمات افزونه','نام الگو'=>$s['template']?:'ثبت نشده','فرستنده'=>$s['sender']?:'پیش‌فرض سرویس','آمادگی تنظیمات'=>self::ready_for_otp()?'کامل؛ نتیجه آزمون ارسال را بررسی کنید':'ناقص یا غیرفعال');
        ?>
        <div class="wrap mph-admin" dir="rtl">
          <header class="mph-admin-head"><span class="dashicons dashicons-smartphone"></span><div><h1>مرکز پیامک و OTP</h1><p>اتصال به پنل پیامکی و بررسی نتیجه ذخیره و ارسال</p></div></header>
          <?php if(is_array($notice)): ?><div class="notice notice-<?php echo esc_attr($notice['type']==='success'?'success':'error'); ?>"><p><?php echo esc_html($notice['message']); ?></p></div><?php endif; ?>
          <section class="mph-admin-box"><h2>تنظیمات ثبت‌شده OTP</h2><table class="widefat striped"><tbody>
          <?php foreach($rows as $label=>$value): ?><tr><th scope="row"><?php echo esc_html($label); ?></th><td><?php echo esc_html($value); ?></td></tr><?php endforeach; ?>
          <?php foreach(array('save'=>'آخرین ذخیره','connection'=>'آخرین بررسی اتصال','test'=>'آخرین ارسال آزمایشی') as $kind=>$label): $item=$status[$kind]??array(); ?><tr><th scope="row"><?php echo esc_html($label); ?></th><td><?php echo esc_html($item?$item['message'].' — '.wp_date('Y/m/d H:i',(int)$item['time']):'هنوز انجام نشده است'); ?><?php if(isset($item['credit_rial'])) echo '<br>'.esc_html('اعتبار گزارش‌شده: '.number_format_i18n($item['credit_rial']).' ریال'); ?><?php if(isset($item['phone'])) echo '<br><bdi>'.esc_html($item['phone']).'</bdi>'; ?></td></tr><?php endforeach; ?>
          </tbody></table></section>
          <form class="mph-admin-box" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="mph_sms_settings"><?php wp_nonce_field('mph_sms_settings'); ?>
            <h2>تنظیم اتصال</h2><div class="mph-admin-grid">
              <label>سرویس<select name="provider"><?php foreach(self::providers() as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($s['provider'],$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
              <label>API Key<input type="password" name="api_key" dir="ltr" autocomplete="new-password" placeholder="برای حفظ کلید قبلی خالی بگذارید"></label>
              <label>نام الگوی تأییدشده<input name="template" dir="ltr" value="<?php echo esc_attr($s['template']); ?>" placeholder="LoginOtp"></label>
              <label>شماره فرستنده (در OTP کاوه‌نگار لازم نیست)<input name="sender" dir="ltr" value="<?php echo esc_attr($s['sender']); ?>"></label>
            </div><div class="mph-admin-grid">
              <?php foreach(array('enabled'=>'فعال‌سازی مرکز پیامک','otp'=>'OTP ورود و بازیابی','order_paid'=>'پرداخت موفق (آماده اتصال به رویداد)','receipt_status'=>'نتیجه فیش (آماده اتصال به رویداد)') as $key=>$label): ?><label class="mph-switch-row"><span><?php echo esc_html($label); ?></span><input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked($s[$key]); ?>></label><?php endforeach; ?>
            </div><p>در پنل کاوه‌نگار یک الگوی تأییدشده با متن «کد ورود شما: %token» بسازید. اینجا نام الگو را بنویسید، نه متن پیامک یا شماره الگو. برای OTP کاوه‌نگار تنظیمات سفیر بله لازم نیست.</p>
            <p>ذخیره در حالت فعال، اتصال حساب را بدون ارسال پیامک بررسی می‌کند؛ آزمون زیر صحت ارسال با الگو را بررسی می‌کند.</p>
            <button class="button button-primary button-hero" type="submit">ذخیره و بررسی اتصال</button>
          </form>
          <form class="mph-admin-box" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="mph_sms_test"><?php wp_nonce_field('mph_sms_test'); ?>
            <h2>ارسال آزمایشی با تنظیمات ثبت‌شده</h2><p>یک پیامک واقعی با هزینه پنل ارسال می‌شود. این کد آزمایشی برای ورود به حساب قابل استفاده نیست.</p>
            <label>شماره موبایل خودتان<input name="test_phone" type="tel" dir="ltr" placeholder="09xxxxxxxxx" required></label>
            <button type="submit" class="button button-secondary">ارسال OTP آزمایشی</button>
          </form>
        </div>
        <?php
    }
}
