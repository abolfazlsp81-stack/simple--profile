<?php
defined('ABSPATH') || exit;

/** درخواست بازیابی رمز با تأیید مدیر و رمز یک‌بارمصرف. */
final class MPH_Password_Recovery {
    const POST_TYPE='mph_password_help';
    const DEFAULT_MINUTES=30;

    public static function init() {
        add_action('init',array(__CLASS__,'register_type'));
        add_action('wp_ajax_nopriv_mph_password_help_request',array(__CLASS__,'ajax_request'));
        add_action('wp_ajax_nopriv_mph_password_help_consume',array(__CLASS__,'ajax_consume'));
        add_action('wp_ajax_mph_password_help_decide_ajax',array(__CLASS__,'ajax_decide'));
        add_action('admin_menu',array(__CLASS__,'admin_menu'),20);
        add_action('admin_post_mph_password_help_decide',array(__CLASS__,'admin_decide'));
    }

    public static function register_type() {
        register_post_type(self::POST_TYPE,array('label'=>'درخواست‌های بازیابی رمز','public'=>false,'show_ui'=>false,'supports'=>array('title','author')));
    }

    public static function admin_menu() {
        $count=self::pending_count();$label='بازیابی رمز کاربران'.($count?' <span class="awaiting-mod count-'.$count.'"><span class="pending-count">'.$count.'</span></span>':'');
        add_submenu_page('mph','بازیابی رمز کاربران',$label,'manage_options','mph-password-recovery',array(__CLASS__,'admin_page'));
    }

    public static function ajax_request() {
        MPH_Helpers::verify_ajax();
        $phone=MPH_Helpers::phone(MPH_Helpers::posted('phone'));
        if(!$phone)wp_send_json_error(array('message'=>'شماره تلفن معتبر وارد کنید.'));
        if(!MPH_Security::allow('password_help_request',3,HOUR_IN_SECONDS,'p:'.hash('sha256',$phone).'|'.MPH_Security::request_fingerprint()))wp_send_json_error(array('message'=>'درخواست‌های زیادی ثبت شده است؛ یک ساعت بعد دوباره تلاش کنید.'),429);
        $user=MPH_Helpers::user_by_phone($phone);
        if($user){
            $existing=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>array('pending','private'),'author'=>$user->ID,'numberposts'=>1,'date_query'=>array(array('after'=>'24 hours ago')),'meta_query'=>array(array('key'=>'_mph_help_status','value'=>array('pending','approved'),'compare'=>'IN'))));
            if(!$existing){
                $id=wp_insert_post(array('post_type'=>self::POST_TYPE,'post_status'=>'pending','post_author'=>$user->ID,'post_title'=>'درخواست بازیابی رمز — '.MPH_Helpers::display_name($user)),true);
                if(!is_wp_error($id)){update_post_meta($id,'_mph_help_status','pending');update_post_meta($id,'_mph_help_phone_hash',hash_hmac('sha256',$phone,wp_salt('auth')));update_post_meta($id,'_mph_help_request_fingerprint',MPH_Security::request_fingerprint());MPH_Security::audit('password_help_requested','request='.$id,$user->ID);}
            }
        }
        wp_send_json_success(array('next'=>'help_sent','phone'=>$phone,'message'=>'اگر حساب معتبر باشد، درخواست در کارتابل مدیریت ثبت شد. پس از تأیید، رمز و جزئیات اعتبار به ایمیل حساب ارسال می‌شود.'));
    }

    public static function ajax_consume() {
        MPH_Helpers::verify_ajax();
        $phone=MPH_Helpers::phone(MPH_Helpers::posted('phone'));$code=preg_replace('/\D+/','',MPH_Helpers::normalize_digits(MPH_Helpers::posted('management_otp')));$password=MPH_Helpers::posted('password','raw');$repeat=MPH_Helpers::posted('password2','raw');
        if(!$phone||strlen($code)!==6)wp_send_json_error(array('message'=>'شماره تلفن و رمز شش‌رقمی را کامل وارد کنید.'));
        if($password!==$repeat||!MPH_Helpers::strong_password($password))wp_send_json_error(array('message'=>'رمز جدید باید حداقل ۱۰ کاراکتر و شامل حرف بزرگ، کوچک، عدد و نماد باشد.'));
        if(!MPH_Security::allow('password_help_consume',6,30*MINUTE_IN_SECONDS,'p:'.hash('sha256',$phone).'|'.MPH_Security::request_fingerprint()))wp_send_json_error(array('message'=>'تعداد تلاش بیش از حد مجاز است؛ ۳۰ دقیقه بعد دوباره تلاش کنید.'),429);
        $user=MPH_Helpers::user_by_phone($phone);if(!$user)wp_send_json_error(array('message'=>'رمز یک‌بارمصرف معتبر نیست یا منقضی شده است.'));
        $requests=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'private','author'=>$user->ID,'numberposts'=>1,'orderby'=>'date','order'=>'DESC','meta_query'=>array(array('key'=>'_mph_help_status','value'=>'approved'))));$request=$requests?$requests[0]:false;
        if(!$request||absint(get_post_meta($request->ID,'_mph_help_expires',true))<time()||get_post_meta($request->ID,'_mph_help_used',true))wp_send_json_error(array('message'=>'رمز یک‌بارمصرف معتبر نیست یا منقضی شده است.'));
        $attempts=absint(get_post_meta($request->ID,'_mph_help_attempts',true))+1;update_post_meta($request->ID,'_mph_help_attempts',$attempts);$hash=(string)get_post_meta($request->ID,'_mph_help_code_hash',true);
        if($attempts>5||!$hash||!wp_check_password($code,$hash))wp_send_json_error(array('message'=>'رمز یک‌بارمصرف معتبر نیست یا منقضی شده است.'));
        reset_password($user,$password);update_post_meta($request->ID,'_mph_help_status','used');update_post_meta($request->ID,'_mph_help_used',current_time('mysql'));delete_post_meta($request->ID,'_mph_help_code_hash');wp_set_current_user($user->ID);wp_set_auth_cookie($user->ID,true,is_ssl());MPH_Security::audit('password_help_consumed','request='.$request->ID,$user->ID);wp_send_json_success(array('sessionChanged'=>true,'message'=>'رمز یک‌بارمصرف تأیید شد؛ رمز جدید ذخیره و وارد حساب شدید.'));
    }

    public static function admin_decide() {
        if(!self::can_manage())wp_die('دسترسی ندارید.','',array('response'=>403));check_admin_referer('mph_password_help_decide');$id=absint($_POST['request_id']??0);$decision=sanitize_key(wp_unslash($_POST['decision']??''));$request=get_post($id);
        if(!$request||$request->post_type!==self::POST_TYPE)self::redirect_notice('درخواست معتبر نیست.','error');
        if((get_post_meta($id,'_mph_help_status',true)?:'pending')!=='pending')self::redirect_notice('این درخواست قبلاً بررسی شده است.','error');
        if(!in_array($decision,array('approve','reject'),true))self::redirect_notice('عملیات معتبر نیست.','error');
        if($decision==='reject'){update_post_meta($id,'_mph_help_status','rejected');wp_update_post(array('ID'=>$id,'post_status'=>'private'));MPH_Security::audit('password_help_rejected','request='.$id);self::redirect_notice('درخواست رد شد.','success');}
        $code=preg_replace('/\D+/','',MPH_Helpers::normalize_digits(sanitize_text_field(wp_unslash($_POST['one_time_code']??''))));if(strlen($code)!==6)self::redirect_notice('رمز یک‌بارمصرف باید دقیقاً شش رقم باشد.','error');
        $duration=self::duration_from_input($_POST['otp_minutes']??'');if(is_wp_error($duration))self::redirect_notice($duration->get_error_message(),'error');
        $approved=self::approve_and_mail($id,$request,$code,$duration);if(is_wp_error($approved))self::redirect_notice($approved->get_error_message(),'error');
        self::redirect_notice('رمز دستی ذخیره شد و همراه جزئیات اعتبار به ایمیل کاربر ارسال گردید.','success');
    }

    public static function ajax_decide() {
        MPH_Helpers::verify_ajax();if(!self::can_manage())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$id=absint($_POST['request_id']??0);$decision=MPH_Helpers::posted('decision','key');$request=get_post($id);if(!$request||$request->post_type!==self::POST_TYPE)wp_send_json_error(array('message'=>'درخواست معتبر نیست.'));
        if((get_post_meta($id,'_mph_help_status',true)?:'pending')!=='pending')wp_send_json_error(array('message'=>'این درخواست قبلاً بررسی شده است.'));
        if(!in_array($decision,array('approve','reject'),true))wp_send_json_error(array('message'=>'عملیات معتبر نیست.'));
        if($decision==='reject'){update_post_meta($id,'_mph_help_status','rejected');wp_update_post(array('ID'=>$id,'post_status'=>'private'));MPH_Security::audit('password_help_rejected','request='.$id);wp_send_json_success(array('message'=>'درخواست رد شد.','html'=>MPH_Manager::render('manage_requests')));}
        $code=preg_replace('/\D+/','',MPH_Helpers::normalize_digits(MPH_Helpers::posted('one_time_code')));if(strlen($code)!==6)wp_send_json_error(array('message'=>'رمز یک‌بارمصرف باید دقیقاً شش رقم باشد.'));
        $duration=self::duration_from_input($_POST['otp_minutes']??'');if(is_wp_error($duration))wp_send_json_error(array('message'=>$duration->get_error_message()));
        $approved=self::approve_and_mail($id,$request,$code,$duration);if(is_wp_error($approved))wp_send_json_error(array('message'=>$approved->get_error_message()));
        wp_send_json_success(array('message'=>'رمز دستی ذخیره شد و همراه جزئیات اعتبار به ایمیل کاربر ارسال گردید.','html'=>MPH_Manager::render('manage_requests')));
    }

    public static function manager_panel() {
        if(!self::can_manage())return'<div class="mph-empty">دسترسی ندارید.</div>';$items=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>array('pending','private'),'numberposts'=>50,'orderby'=>'date','order'=>'DESC'));ob_start(); ?>
        <section class="mph-section mph-manager-password-help"><div class="mph-section-heading"><div><h3>بازیابی رمز کاربران</h3><p>تأیید درخواست، تعیین رمز و مدت اعتبار دلخواه و ارسال خودکار ایمیل</p></div><span class="dashicons dashicons-unlock"></span></div><div class="mph-manager-summary"><div><b><?php echo self::pending_count(); ?></b><span>در انتظار بررسی</span></div><div><b>دلخواه</b><span>مدت اعتبار به دقیقه</span></div><div><b>۱</b><span>بار استفاده مجاز</span></div></div><div class="mph-manager-request-list"><?php if(!$items): ?><div class="mph-empty">درخواست بازیابی رمزی وجود ندارد.</div><?php endif;foreach($items as$item):$status=get_post_meta($item->ID,'_mph_help_status',true)?:'pending';if(!in_array($status,array('pending','approved'),true))continue;$user=get_user_by('id',$item->post_author); ?><div><span><?php echo get_avatar($user?$user->ID:0,42); ?><b><?php echo esc_html($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده'); ?></b><small><?php echo esc_html(($user?MPH_Helpers::profile_identifier($user):'—').' · '.self::status_label($status)); ?></small></span><?php if($status==='pending'): ?><div class="mph-manual-otp-actions"><details><summary class="mph-primary mph-otp-open-button"><span class="dashicons dashicons-admin-network"></span><span>تعیین رمز یک‌بارمصرف</span></summary><form data-mph-action="mph_password_help_decide_ajax"><input type="hidden" name="request_id" value="<?php echo absint($item->ID); ?>"><label>رمز دستی شش‌رقمی<input name="one_time_code" inputmode="numeric" maxlength="6" pattern="[0-9۰-۹]{6}" placeholder="مثلاً 583214" required></label><label>مدت اعتبار به دقیقه<input name="otp_minutes" inputmode="numeric" pattern="[0-9۰-۹]+" value="<?php echo self::DEFAULT_MINUTES; ?>" placeholder="مثلاً 30" required><small>هر تعداد دقیقه دلخواه قابل ثبت است.</small></label><button class="mph-primary" name="decision" value="approve"><span class="dashicons dashicons-email-alt"></span> ذخیره و ارسال ایمیل</button><div class="mph-message"></div></form></details><form data-mph-action="mph_password_help_decide_ajax"><input type="hidden" name="request_id" value="<?php echo absint($item->ID); ?>"><button class="mph-secondary" name="decision" value="reject">رد درخواست</button><div class="mph-message"></div></form></div><?php else:$minutes=absint(get_post_meta($item->ID,'_mph_help_minutes',true)); ?><em class="mph-status">ایمیل شد<?php echo $minutes?' · '.esc_html(number_format_i18n($minutes)).' دقیقه':''; ?></em><?php endif; ?></div><?php endforeach; ?></div></section><?php return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    public static function admin_page() {
        if(!self::can_manage())wp_die('دسترسی ندارید.');$items=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>array('pending','private'),'numberposts'=>100,'orderby'=>'date','order'=>'DESC'));$notice=sanitize_text_field(wp_unslash($_GET['mph_notice']??''));$type=sanitize_key(wp_unslash($_GET['mph_type']??'')); ?>
        <div class="wrap mph-admin mph-recovery-admin" dir="rtl"><header class="mph-admin-head"><span class="dashicons dashicons-unlock"></span><div><h1>درخواست‌های بازیابی رمز</h1><p>تأیید درخواست و تعیین دستی رمز یک‌بارمصرف توسط مدیر یا سوپرادمین</p></div></header>
        <?php if($notice): ?><div class="notice notice-<?php echo $type==='error'?'error':'success'; ?> is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
        <div class="mph-admin-metrics"><article><span class="dashicons dashicons-clock"></span><b><?php echo self::pending_count(); ?></b><small>در انتظار بررسی</small></article><article><span class="dashicons dashicons-admin-users"></span><b>دستی</b><small>تعیین رمز توسط مدیریت</small></article><article><span class="dashicons dashicons-shield"></span><b>دلخواه</b><small>اعتبار به دقیقه</small></article></div>
        <section class="mph-admin-box"><div class="mph-builder-head"><div><h2>کارتابل درخواست‌ها</h2><p>رمز و مدت اعتبار را تعیین کنید؛ پس از ارسال موفق ایمیل، فقط هش رمز در پایگاه داده نگهداری می‌شود.</p></div></div><div class="mph-recovery-grid"><?php if(!$items): ?><div class="mph-admin-empty"><span class="dashicons dashicons-yes-alt"></span><p>درخواستی وجود ندارد.</p></div><?php endif;foreach($items as$item):$user=get_user_by('id',$item->post_author);$status=get_post_meta($item->ID,'_mph_help_status',true)?:'pending'; ?><article class="is-<?php echo esc_attr($status); ?>"><header><?php echo get_avatar($user?$user->ID:0,52); ?><div><b><?php echo esc_html($user?MPH_Helpers::display_name($user):'کاربر حذف‌شده'); ?></b><small><?php echo esc_html($user?MPH_Helpers::profile_identifier($user):'—'); ?></small></div><em><?php echo esc_html(self::status_label($status)); ?></em></header><p><span class="dashicons dashicons-calendar-alt"></span><?php echo esc_html(get_the_date('Y/m/d H:i',$item)); ?></p><?php if($status==='pending'): ?><details class="mph-admin-manual-otp"><summary class="button button-primary mph-otp-open-button"><span class="dashicons dashicons-admin-network"></span> تعیین رمز یک‌بارمصرف</summary><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('mph_password_help_decide'); ?><input type="hidden" name="action" value="mph_password_help_decide"><input type="hidden" name="request_id" value="<?php echo absint($item->ID); ?>"><label>رمز یک‌بارمصرف شش‌رقمی<input name="one_time_code" inputmode="numeric" pattern="[0-9۰-۹]{6}" maxlength="6" required placeholder="مثلاً 583214"></label><label>مدت اعتبار به دقیقه<input name="otp_minutes" inputmode="numeric" pattern="[0-9۰-۹]+" value="<?php echo self::DEFAULT_MINUTES; ?>" required><small>سقف زمانی تعیین نشده است.</small></label><button class="button button-primary" name="decision" value="approve"><span class="dashicons dashicons-email-alt"></span> ذخیره و ارسال ایمیل</button></form></details><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="mph-recovery-reject"><?php wp_nonce_field('mph_password_help_decide'); ?><input type="hidden" name="action" value="mph_password_help_decide"><input type="hidden" name="request_id" value="<?php echo absint($item->ID); ?>"><button class="button" name="decision" value="reject">رد درخواست</button></form><?php elseif($status==='approved'):$minutes=absint(get_post_meta($item->ID,'_mph_help_minutes',true)); ?><div class="mph-recovery-expiry">رمز برای <?php echo esc_html(number_format_i18n($minutes)); ?> دقیقه ایمیل شده و تا <?php echo esc_html(wp_date('Y/m/d H:i',absint(get_post_meta($item->ID,'_mph_help_expires',true)),wp_timezone())); ?> معتبر است.</div><?php endif; ?></article><?php endforeach; ?></div></section></div><?php
    }

    private static function pending_count() {$counts=wp_count_posts(self::POST_TYPE);return$counts?absint($counts->pending):0;}
    private static function status_label($status) {$labels=array('pending'=>'در انتظار','approved'=>'رمز تعیین شد','used'=>'استفاده‌شده','rejected'=>'ردشده');return$labels[$status]??'نامشخص';}
    private static function duration_from_input($value) {
        $digits=ltrim(preg_replace('/\D+/','',MPH_Helpers::normalize_digits((string)$value)),'0');
        if($digits===''||!ctype_digit($digits))return new WP_Error('duration','مدت اعتبار را به دقیقه و بزرگ‌تر از صفر وارد کنید.');
        $technical_max=(int)floor((PHP_INT_MAX-time())/MINUTE_IN_SECONDS);$technical_max=max(1,$technical_max);$max_string=(string)$technical_max;
        if(strlen($digits)>strlen($max_string)||(strlen($digits)===strlen($max_string)&&strcmp($digits,$max_string)>0))return$technical_max;
        return max(1,(int)$digits);
    }
    private static function approve_and_mail($id,$request,$code,$minutes) {
        $user=get_user_by('id',$request->post_author);if(!$user)return new WP_Error('missing_user','حساب کاربر پیدا نشد.');
        if(!is_email($user->user_email)||substr((string)$user->user_email,-8)==='.invalid')return new WP_Error('missing_email','برای این حساب ایمیل معتبر ثبت نشده است؛ ابتدا ایمیل کاربر را تکمیل کنید.');
        $minutes=max(1,(int)$minutes);$expires=time()+($minutes*MINUTE_IN_SECONDS);$site=wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES);$url=MPH_Helpers::clean_auth_url(array('mph_help'=>1));
        $subject='رمز یک‌بارمصرف بازیابی | '.$site;
        $body=MPH_Helpers::display_name($user)." گرامی،\n\nدرخواست بازیابی رمز شما توسط مدیریت تأیید شد.\n\nرمز یک‌بارمصرف: {$code}\nمدت اعتبار: ".number_format_i18n($minutes)." دقیقه\nزمان پایان اعتبار: ".wp_date('Y/m/d H:i',$expires,wp_timezone())."\nشماره درخواست: #".absint($id)."\n\nبرای تعیین رمز عبور جدید وارد این نشانی شوید:\n{$url}\n\nاین رمز فقط یک‌بار قابل استفاده است. اگر این درخواست متعلق به شما نیست، آن را نادیده بگیرید و با مدیریت تماس بگیرید.";
        if(!wp_mail($user->user_email,$subject,$body,self::management_headers()))return new WP_Error('mail_failed','ارسال ایمیل انجام نشد؛ تنظیمات ایمیل مدیریت یا SMTP را بررسی کنید. درخواست همچنان در انتظار باقی ماند.');
        update_post_meta($id,'_mph_help_code_hash',wp_hash_password($code));update_post_meta($id,'_mph_help_expires',$expires);update_post_meta($id,'_mph_help_minutes',$minutes);update_post_meta($id,'_mph_help_attempts',0);update_post_meta($id,'_mph_help_status','approved');delete_post_meta($id,'_mph_help_used');wp_update_post(array('ID'=>$id,'post_status'=>'private'));
        MPH_Security::audit('password_help_approved','request='.$id.';minutes='.$minutes.';email='.MPH_Security::mask_email($user->user_email).';set_by='.get_current_user_id(),$user->ID);return true;
    }
    public static function management_headers() {$email=sanitize_email(get_option('admin_email'));$name=wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES);return$email?array('From: '.$name.' <'.$email.'>','Reply-To: '.$name.' <'.$email.'>'):array();}
    private static function can_manage() {return is_super_admin(get_current_user_id())||current_user_can('manage_options')||current_user_can('mph_manage_support');}
    private static function redirect_notice($message,$type) {wp_safe_redirect(add_query_arg(array('page'=>'mph-password-recovery','mph_notice'=>$message,'mph_type'=>$type),admin_url('admin.php')));exit;}
}
