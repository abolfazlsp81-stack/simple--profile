<?php
defined('ABSPATH') || exit;

final class MPH_Commerce {
    const RECEIPT_META = '_mph_receipt_payment';
    const RECEIPT_STATUS = '_mph_receipt_status';
    const RECEIPT_FILE = '_mph_receipt_file_id';
    const MAX_RECEIPT_SIZE = 2097152;

    public static function init() {
        add_action('wp_ajax_mph_cart_remove', array(__CLASS__, 'ajax_remove'));
        add_action('wp_ajax_mph_checkout_prepare', array(__CLASS__, 'ajax_checkout_prepare'));
        add_action('wp_ajax_mph_select_course_mode', array(__CLASS__, 'ajax_select_course_mode'));
        add_action('wp_ajax_mph_receipt_submit', array(__CLASS__, 'ajax_submit_receipt'));
        add_action('wp_ajax_mph_receipt_decision', array(__CLASS__, 'ajax_receipt_decision'));
        add_action('admin_post_mph_receipt_file', array(__CLASS__, 'download_receipt'));
        add_filter('woocommerce_add_to_cart_redirect', array(__CLASS__, 'cart_redirect'));
        add_filter('woocommerce_get_return_url', array(__CLASS__, 'payment_return'), 20, 2);
        add_filter('woocommerce_get_checkout_order_received_url', array(__CLASS__, 'payment_return'), 20, 2);
        add_action('template_redirect', array(__CLASS__, 'redirect_native_cart'), 20);
    }

    public static function render() {
        if (!self::ensure_cart()) return '<div class="mph-empty mph-commerce-warning"><span class="dashicons dashicons-cart"></span><p>برای استفاده از سبد خرید اختصاصی، افزونه WooCommerce را فعال کنید.</p></div>';
        $choose=absint($_GET['mph_choose_course']??0);
        $selector=$choose?MPH_Courses::mode_selector($choose):'';
        if($selector){
            return '<div class="mph-cart mph-cart-flow mph-mode-flow" data-mph-cart-flow data-initial-cart-stage="mode"><ol class="mph-cart-steps" aria-label="مراحل خرید"><li class="is-active" data-mph-cart-step="mode"><span>۱</span><b>انتخاب شیوه</b></li><li><span>۲</span><b>بررسی سبد</b></li><li><span>۳</span><b>صورتحساب و پرداخت</b></li></ol><section class="mph-cart-stage is-active" data-mph-cart-stage="mode">'.$selector.'</section></div>';
        }
        $normalized=false;foreach(WC()->cart->get_cart()as$key=>$row)if(absint($row['quantity']??1)!==1){WC()->cart->set_quantity($key,1,false);$normalized=true;}if($normalized)self::persist_cart();
        $items = WC()->cart->get_cart();$unavailable=MPH_Shared_Cart::unavailable();
        if (!$items) {
            $pending = self::pending_orders(get_current_user_id());
            $courses_url = MPH_Courses::courses_archive_url();
            return $unavailable . ($pending ? self::pending_order_notice($pending) : '') . '<div class="mph-empty mph-empty-cart"><span class="dashicons dashicons-cart"></span><h4>سبد خرید شما خالی است</h4><p>دوره یا محصول موردنظر را به سبد خرید اضافه کنید.</p><a class="mph-native-link" href="' . esc_url($courses_url) . '">مشاهده دوره‌ها</a></div>';
        }
        $user = wp_get_current_user();
        $phone = get_user_meta($user->ID, 'mph_phone', true);
        $address = get_user_meta($user->ID, 'mph_address', true);
        $postal = get_user_meta($user->ID, 'mph_postal_code', true);
        $email = substr((string)$user->user_email,-8)==='.invalid'?'':$user->user_email;
        $card = trim((string) MPH_Security::get_secret_option('mph_bank_card_number', ''));
        $card_owner = trim((string) MPH_Security::get_secret_option('mph_bank_card_owner', ''));
        $online_gateways = self::online_gateway_names();
        WC()->cart->calculate_totals();
        $is_free = (float) WC()->cart->get_total('edit') <= 0.0001;
        ob_start(); ?>
        <div class="mph-cart mph-cart-flow" data-mph-cart-flow data-initial-cart-stage="cart">
            <ol class="mph-cart-steps" aria-label="مراحل خرید">
                <li class="is-complete"><span>۱</span><b>انتخاب شیوه</b></li>
                <li class="is-active" data-mph-cart-step="cart"><span>۲</span><b>بررسی سبد</b></li>
                <li data-mph-cart-step="checkout"><span>۳</span><b>صورتحساب و پرداخت</b></li>
            </ol>
            <section class="mph-cart-stage is-active" data-mph-cart-stage="cart">
                <div class="mph-cart-stage-heading"><div><small>مرحله دوم</small><h4>بررسی انتخاب‌های شما</h4><p>می‌توانید دوره یا نوبت دیگری اضافه کنید و انتخاب‌ها را یک‌جا پرداخت کنید.</p></div></div>
                <div class="mph-cart-list"><?php echo $unavailable; ?>
                <?php foreach ($items as $key => $item) : $product = isset($item['data']) && is_object($item['data']) ? $item['data'] : false;if (!$product || !$product->exists()) continue; ?>
                    <article class="mph-cart-item">
                        <a class="mph-cart-thumb" href="<?php echo esc_url($product->get_permalink($item)); ?>"><?php echo $product->get_image('woocommerce_thumbnail'); ?></a>
                        <div class="mph-cart-info"><h4><a href="<?php echo esc_url($product->get_permalink($item)); ?>"><?php echo esc_html($product->get_name()); ?></a></h4><span class="mph-cart-price"><?php echo wp_kses_post(WC()->cart->get_product_price($product)); ?></span><?php echo wp_kses_post(wc_get_formatted_cart_item_data($item)); ?></div>
                        <div class="mph-cart-subtotal"><?php echo wp_kses_post(WC()->cart->get_product_subtotal($product, $item['quantity'])); ?></div>
                        <form data-mph-action="mph_cart_remove" class="mph-cart-remove"><input type="hidden" name="cart_key" value="<?php echo esc_attr($key); ?>"><button type="submit" class="mph-icon-danger" aria-label="حذف از سبد خرید"><span class="dashicons dashicons-trash"></span></button><div class="mph-message"></div></form>
                    </article>
                <?php endforeach; ?>
                </div>
                <div class="mph-cart-stage-actions"><a class="mph-secondary" href="<?php echo esc_url(MPH_Courses::courses_archive_url()); ?>">افزودن دوره دیگر</a><button type="button" class="mph-primary mph-cart-next" data-mph-cart-next><span>مرحله سوم؛ صورتحساب</span><span class="dashicons dashicons-arrow-left-alt2"></span></button></div>
            </section>
            <section class="mph-cart-stage" data-mph-cart-stage="checkout" hidden>
                <button type="button" class="mph-cart-back" data-mph-cart-back><span class="dashicons dashicons-arrow-right-alt2"></span> بازگشت به سبد</button>
                <div class="mph-checkout-layout">
                    <div class="mph-checkout-main">
                        <div class="mph-cart-stage-heading"><div><small>مرحله سوم و پایانی</small><h4>صورتحساب، تخفیف و پرداخت</h4><p>اطلاعات را بررسی کنید، روش پرداخت را انتخاب کنید و خرید را به پایان برسانید؛ ایمیل اختیاری است.</p></div></div>
                        <div class="mph-order-review">
                            <?php foreach ($items as $key => $item) : $product = isset($item['data']) && is_object($item['data']) ? $item['data'] : false;if (!$product || !$product->exists()) continue; ?>
                                <article class="mph-order-review-item">
                                    <div class="mph-order-review-product"><?php echo $product->get_image('woocommerce_thumbnail'); ?><div><b><?php echo esc_html($product->get_name()); ?></b><small><?php echo wp_kses_post(WC()->cart->get_product_price($product)); ?></small></div></div>
                                    <div class="mph-cart-subtotal"><?php echo wp_kses_post(WC()->cart->get_product_subtotal($product, $item['quantity'])); ?></div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                        <?php if (!$is_free) : ?><section class="mph-invoice-box" data-mph-invoice-fields><div class="mph-section-heading"><div><h4>اطلاعات صورتحساب</h4><p>پیش از پرداخت بررسی و در صورت نیاز ویرایش کنید.</p></div><span class="dashicons dashicons-media-spreadsheet"></span></div><div class="mph-billing-fields"><label>نام <input name="billing_first_name" value="<?php echo esc_attr($user->first_name); ?>" autocomplete="given-name" required><small class="mph-field-error"></small></label><label>نام خانوادگی <input name="billing_last_name" value="<?php echo esc_attr($user->last_name); ?>" autocomplete="family-name" required><small class="mph-field-error"></small></label><label>موبایل <input name="billing_phone" value="<?php echo esc_attr($phone); ?>" inputmode="numeric" maxlength="11" autocomplete="tel" required><small class="mph-field-error"></small></label><label>ایمیل <small>(اختیاری)</small><input type="email" name="billing_email" value="<?php echo esc_attr($email); ?>" autocomplete="email"><small class="mph-field-error"></small></label><label>کد پستی <input name="billing_postcode" value="<?php echo esc_attr($postal); ?>" inputmode="numeric" maxlength="10" autocomplete="postal-code"><small class="mph-field-error"></small></label><label class="is-wide">آدرس کامل <textarea name="billing_address_1" autocomplete="street-address" required><?php echo esc_textarea($address); ?></textarea><small class="mph-field-error"></small></label></div><div class="mph-billing-valid" data-mph-billing-valid><span class="dashicons dashicons-yes-alt"></span> اطلاعات به‌صورت لحظه‌ای بررسی می‌شود.</div></section><?php else: ?><div class="mph-free-order-ready"><span class="dashicons dashicons-awards"></span><div><h4>این خرید کاملاً رایگان شد</h4><p>کد تخفیف صددرصدی اعمال شده است؛ نیازی به اطلاعات صورتحساب، درگاه یا فیش ندارید.</p></div></div><?php endif; ?>
                    </div>
                    <aside class="mph-cart-summary">
                        <h4>خلاصه سفارش</h4><div><span>جمع محصولات</span><b><?php echo wp_kses_post(WC()->cart->get_cart_subtotal()); ?></b></div>
                        <?php if (WC()->cart->get_discount_total() > 0) : ?><div class="mph-cart-discount"><span>تخفیف</span><b>− <?php echo wp_kses_post(wc_price(WC()->cart->get_discount_total())); ?></b></div><?php endif; ?>
                        <div class="mph-cart-total"><span>مبلغ قابل پرداخت</span><b><?php echo wp_kses_post(WC()->cart->get_total()); ?></b></div><?php if (!$is_free) echo MPH_Discounts::cart_form(); ?>
                        <?php if ($is_free) : ?><form class="mph-free-checkout" data-mph-action="mph_checkout_prepare"><button class="mph-checkout-button is-free" type="submit"><span class="dashicons dashicons-saved"></span> ثبت خرید و فعال‌سازی دوره</button><div class="mph-message" aria-live="polite"></div></form><?php else: ?><div class="mph-payment-choice" data-payment-choice><h5>روش پرداخت</h5><label><input type="radio" name="mph_payment_preview" value="online" checked> پرداخت آنلاین</label><label><input type="radio" name="mph_payment_preview" value="receipt"> ارسال فیش واریزی</label></div>
                        <form class="mph-online-checkout" data-online-payment data-mph-action="mph_checkout_prepare"><?php echo MPH_Checkout::gateway_select(); ?><button class="mph-checkout-button" type="submit"><span class="dashicons dashicons-lock"></span> ساخت سفارش و ادامه به پرداخت <?php if($online_gateways): ?><small>(<?php echo esc_html(implode(' / ', $online_gateways)); ?>)</small><?php endif; ?></button><div class="mph-message" aria-live="polite"></div></form>
                        <form class="mph-receipt-payment" data-receipt-payment data-mph-action="mph_receipt_submit" enctype="multipart/form-data" hidden>
                            <div class="mph-bank-card"><small>شماره کارت مجموعه</small><b dir="ltr"><?php echo esc_html($card ?: 'در تنظیمات مدیریت وارد نشده'); ?></b><?php if($card_owner): ?><strong><?php echo esc_html($card_owner); ?></strong><?php endif; ?><button type="button" data-copy-card data-card="<?php echo esc_attr(preg_replace('/\s+/', '', $card)); ?>">کپی شماره کارت</button></div>
                            <?php if (!$card || !$card_owner) : ?><div class="mph-message is-error">مدیر سایت باید شماره کارت و نام صاحب کارت را در تنظیمات پنل مدیر وارد کند.</div><?php endif; ?>
                            <label>فایل فیش <small>حداکثر ۲ مگابایت</small><input type="file" name="receipt_file" data-mph-max-file="2097152" accept="image/jpeg,image/png,image/webp,application/pdf" required></label>
                            <button class="mph-checkout-button" type="submit" <?php disabled(!$card||!$card_owner); ?>><span class="dashicons dashicons-upload"></span> ثبت سفارش و ارسال فیش</button><div class="mph-message"></div>
                        </form><?php endif; ?>
                    </aside>
                </div>
            </section>
        </div><?php echo MPH_Courses::browse_courses_link();return ob_get_clean();
    }

    public static function section() {$count=self::cart_count();return '<section class="mph-section mph-cart-section"><div class="mph-section-heading"><div><h3>سبد خرید</h3><p>سبد، صورتحساب و انتخاب روش پرداخت</p></div><span class="mph-cart-heading-icon"><span class="dashicons dashicons-cart"></span><b data-mph-cart-count>'.absint($count).'</b></span></div>' . self::render() . '</section>';}

    public static function pending_courses($user_id) {
        if (!function_exists('wc_get_orders')) return '';
        $orders = self::pending_orders($user_id);$courses=array();
        foreach($orders as $order)foreach($order->get_items() as $item){$course_id=self::course_by_product($item->get_product_id());if($course_id)$courses[$course_id]=$order->get_id();}
        if(!$courses)return '';
        ob_start(); ?><div class="mph-pending-courses"><div class="mph-section-heading"><div><h4>دوره‌های در انتظار تأیید پرداخت</h4><p>پس از تأیید فیش توسط مدیر، دسترسی دوره به‌طور خودکار فعال می‌شود.</p></div><span class="dashicons dashicons-clock"></span></div><div class="mph-course-grid"><?php foreach($courses as $course_id=>$order_id): ?><article class="mph-course-card mph-course-pending"><div class="mph-pending-course-media"><?php echo get_the_post_thumbnail($course_id,'medium')?:'<span class="mph-course-placeholder dashicons dashicons-welcome-learn-more"></span>'; ?><span>در انتظار تأیید</span></div><div><h4><?php echo esc_html(get_the_title($course_id)); ?></h4><p>سفارش #<?php echo absint($order_id); ?> ثبت شده و هنوز فعال نیست.</p></div></article><?php endforeach; ?></div></div><?php return ob_get_clean();
    }

    public static function render_manager() {
        if(!self::can_manage())return '<div class="mph-empty">دسترسی ندارید.</div>';
        $orders=function_exists('wc_get_orders')?wc_get_orders(array('limit'=>100,'orderby'=>'date','order'=>'DESC','meta_key'=>self::RECEIPT_META,'meta_value'=>'yes')):array();
        ob_start(); ?><section class="mph-section mph-receipt-manager"><div class="mph-section-heading"><div><h3>تأیید فیش‌های واریزی</h3><p>تا زمان تأیید شما، سفارش و دسترسی دوره معلق باقی می‌ماند.</p></div><span class="dashicons dashicons-yes-alt"></span></div><div class="mph-receipt-list"><?php if(!$orders)echo '<div class="mph-empty"><p>فیش واریزی ثبت نشده است.</p></div>';foreach($orders as $order):$status=$order->get_meta(self::RECEIPT_STATUS)?:'pending';$file_id=absint($order->get_meta(self::RECEIPT_FILE));$user=get_user_by('id',$order->get_customer_id()); ?><article class="mph-receipt-card is-<?php echo esc_attr($status); ?>"><header><div><b>سفارش #<?php echo esc_html($order->get_order_number()); ?></b><small><?php echo esc_html($user?MPH_Helpers::display_name($user):$order->get_formatted_billing_full_name()); ?> · <?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></small></div><span><?php echo esc_html(self::receipt_status_label($status)); ?></span></header><div class="mph-receipt-products"><?php foreach($order->get_items() as $item)echo '<span>'.esc_html($item->get_name()).' × '.absint($item->get_quantity()).'</span>'; ?></div><div class="mph-receipt-footer"><b><?php echo wp_kses_post($order->get_formatted_order_total()); ?></b><?php if($file_id): ?><a class="mph-native-link" href="<?php echo esc_url(self::receipt_url($order->get_id(),$file_id)); ?>"><span class="dashicons dashicons-download"></span> مشاهده فیش</a><?php endif; ?><?php if($status==='pending'): ?><form data-mph-action="mph_receipt_decision"><input type="hidden" name="order_id" value="<?php echo absint($order->get_id()); ?>"><button class="mph-primary" name="decision" value="approve">تأیید و فعال‌سازی</button><button class="mph-secondary" name="decision" value="reject">رد فیش</button><div class="mph-message"></div></form><?php endif; ?></div></article><?php endforeach; ?></div></section><?php return ob_get_clean();
    }

    public static function manager_pending_count(){if(!function_exists('wc_get_orders'))return 0;return count(wc_get_orders(array('limit'=>100,'return'=>'ids','meta_key'=>self::RECEIPT_STATUS,'meta_value'=>'pending')));}

    public static function ajax_remove() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in() || !self::ensure_cart()) wp_send_json_error(array('message'=>'سبد خرید در دسترس نیست.'),403);
        $key=MPH_Helpers::posted('shared_key');$instance='';
        if (!$key) {$row=WC()->cart->get_cart_item(MPH_Helpers::posted('cart_key'));$key=$row['mph_shared_key']??'';$instance=$row['mph_shared_instance']??'';}
        if (!$key) wp_send_json_error(array('message'=>'این انتخاب قبلاً حذف شده است.'));
        $result=MPH_Shared_Cart::remove(get_current_user_id(),$key,$instance);
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()),409);
        self::persist_cart();
        wp_send_json_success(array('message'=>'انتخاب از سبد حذف شد.','html'=>self::section(),'cartCount'=>self::cart_count(),'cartStage'=>'cart'));
    }

    public static function ajax_select_course_mode() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in() || !self::ensure_cart()) wp_send_json_error(array('message'=>'ابتدا وارد حساب شوید.'),403);
        $product=MPH_Courses::product_for_mode(absint($_POST['course_id']??0),MPH_Helpers::posted('delivery_mode','key'));
        if (!$product) wp_send_json_error(array('message'=>'این شیوه فروش فعال نیست.'));
        $result=MPH_Shared_Cart::add(get_current_user_id(),array('product_id'=>$product->get_id()));
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()),409);
        self::persist_cart();
        wp_send_json_success(array('message'=>'دوره به سبد اضافه شد؛ انتخاب‌های قبلی محفوظ‌اند.','html'=>self::section(),'cartCount'=>self::cart_count(),'cartStage'=>'cart'));
    }

    public static function ajax_checkout_prepare() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in() || !self::ensure_cart()) wp_send_json_error(array('message'=>'ابتدا وارد حساب شوید.'),403);
        WC()->cart->calculate_totals();$user=wp_get_current_user();
        $billing=(float)WC()->cart->get_total('edit')<=0.0001?self::billing_from_profile($user):self::billing_from_request($user);
        if (is_wp_error($billing)) wp_send_json_error(array('message'=>$billing->get_error_message()));
        self::save_billing($user,$billing);
        $result=MPH_Checkout::submit($user,$billing,'online',MPH_Helpers::posted('gateway_id','key'));
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()),409);
        wp_send_json_success($result);
    }

    public static function ajax_submit_receipt() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in() || !self::ensure_cart()) wp_send_json_error(array('message'=>'ابتدا وارد حساب شوید.'),403);
        if (!MPH_Security::get_secret_option('mph_bank_card_number') || !MPH_Security::get_secret_option('mph_bank_card_owner')) wp_send_json_error(array('message'=>'اطلاعات کارت مجموعه کامل نیست.'));
        $user=wp_get_current_user();$billing=self::billing_from_request($user);
        if (is_wp_error($billing)) wp_send_json_error(array('message'=>$billing->get_error_message()));
        self::save_billing($user,$billing);
        $result=MPH_Checkout::submit($user,$billing,'receipt','',array(__CLASS__,'upload_receipt'));
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()),409);
        wp_send_json_success($result);
    }

    public static function ajax_receipt_decision(){
        MPH_Helpers::verify_ajax();
        if(!self::can_manage()||!function_exists('wc_get_order'))wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);
        $order=wc_get_order(absint($_POST['order_id']??0));$decision=MPH_Helpers::posted('decision','key');
        if(!$order||$order->get_meta(self::RECEIPT_META)!=='yes'||$order->get_meta(self::RECEIPT_STATUS)!=='pending')wp_send_json_error(array('message'=>'سفارش در انتظار پیدا نشد.'));
        $access_error='';$is_appointment=(bool)MPH_Appointment_Cart::order_ids($order);if($decision==='approve'){$holds=MPH_Appointment_Cart::ensure_holds($order);if(is_wp_error($holds))wp_send_json_error(array('message'=>'ظرفیت نوبت نیازمند بررسی است؛ پرداخت را بدون تعیین تکلیف تأیید نکنید. '.$holds->get_error_message()),409);}
        if($decision==='approve'){
            $order->update_meta_data(self::RECEIPT_STATUS,'approved');MPH_Helpers::audit('receipt_approved','order='.$order->get_id());$order->save();$order->payment_complete();$order->update_status('completed','فیش توسط مدیر تأیید شد.');$order->save();MPH_Courses::grant_order_access($order->get_id(),true);MPH_Payment_Attempts::event($order,'receipt_approved','فیش توسط مدیر تأیید شد.');
            if($is_appointment){MPH_Appointments::handle_receipt_decision($order,'approve');$message='فیش نوبت #'.$order->get_order_number().' تأیید و رزرو قطعی شد.';}
            else{$grant=MPH_Courses::grant_order_access($order->get_id(),true);delete_user_meta($order->get_customer_id(),'_mph_access_repair_at');if(is_wp_error($grant))$access_error=$grant->get_error_message();$message='فیش سفارش #'.$order->get_order_number().' تأیید شد'.($access_error?'؛ اما فعال‌سازی خودکار دوره نیازمند بررسی مدیر است.':' و دسترسی دوره شما فعال گردید.');}
        }elseif($decision==='reject'){
            $order->update_meta_data(self::RECEIPT_STATUS,'rejected');MPH_Helpers::audit('receipt_rejected','order='.$order->get_id());$order->update_status('failed','فیش توسط مدیر رد شد.');$order->save();if($is_appointment)MPH_Appointments::handle_receipt_decision($order,'reject');$message='فیش سفارش #'.$order->get_order_number().' تأیید نشد. لطفاً با پشتیبانی تماس بگیرید.';
        }else wp_send_json_error(array('message'=>'عملیات معتبر نیست.'));
        MPH_Tickets::create_system_notification($order->get_customer_id(),$decision==='approve'?'پرداخت تأیید شد':'پرداخت تأیید نشد',$message,'payment');
        wp_send_json_success(array('message'=>$decision==='approve'?($is_appointment?'فیش تأیید و نوبت قطعی شد.':($access_error?'فیش تأیید شد؛ خطای اتصال دوره در یادداشت سفارش ثبت شد.':'فیش تأیید و دوره در پنل کاربر فعال شد.')):'فیش رد شد.','html'=>self::render_manager()));
    }

    public static function download_receipt(){if(!is_user_logged_in())auth_redirect();$order_id=absint($_GET['order_id']??0);$file_id=absint($_GET['file_id']??0);$nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));if(!$order_id||!$file_id||!wp_verify_nonce($nonce,'mph_receipt_'.$order_id.'_'.$file_id))wp_die('لینک معتبر نیست.','',array('response'=>403));$order=function_exists('wc_get_order')?wc_get_order($order_id):false;if(!$order||absint($order->get_meta(self::RECEIPT_FILE))!==$file_id||($order->get_customer_id()!==get_current_user_id()&&!self::can_manage()))wp_die('دسترسی ندارید.','',array('response'=>403));$path=get_attached_file($file_id);if(!$path||!is_readable($path))wp_die('فایل پیدا نشد.','',array('response'=>404));while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: '.(get_post_mime_type($file_id)?:'application/octet-stream'));header('Content-Disposition: attachment; filename="'.sanitize_file_name(basename($path)).'"');header('Content-Length: '.filesize($path));readfile($path);exit;}

    public static function cart_redirect(){return add_query_arg('mph_open','cart',MPH_Helpers::account_page_url());}
    public static function payment_return($url,$order){return $order?MPH_Payment_Result::url($order):$url;}
    public static function redirect_native_cart(){if(is_admin()||wp_doing_ajax()||!function_exists('is_cart')||!is_cart())return;$settings=get_option(MPH_Helpers::SETTINGS,array());if(absint($settings['account_page_id']??0)===get_queried_object_id())return;$target=add_query_arg('mph_open','cart',MPH_Helpers::account_page_url());if($target){wp_safe_redirect($target);exit;}}

    private static function pending_orders($user_id){return function_exists('wc_get_orders')?wc_get_orders(array('customer_id'=>absint($user_id),'limit'=>50,'meta_key'=>self::RECEIPT_STATUS,'meta_value'=>'pending','orderby'=>'date','order'=>'DESC')):array();}
    private static function pending_order_notice($orders){return '<div class="mph-pending-order-notice"><span class="dashicons dashicons-clock"></span><div><b>'.count($orders).' سفارش در انتظار تأیید</b><p>فیش شما ثبت شده و پس از تأیید مدیر، دسترسی دوره فعال می‌شود.</p></div></div>';}
    private static function receipt_status_label($status){$map=array('pending'=>'در انتظار بررسی','approved'=>'تأیید شده','rejected'=>'رد شده','cancelled'=>'لغوشده');return$map[$status]??$status;}
    public static function receipt_url($order_id,$file_id){return wp_nonce_url(admin_url('admin-post.php?action=mph_receipt_file&order_id='.absint($order_id).'&file_id='.absint($file_id)),'mph_receipt_'.absint($order_id).'_'.absint($file_id));}
    private static function course_by_product($product_id){if(!$product_id||!MPH_Tutor::active())return 0;if(function_exists('wc_get_product')){$product=wc_get_product(absint($product_id));if($product){$id=absint($product->get_meta(MPH_Courses::COURSE_META));if($id)return$id;}}if(method_exists(tutor_utils(),'get_course_id_by_product')){$id=absint(tutor_utils()->get_course_id_by_product($product_id));if($id)return$id;}$posts=get_posts(array('post_type'=>tutor()->course_post_type,'post_status'=>'any','numberposts'=>1,'fields'=>'ids','meta_key'=>'_tutor_course_product_id','meta_value'=>absint($product_id)));return absint($posts[0]??0);}
    public static function upload_receipt(){if(!empty($_POST['mph_attachment_id']))return MPH_Private_Files::staged(absint($_POST['mph_attachment_id']),'receipt');$file=$_FILES['receipt_file']??array();if(empty($file['tmp_name']))return new WP_Error('mph_file','فیش را انتخاب کنید.');if(!empty($file['error']))return new WP_Error('upload','آپلود فیش انجام نشد.');if(absint($file['size'])>self::MAX_RECEIPT_SIZE)return new WP_Error('large','حجم فیش باید حداکثر ۲ مگابایت باشد.');$allowed=array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf');$check=wp_check_filetype_and_ext($file['tmp_name'],sanitize_file_name($file['name']),$allowed);if(empty($check['type'])||!in_array($check['type'],$allowed,true))return new WP_Error('type','محتوای فایل معتبر نیست؛ فقط تصویر یا PDF واقعی مجاز است.');require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$id=media_handle_upload('receipt_file',0,array(),array('test_form'=>false,'mimes'=>$allowed));return is_wp_error($id)?$id:absint($id);}
    private static function online_gateway_names(){if(!function_exists('WC')||!WC()->payment_gateways())return class_exists('MPH_Payments')?MPH_Payments::enabled_names():array();$names=array();foreach(WC()->payment_gateways()->payment_gateways()as$gateway){if(($gateway->enabled??'no')!=='yes'||in_array($gateway->id,array('bacs','cheque','cod'),true))continue;$names[]=wp_strip_all_tags($gateway->get_title());}return array_values(array_unique(array_filter($names)));}
    public static function billing_from_request($user){$first=MPH_Helpers::posted('billing_first_name');$last=MPH_Helpers::posted('billing_last_name');$phone=MPH_Helpers::phone(MPH_Helpers::posted('billing_phone'));$email=sanitize_email(MPH_Helpers::posted('billing_email'));$postcode=preg_replace('/\D+/','',strtr(MPH_Helpers::posted('billing_postcode'),array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9')));$address=MPH_Helpers::posted('billing_address_1','textarea');if(!$first||!$last||!$phone||!$address)return new WP_Error('billing_required','نام، نام خانوادگی، موبایل و آدرس صورتحساب را کامل کنید.');if(!MPH_Helpers::valid_person_name($first)||!MPH_Helpers::valid_person_name($last))return new WP_Error('billing_numeric_name','نام و نام خانوادگی باید شامل حروف باشند و نمی‌توانند فقط عدد باشند.');if($email&&!is_email($email))return new WP_Error('billing_email','ایمیل صورتحساب معتبر نیست.');$owner=$email?email_exists($email):false;if($owner&&absint($owner)!==absint($user->ID))return new WP_Error('billing_email_exists','این ایمیل متعلق به حساب کاربری دیگری است.');if($postcode&&strlen($postcode)!==10)return new WP_Error('billing_postcode','کد پستی باید دقیقاً ۱۰ رقم باشد.');return array('first_name'=>$first,'last_name'=>$last,'email'=>$email,'phone'=>$phone,'postcode'=>$postcode,'address_1'=>$address,'country'=>'IR');}
    public static function billing_from_profile($user){$email=substr((string)$user->user_email,-8)==='.invalid'?'':$user->user_email;return array('first_name'=>(string)$user->first_name,'last_name'=>(string)$user->last_name,'email'=>$email,'phone'=>(string)get_user_meta($user->ID,'mph_phone',true),'postcode'=>(string)get_user_meta($user->ID,'mph_postal_code',true),'address_1'=>(string)get_user_meta($user->ID,'mph_address',true),'country'=>'IR');}
    private static function save_billing($user,$address){$profile=array('ID'=>$user->ID,'first_name'=>$address['first_name'],'last_name'=>$address['last_name'],'display_name'=>trim($address['first_name'].' '.$address['last_name']));if($address['email'])$profile['user_email']=$address['email'];wp_update_user($profile);update_user_meta($user->ID,'mph_phone',$address['phone']);update_user_meta($user->ID,'mph_address',$address['address_1']);update_user_meta($user->ID,'mph_postal_code',$address['postcode']);foreach($address as$key=>$value)update_user_meta($user->ID,'billing_'.$key,$value);if(WC()->customer){WC()->customer->set_props(array('billing_first_name'=>$address['first_name'],'billing_last_name'=>$address['last_name'],'billing_email'=>$address['email'],'billing_phone'=>$address['phone'],'billing_postcode'=>$address['postcode'],'billing_address_1'=>$address['address_1'],'billing_country'=>'IR'));WC()->customer->save();}}
    private static function validate_cart_capacity(){if(!class_exists('MPH_Growth'))return true;foreach(WC()->cart->get_cart()as$item){$product=$item['data']??false;if(!$product||$product->get_meta(MPH_Courses::MODE_META)!=='inperson')continue;$status=MPH_Growth::capacity_status($product->get_id());if($status['capacity']&&absint($item['quantity'])>$status['remaining'])return new WP_Error('capacity','ظرفیت باقی‌مانده «'.$product->get_name().'» فقط '.number_format_i18n($status['remaining']).' نفر است.');}return true;}
    private static function ensure_cart(){if(!function_exists('WC'))return false;if(!WC()->cart&&function_exists('wc_load_cart'))wc_load_cart();if(WC()->cart)MPH_Shared_Cart::sync();return(bool)WC()->cart;}
    public static function persist_cart(){if(!self::ensure_cart())return;WC()->cart->calculate_totals();if(method_exists(WC()->cart,'set_session'))WC()->cart->set_session();if(WC()->session&&method_exists(WC()->session,'save_data'))WC()->session->save_data();if(class_exists('MPH_Growth'))MPH_Growth::save_cart();}
    private static function cart_count(){return is_user_logged_in()?count(MPH_Shared_Cart::read(get_current_user_id())['items']):0;}
    private static function can_manage(){return is_user_logged_in()&&(MPH_Helpers::has_role('mph_manager')||current_user_can('mph_manage_portal')||current_user_can('manage_options'));}
}
