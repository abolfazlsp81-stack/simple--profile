<?php
defined('ABSPATH') || exit;

final class MPH_Appointments {
    const APPOINTMENT_TYPE = 'mph_appointment';
    const SLOT_TYPE = 'mph_therapy_slot';
    const ORDER_META = '_mph_appointment_id';
    const SERVICE_PRODUCT_OPTION = 'mph_appointment_service_product';
    const HOLIDAY_OPTION = 'mph_appointment_holidays';
    const HOLD_MINUTES = 30;
    const MAX_RECEIPT_SIZE = 2097152;

    public static function init() {
        add_action('init', array(__CLASS__, 'register_types'));
        add_action('wp_ajax_mph_appointment_slot_save', array(__CLASS__, 'ajax_slot_save'));
        add_action('wp_ajax_mph_appointment_slot_delete', array(__CLASS__, 'ajax_slot_delete'));
        add_action('wp_ajax_mph_appointment_holidays_save', array(__CLASS__, 'ajax_holidays_save'));
        add_action('wp_ajax_mph_appointment_book', array(__CLASS__, 'ajax_book'));
        add_action('wp_ajax_mph_appointment_cancel', array(__CLASS__, 'ajax_cancel'));
        add_action('wp_ajax_mph_appointment_decision', array(__CLASS__, 'ajax_decision'));
        add_action('wp_ajax_mph_therapist_profile_save', array(__CLASS__, 'ajax_therapist_profile'));
        add_action('woocommerce_payment_complete', array(__CLASS__, 'confirm_paid_order'), 20);
        add_action('woocommerce_order_status_processing', array(__CLASS__, 'confirm_paid_order'), 20);
        add_action('woocommerce_order_status_completed', array(__CLASS__, 'confirm_paid_order'), 20);
        add_action('mph_release_appointment_hold', array(__CLASS__, 'release_hold'));
        add_action('admin_post_mph_appointment_pdf', array(__CLASS__, 'pdf'));
        add_action('admin_post_mph_therapist_appointments_export', array(__CLASS__, 'export_therapist_appointments'));
        add_filter('woocommerce_get_return_url', array(__CLASS__, 'return_url'), 40, 2);
        add_filter('woocommerce_get_checkout_order_received_url', array(__CLASS__, 'return_url'), 40, 2);
        add_shortcode('mph_appointment_booking', array(__CLASS__, 'booking_shortcode'));
    }

    public static function register_types() {
        register_post_type(self::APPOINTMENT_TYPE, array('label'=>'نوبت‌های درمانی','public'=>false,'show_ui'=>false,'supports'=>array('title','author')));
        register_post_type(self::SLOT_TYPE, array('label'=>'زمان‌های درمانگران','public'=>false,'show_ui'=>false,'supports'=>array('title','author')));
    }

    public static function booking_shortcode() {
        if (class_exists('MPH_Dashboard')) MPH_Dashboard::enqueue_appointment_assets();
        if (!is_user_logged_in()) return MPH_Helpers::secure_form_markup('<div class="mph-root" dir="rtl">'.self::login_required().'</div>');
        return MPH_Helpers::secure_form_markup('<div class="mph-root" dir="rtl">'.self::booking().'</div>');
    }

    private static function login_required() {
        return '<section class="mph-section mph-appointment-login-required"><span class="dashicons dashicons-lock"></span><h3>رزرو نوبت فقط برای کاربران واردشده است</h3><p>برای مشاهده تقویم درمانگران و ثبت نوبت، ابتدا وارد حساب کاربری خود شوید.</p><a class="mph-primary" href="'.esc_url(MPH_Helpers::clean_auth_url()).'">ورود به حساب کاربری</a></section>';
    }

    public static function render($panel) {
        if ($panel === 'book_appointment') return self::booking();
        if ($panel === 'my_appointments') return self::appointment_list('user');
        if ($panel === 'therapist_dashboard') return self::therapist_dashboard();
        if ($panel === 'therapist_schedule') return self::schedule(false);
        if ($panel === 'therapist_appointments') return self::appointment_export_controls().self::appointment_list('therapist');
        if ($panel === 'therapist_settings') return self::therapist_profile();
        if ($panel === 'manage_therapists') return self::therapists();
        if ($panel === 'manage_appointment_schedule') return self::schedule(true);
        if ($panel === 'manage_appointments') return self::appointment_list('manager');
        return '<div class="mph-empty">بخش نوبت‌دهی در دسترس نیست.</div>';
    }

    private static function booking() {
        if (!is_user_logged_in()) return self::login_required();
        $therapists = get_users(array('role'=>'mph_therapist','orderby'=>'display_name','order'=>'ASC'));
        $slots = self::available_slots();
        $card = trim((string)MPH_Security::get_secret_option('mph_bank_card_number',''));
        $owner = trim((string)MPH_Security::get_secret_option('mph_bank_card_owner',''));
        $online = self::online_gateway_names();
        $slot_data = array();
        foreach ($slots as $slot) {
            $modes = array_values(array_intersect(array_keys(self::modes()), (array)get_post_meta($slot->ID, '_mph_slot_modes', true)));
            $prices = array();
            foreach ($modes as $mode) $prices[$mode] = (string)get_post_meta($slot->ID, '_mph_slot_price_'.$mode, true);
            $slot_data[] = array(
                'id'=>absint($slot->ID),
                'therapist'=>absint($slot->post_author),
                'date'=>(string)get_post_meta($slot->ID, '_mph_slot_date', true),
                'jdate'=>self::jalali_date_label(get_post_meta($slot->ID, '_mph_slot_date', true), false),
                'time'=>(string)get_post_meta($slot->ID, '_mph_slot_time', true),
                'end'=>self::slot_end($slot),
                'duration'=>absint(get_post_meta($slot->ID, '_mph_slot_duration', true)),
                'modes'=>$modes,
                'prices'=>$prices,
            );
        }
        ob_start(); ?>
        <section class="mph-section mph-appointment-booking" data-mph-appointment-booking>
            <div class="mph-appointment-hero"><div><small>سامانه مرحله‌ای نوبت‌دهی روان‌شناسی</small><h3>رزرو نوبت با درمانگر</h3><p>درمانگر را انتخاب کنید، روز موردنظر را روی تقویم شمسی بزنید و یکی از زمان‌های آزاد را بردارید.</p></div><span class="dashicons dashicons-calendar-alt"></span></div>
            <?php if(!$therapists): ?><div class="mph-empty"><span class="dashicons dashicons-admin-users"></span><p>درمانگر فعالی برای رزرو ثبت نشده است.</p></div></section><?php return ob_get_clean(); endif; ?>
            <?php if(!$slots): ?><div class="mph-empty"><span class="dashicons dashicons-calendar-alt"></span><p>در حال حاضر زمان آزادی برای رزرو وجود ندارد.</p></div></section><?php return ob_get_clean(); endif; ?>
            <form class="mph-form mph-appointment-form" data-mph-action="mph_appointment_book" enctype="multipart/form-data">
                <div class="mph-appointment-steps"><span class="is-active" data-mph-appointment-step="1"><b>۱</b> درمانگر</span><span data-mph-appointment-step="2"><b>۲</b> روز مراجعه</span><span data-mph-appointment-step="3"><b>۳</b> ساعت آزاد</span><span data-mph-appointment-step="4"><b>۴</b> پرداخت</span></div>
                <div class="mph-booking-toolbar"><label><?php echo MPH_Helpers::required('انتخاب درمانگر'); ?><select name="therapist_id" data-mph-therapist-select required><option value="">درمانگر را انتخاب کنید</option><?php foreach($therapists as$therapist): ?><option value="<?php echo absint($therapist->ID); ?>" data-specialty="<?php echo esc_attr(get_user_meta($therapist->ID,'mph_therapist_specialty',true)?:'روان‌شناس'); ?>"><?php echo esc_html(MPH_Helpers::display_name($therapist).' — '.(get_user_meta($therapist->ID,'mph_therapist_specialty',true)?:'روان‌شناس')); ?></option><?php endforeach; ?></select><small>ابتدا درمانگر موردنظر را انتخاب کنید تا روزهای فعال تقویم نمایش داده شوند.</small></label></div>
                <div class="mph-booking-calendar-layout">
                    <section class="mph-booking-calendar" data-mph-booking-calendar aria-live="polite">
                        <header><button type="button" data-mph-calendar-prev aria-label="ماه قبل">‹</button><div><small>تقویم شمسی نوبت‌دهی</small><div class="mph-calendar-jump"><select data-mph-calendar-month aria-label="انتخاب ماه"></select><select data-mph-calendar-year aria-label="انتخاب سال"></select></div><h4 data-mph-calendar-title>انتخاب درمانگر</h4></div><button type="button" data-mph-calendar-next aria-label="ماه بعد">›</button></header>
                        <div class="mph-booking-weekdays"><span>ش</span><span>ی</span><span>د</span><span>س</span><span>چ</span><span>پ</span><span>ج</span></div>
                        <div class="mph-booking-days" data-mph-calendar-days><p>پس از انتخاب درمانگر، روزهای دارای نوبت فعال می‌شوند.</p></div>
                        <footer><span><i></i> زمان خالی</span><span><i class="is-holiday"></i> تعطیل و غیرقابل رزرو</span></footer>
                    </section>
                    <section class="mph-booking-times" data-mph-booking-times><header><div><small>زمان‌های آزاد</small><h4 data-mph-selected-day>هنوز روزی انتخاب نشده است</h4></div><span class="dashicons dashicons-clock"></span></header><div data-mph-slot-options><p>یک روز سبز را از تقویم انتخاب کنید.</p></div></section>
                </div>
                <section class="mph-appointment-payment-stage" data-mph-payment-stage hidden>
                    <input type="hidden" name="slot_id" data-mph-slot-id required>
                    <div class="mph-selected-appointment" data-mph-selected-appointment></div>
                    <fieldset class="mph-appointment-modes" data-mph-appointment-modes disabled><legend>نوع جلسه</legend><?php foreach(self::modes()as$key=>$mode): ?><label data-appointment-mode="<?php echo esc_attr($key); ?>"><input type="radio" name="appointment_mode" value="<?php echo esc_attr($key); ?>" required><span class="dashicons <?php echo esc_attr($mode['icon']); ?>"></span><b><?php echo esc_html($mode['label']); ?></b><small><?php echo esc_html($mode['hint']); ?></small></label><?php endforeach; ?></fieldset>
                    <div class="mph-appointment-price" data-mph-appointment-price><span>مبلغ جلسه</span><b>پس از انتخاب نوع جلسه نمایش داده می‌شود</b></div>
                    <div class="mph-cart-notice">روش پرداخت و فیش را در سبد خرید انتخاب می‌کنید؛ افزودن به سبد هنوز رزرو قطعی نیست.</div>
                    <label>یادداشت برای درمانگر <small>(اختیاری و حداکثر ۵۰۰ نویسه)</small><textarea name="patient_note" maxlength="500" rows="3" placeholder="موضوع کلی مراجعه یا نکته‌ای که پیش از جلسه لازم است درمانگر بداند"></textarea></label>
                    <div class="mph-appointment-security"><span class="dashicons dashicons-shield-alt"></span><p>اطلاعات رزرو فقط برای شما، درمانگر منتخب و مدیر مجاز قابل مشاهده است.</p></div>
                    <div class="mph-appointment-final-actions"><button class="mph-primary mph-appointment-submit" type="submit"><span class="dashicons dashicons-lock"></span> افزودن نوبت به سبد خرید</button><button class="mph-secondary" type="button" data-mph-change-time>تغییر روز یا ساعت</button></div>
                </section>
                <div class="mph-message" aria-live="polite"></div>
                <script type="application/json" class="mph-appointment-slot-data"><?php echo wp_json_encode($slot_data, JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
                <script type="application/json" class="mph-appointment-holiday-data"><?php echo wp_json_encode(self::holiday_client_data(), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
            </form>
        </section><?php return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    private static function schedule($manager) {
        if ($manager && !self::can_manage()) return '<div class="mph-empty">دسترسی ندارید.</div>';
        if (!$manager && !self::is_therapist()) return '<div class="mph-empty">دسترسی درمانگر لازم است.</div>';
        $therapists = $manager ? get_users(array('role'=>'mph_therapist','orderby'=>'display_name')) : array(wp_get_current_user());
        $owner_ids = $manager ? wp_list_pluck($therapists,'ID') : array(get_current_user_id());
        $slots = $owner_ids ? get_posts(array('post_type'=>self::SLOT_TYPE,'post_status'=>'publish','author__in'=>array_map('absint',$owner_ids),'numberposts'=>200,'meta_key'=>'_mph_slot_date','orderby'=>'meta_value','order'=>'ASC')) : array();
        $panel = $manager ? 'manage_appointment_schedule' : 'therapist_schedule';
        $today = current_time('Y-m-d');
        $default_date = self::next_working_date($today);
        $today_jalali = MPH_Helpers::gregorian_to_jalali_date($default_date);
        ob_start(); ?><section class="mph-section mph-therapy-schedule"><div class="mph-section-heading"><div><small class="mph-eyebrow">تقویم مستقل نوبت‌دهی</small><h3>ثبت زمان‌های قابل رزرو</h3><p>تاریخ شمسی، ساعت شروع، مدت دلخواه، شیوه برگزاری و قیمت هر زمان را تعیین کنید.</p></div><span class="dashicons dashicons-calendar-alt"></span></div>
        <?php if(!$therapists): ?><div class="mph-empty">ابتدا یک کاربر با نقش درمانگر تأیید کنید.</div></section><?php return ob_get_clean();endif; ?>
        <form class="mph-form mph-slot-form" data-mph-action="mph_appointment_slot_save" data-mph-today="<?php echo esc_attr($today); ?>">
            <input type="hidden" name="return_panel" value="<?php echo esc_attr($panel); ?>">
            <div class="mph-slot-planner">
                <section class="mph-slot-calendar-card" data-mph-slot-calendar>
                    <header><button type="button" data-mph-slot-prev aria-label="ماه قبل">‹</button><div><small>انتخاب روز کاری</small><div class="mph-calendar-jump"><select data-mph-slot-month aria-label="ماه"></select><select data-mph-slot-year aria-label="سال"></select></div></div><button type="button" data-mph-slot-next aria-label="ماه بعد">›</button></header>
                    <div class="mph-slot-weekdays"><span>ش</span><span>ی</span><span>د</span><span>س</span><span>چ</span><span>پ</span><span>ج</span></div>
                    <div class="mph-slot-calendar-days" data-mph-slot-days></div>
                    <footer><span><i></i> قابل انتخاب</span><span><i class="is-holiday"></i> تعطیل</span></footer>
                </section>
                <section class="mph-slot-details-card"><header><span class="dashicons dashicons-clock"></span><div><b>ثبت زمان</b><small>روز، ساعت و مدت جلسه را مشخص کنید</small></div></header><div class="mph-field-grid mph-slot-range-grid">
                    <?php if($manager): ?><label><?php echo MPH_Helpers::required('درمانگر'); ?><select name="therapist_id" required><?php foreach($therapists as$therapist): ?><option value="<?php echo absint($therapist->ID); ?>"><?php echo esc_html(MPH_Helpers::display_name($therapist)); ?></option><?php endforeach; ?></select></label><?php else: ?><input type="hidden" name="therapist_id" value="<?php echo get_current_user_id(); ?>"><?php endif; ?>
                    <label class="mph-slot-jalali-date mph-jalali-field"><?php echo MPH_Helpers::required('تاریخ شمسی'); ?><span class="mph-input-with-icon"><span class="dashicons dashicons-calendar-alt"></span><input type="text" name="slot_jdate" value="<?php echo esc_attr($today_jalali); ?>" inputmode="numeric" autocomplete="off" dir="ltr" maxlength="10" required placeholder="1405/06/02" data-mph-jalali-input></span><small>از تقویم انتخاب کنید یا ۸ رقم تایپ کنید.</small></label>
                    <label><?php echo MPH_Helpers::required('ساعت شروع'); ?><input type="time" name="slot_time" value="11:00" required></label>
                    <label><?php echo MPH_Helpers::required('مدت جلسه به دقیقه'); ?><input type="text" name="slot_duration" value="" inputmode="numeric" maxlength="4" required placeholder="مثلاً 45 یا 90" data-mph-slot-duration><small>مدت دلخواه؛ محدود به یک ساعت نیست.</small></label>
                    <label>ساعت پایان خودکار<output data-mph-slot-end-label>پس از ورود مدت</output><small>به‌صورت خودکار محاسبه می‌شود.</small></label>
                </div></section>
            </div>
            <section class="mph-slot-services"><header><div><b>نوع جلسه و قیمت</b><small>حداقل یک روش را فعال کنید</small></div></header><div class="mph-slot-mode-prices"><?php foreach(self::modes()as$key=>$mode): ?><label><span><input type="checkbox" name="slot_modes[]" value="<?php echo esc_attr($key); ?>"> <?php echo esc_html($mode['label']); ?></span><input type="text" inputmode="decimal" name="slot_price_<?php echo esc_attr($key); ?>" placeholder="مبلغ بدون محدودیت"></label><?php endforeach; ?></div><p class="mph-slot-price-note"><span class="dashicons dashicons-info-outline"></span> سقفی برای مبلغ نوبت تعیین نشده است؛ مبلغ را به واحد پول فروشگاه وارد کنید.</p></section>
            <div class="mph-slot-submitbar"><button class="mph-primary" type="submit"><span class="dashicons dashicons-plus-alt2"></span> ثبت زمان</button><div class="mph-message"></div></div>
            <script type="application/json" class="mph-appointment-holiday-data"><?php echo wp_json_encode(self::holiday_client_data(), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
        </form>
        <?php if($manager):$custom=self::custom_holidays(); ?><details class="mph-holiday-settings"><summary><span class="dashicons dashicons-calendar-alt"></span><div><b>تعطیلات تکمیلی مجموعه</b><small>برای تعطیلی‌های مناسبتی یا محلی که در تقویم عمومی نیستند</small></div></summary><form class="mph-form" data-mph-action="mph_appointment_holidays_save"><input type="hidden" name="return_panel" value="<?php echo esc_attr($panel); ?>"><label>هر تاریخ در یک خط<textarea name="holiday_dates" rows="5" dir="ltr" placeholder="1405/06/10 | تعطیلی مناسبتی"><?php foreach($custom as$date=>$label)echo esc_textarea($date.' | '.$label."\n"); ?></textarea><small>نمونه: ۱۴۰۵/۰۶/۱۰ | تعطیلی مناسبتی</small></label><button class="mph-secondary" type="submit">ذخیره تعطیلات تکمیلی</button><div class="mph-message"></div></form></details><?php endif; ?>
        <div class="mph-slot-list"><?php if(!$slots): ?><div class="mph-empty">هنوز زمان آزادی ثبت نشده است.</div><?php endif;foreach($slots as$slot):$reserved=absint(get_post_meta($slot->ID,'_mph_reserved_appointment',true));$booked=absint(get_post_meta($slot->ID,'_mph_slot_booked',true));$therapist=get_user_by('id',$slot->post_author);$holiday=self::holiday_info(get_post_meta($slot->ID,'_mph_slot_date',true)); ?><article class="<?php echo esc_attr($holiday?'is-holiday':($booked?'is-booked':($reserved?'is-reserved':''))); ?>"><div><b><?php echo esc_html(self::slot_label($slot)); ?></b><small><?php echo esc_html(($therapist?MPH_Helpers::display_name($therapist):'درمانگر حذف‌شده').' · '.implode('، ',array_map(array(__CLASS__,'mode_label'),(array)get_post_meta($slot->ID,'_mph_slot_modes',true)))); ?></small></div><span><?php echo esc_html($holiday?'تعطیل: '.$holiday:($booked?'رزرو قطعی':($reserved?'در انتظار پرداخت':'آزاد'))); ?></span><?php if(!$booked&&!$reserved): ?><form data-mph-action="mph_appointment_slot_delete" onsubmit="return confirm('این زمان آزاد حذف شود؟')"><input type="hidden" name="slot_id" value="<?php echo absint($slot->ID); ?>"><input type="hidden" name="return_panel" value="<?php echo esc_attr($panel); ?>"><button class="mph-icon-danger" type="submit"><span class="dashicons dashicons-trash"></span></button><div class="mph-message"></div></form><?php endif; ?></article><?php endforeach; ?></div></section><?php return MPH_Helpers::secure_form_markup(ob_get_clean());
    }

    private static function therapist_dashboard() {
        if(!self::is_therapist())return'<div class="mph-empty">دسترسی درمانگر لازم است.</div>';$id=get_current_user_id();$today=current_time('Y-m-d');$appointments=self::query_appointments('therapist',$id);$confirmed=0;$today_count=0;$pending=0;foreach($appointments as$item){$status=get_post_meta($item->ID,'_mph_appointment_status',true);if($status==='confirmed')$confirmed++;if(in_array($status,array('awaiting_payment','pending_receipt'),true))$pending++;if(get_post_meta($item->ID,'_mph_appointment_date',true)===$today)$today_count++;}ob_start(); ?><section class="mph-section mph-therapist-home"><div class="mph-appointment-hero"><div><small>کارتابل درمانگر</small><h3>مدیریت جلسات روان‌شناسی</h3><p>زمان‌های آزاد و نوبت‌های قطعی را از پنل خود مدیریت کنید.</p></div><span class="dashicons dashicons-heart"></span></div><div class="mph-therapy-stats"><article><b><?php echo $today_count; ?></b><span>جلسه امروز</span></article><article><b><?php echo $confirmed; ?></b><span>رزرو قطعی</span></article><article><b><?php echo $pending; ?></b><span>در انتظار پرداخت</span></article><article><b><?php echo count(self::available_slots($id)); ?></b><span>زمان آزاد آینده</span></article></div><div class="mph-therapist-guides"><article><span class="dashicons dashicons-calendar-alt"></span><div><h4>برنامه کاری</h4><p>روز، ساعت، مدت، قیمت و شیوه برگزاری را ثبت کنید.</p></div></article><article><span class="dashicons dashicons-groups"></span><div><h4>پرونده نوبت</h4><p>نام مراجع، شیوه جلسه، پرداخت و کد پیگیری را یکجا ببینید.</p></div></article><article><span class="dashicons dashicons-shield-alt"></span><div><h4>حریم خصوصی</h4><p>اطلاعات هر رزرو فقط برای افراد مجاز نمایش داده می‌شود.</p></div></article></div></section><?php return ob_get_clean();
    }

    private static function appointment_export_controls() {
        if(!self::is_therapist())return'';$today=MPH_Helpers::gregorian_to_jalali_date(current_time('Y-m-d'));ob_start();?><section class="mph-section mph-appointment-export"><div class="mph-section-heading"><div><h3>خروجی Excel نوبت‌ها</h3><p>بازه روز، هفته، ماه یا تاریخ دلخواه را انتخاب کنید؛ آخرین وضعیت پرداخت و نوبت نیز در فایل می‌آید.</p></div><span class="dashicons dashicons-media-spreadsheet"></span></div><form method="get" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-mph-no-ajax><input type="hidden" name="action" value="mph_therapist_appointments_export"><?php wp_nonce_field('mph_therapist_appointments_export','_mphnonce'); ?><div class="mph-field-grid"><label>بازه گزارش<select name="range" data-mph-appointment-export-range><option value="day">امروز</option><option value="week">هفت روز آینده</option><option value="month">ماه جاری</option><option value="custom">بازه دلخواه</option></select></label><label data-mph-export-custom>از تاریخ شمسی<input type="text" name="date_from" value="<?php echo esc_attr($today); ?>" inputmode="numeric" maxlength="10" data-mph-jalali-input></label><label data-mph-export-custom>تا تاریخ شمسی<input type="text" name="date_to" value="<?php echo esc_attr($today); ?>" inputmode="numeric" maxlength="10" data-mph-jalali-input></label></div><button class="mph-primary" type="submit"><span class="dashicons dashicons-download"></span> دریافت فایل Excel</button></form></section><?php return ob_get_clean();
    }

    public static function export_therapist_appointments() {
        if(!is_user_logged_in()||!self::is_therapist()||!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_mphnonce']??'')),'mph_therapist_appointments_export'))wp_die('دسترسی ندارید.','',array('response'=>403));$range=sanitize_key(wp_unslash($_GET['range']??'day'));$today=current_time('Y-m-d');$from=$today;$to=$today;
        if($range==='week')$to=wp_date('Y-m-d',strtotime($today.' +6 days'));elseif($range==='month'){$from=wp_date('Y-m-01',strtotime($today));$to=wp_date('Y-m-t',strtotime($today));}elseif($range==='custom'){$from=MPH_Helpers::jalali_to_gregorian_date(sanitize_text_field(wp_unslash($_GET['date_from']??'')));$to=MPH_Helpers::jalali_to_gregorian_date(sanitize_text_field(wp_unslash($_GET['date_to']??'')));if(!$from||!$to||$from>$to)wp_die('بازه تاریخ شمسی معتبر نیست.','',array('response'=>400));}
        $items=self::query_appointments('therapist',get_current_user_id());$items=array_values(array_filter($items,function($item)use($from,$to){$date=(string)get_post_meta($item->ID,'_mph_appointment_date',true);return$date>=$from&&$date<=$to;}));while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="appointments-'.$from.'-'.$to.'.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,array('اسم و فامیل','شماره تلفن','تاریخ نوبت','ساعت نوبت','آخرین وضعیت پرداخت','آخرین وضعیت نوبت'));
        foreach($items as$item){$patient_id=absint(get_post_meta($item->ID,'_mph_appointment_patient',true));$patient=get_user_by('id',$patient_id);$order_id=absint(get_post_meta($item->ID,'_mph_appointment_order',true));$order=$order_id&&function_exists('wc_get_order')?wc_get_order($order_id):false;$payment=$order?wc_get_order_status_name($order->get_status()):'بدون سفارش';$receipt=$order?$order->get_meta(MPH_Commerce::RECEIPT_STATUS):'';if($receipt)$payment.=' / فیش: '.$receipt;$row=array($patient?MPH_Helpers::display_name($patient):'کاربر حذف‌شده',get_user_meta($patient_id,'mph_phone',true),self::jalali_date_label(get_post_meta($item->ID,'_mph_appointment_date',true),true),get_post_meta($item->ID,'_mph_appointment_time',true),$payment,self::status_label(get_post_meta($item->ID,'_mph_appointment_status',true)));fputcsv($out,array_map(array(__CLASS__,'csv_safe'),$row));}fclose($out);exit;
    }

    private static function csv_safe($value){$value=(string)$value;return preg_match('/^[=+\-@]/u',$value)?"'".$value:$value;}

    private static function appointment_list($view) {
        if($view==='manager'&&!self::can_manage())return'<div class="mph-empty">دسترسی ندارید.</div>';if($view==='therapist'&&!self::is_therapist())return'<div class="mph-empty">دسترسی درمانگر لازم است.</div>';$user_id=get_current_user_id();$items=self::query_appointments($view,$user_id);ob_start(); ?><section class="mph-section mph-appointment-list"><div class="mph-section-heading"><div><h3><?php echo $view==='user'?'نوبت‌های من':($view==='therapist'?'نوبت‌های مراجعان':'مدیریت همه نوبت‌ها'); ?></h3><p>وضعیت رزرو، پرداخت، زمان جلسه و فایل تأیید</p></div><span class="dashicons dashicons-clipboard"></span></div><?php if(!$items): ?><div class="mph-empty">هنوز نوبتی در این بخش ثبت نشده است.</div><?php endif; ?><div class="mph-appointment-cards"><?php foreach($items as$item):echo self::appointment_card($item,$view);endforeach; ?></div></section><?php return ob_get_clean();
    }

    private static function appointment_card($appointment,$view) {
        $id = $appointment->ID;
        $therapist = get_user_by('id', absint(get_post_meta($id, '_mph_appointment_therapist', true)));
        $patient = get_user_by('id', absint(get_post_meta($id, '_mph_appointment_patient', true)));
        $status = sanitize_key(get_post_meta($id, '_mph_appointment_status', true));
        $mode = sanitize_key(get_post_meta($id, '_mph_appointment_mode', true));
        $order_id = absint(get_post_meta($id, '_mph_appointment_order', true));
        $order = $order_id && function_exists('wc_get_order') ? wc_get_order($order_id) : false;
        $can_pdf = in_array($status, array('confirmed','completed'), true);
        $session = $can_pdf && $therapist ? self::session_details($therapist->ID, $mode) : array();
        $cancellation = self::cancellation_info($id);
        $date = get_post_meta($id, '_mph_appointment_date', true);
        $time = get_post_meta($id, '_mph_appointment_time', true);
        $end = get_post_meta($id, '_mph_appointment_end', true);
        if (!$end) $end = self::minutes_to_time(self::time_to_minutes($time) + absint(get_post_meta($id, '_mph_appointment_duration', true)));
        ob_start(); ?>
        <article class="mph-appointment-card is-<?php echo esc_attr($status); ?>">
            <header><div><?php echo get_avatar($view==='user'?($therapist?$therapist->ID:0):($patient?$patient->ID:0),54); ?><span><b><?php echo esc_html($view==='user'?($therapist?MPH_Helpers::display_name($therapist):'درمانگر حذف‌شده'):($patient?MPH_Helpers::display_name($patient):'کاربر حذف‌شده')); ?></b><small><?php echo esc_html(self::mode_label($mode)); ?></small></span></div><em><?php echo esc_html(self::status_label($status)); ?></em></header>
            <div class="mph-appointment-meta"><span><i class="dashicons dashicons-calendar-alt"></i><?php echo esc_html(self::jalali_date_label($date, true)); ?></span><span><i class="dashicons dashicons-clock"></i><?php echo esc_html($time.' تا '.$end); ?></span><span><i class="dashicons dashicons-tickets-alt"></i><?php echo esc_html(get_post_meta($id,'_mph_appointment_tracking',true)); ?></span><span><i class="dashicons dashicons-money-alt"></i><?php echo $order?wp_kses_post($order->get_formatted_order_total()):'—'; ?></span></div>
            <?php if ($session) : ?><div class="mph-appointment-session"><span class="dashicons <?php echo esc_attr($session['icon']); ?>"></span><div><small><?php echo esc_html($session['label']); ?></small><?php if (!empty($session['url'])) : ?><a href="<?php echo esc_url($session['url']); ?>" target="_blank" rel="noopener nofollow">ورود به جلسه آنلاین</a><?php else : ?><b dir="auto"><?php echo esc_html($session['value']); ?></b><?php endif; ?></div></div><?php endif; ?>
            <?php if($view!=='user'&&get_post_meta($id,'_mph_appointment_note',true)): ?><p class="mph-patient-note"><b>یادداشت مراجع:</b> <?php echo esc_html(get_post_meta($id,'_mph_appointment_note',true)); ?></p><?php endif; ?>
            <?php if ($view === 'user' && $cancellation['eligible']) : ?><div class="mph-cancellation-rule <?php echo $cancellation['allowed'] ? 'is-open' : 'is-closed'; ?>"><span class="dashicons <?php echo $cancellation['allowed'] ? 'dashicons-clock' : 'dashicons-lock'; ?>"></span><p><?php echo esc_html($cancellation['allowed'] ? 'امکان لغو تا '.$cancellation['deadline'].' وجود دارد.' : 'مهلت لغو این نوبت (۲۴ ساعت پیش از مراجعه) پایان یافته است.'); ?></p></div><?php endif; ?>
            <footer><?php if($can_pdf): ?><a class="mph-primary" target="_blank" rel="noopener" href="<?php echo esc_url(self::pdf_url($id)); ?>"><span class="dashicons dashicons-pdf"></span> رسید چاپی / PDF</a><?php endif; ?><?php if($view==='user'&&$cancellation['allowed']): ?><form data-mph-action="mph_appointment_cancel" onsubmit="return confirm('این نوبت لغو شود؟ این عملیات قابل بازگشت نیست.')"><input type="hidden" name="appointment_id" value="<?php echo $id; ?>"><button class="mph-secondary mph-cancel-appointment" type="submit"><span class="dashicons dashicons-no-alt"></span> لغو نوبت</button><div class="mph-message"></div></form><?php endif; ?><?php if(in_array($view,array('therapist','manager'),true)&&in_array($status,array('confirmed','completed'),true)): ?><form data-mph-action="mph_appointment_decision"><input type="hidden" name="appointment_id" value="<?php echo $id; ?>"><input type="hidden" name="return_panel" value="<?php echo esc_attr($view==='manager'?'manage_appointments':'therapist_appointments'); ?>"><?php if($status==='confirmed'): ?><button class="mph-secondary" name="decision" value="complete">ثبت انجام جلسه</button><?php endif; ?><button class="mph-icon-danger" name="decision" value="cancel" onclick="return confirm('این نوبت لغو شود؟')"><span class="dashicons dashicons-no-alt"></span></button><div class="mph-message"></div></form><?php endif; ?></footer>
        </article><?php return ob_get_clean();
    }

    private static function therapists() {
        if(!self::can_manage())return'<div class="mph-empty">دسترسی ندارید.</div>';$users=get_users(array('role'=>'mph_therapist','orderby'=>'display_name'));ob_start(); ?><section class="mph-section mph-manager-therapists"><div class="mph-section-heading"><div><h3>درمانگران</h3><p>کاربران تأییدشده برای نوبت‌دهی مستقل</p></div><span class="dashicons dashicons-heart"></span></div><div class="mph-therapist-showcase"><?php if(!$users): ?><div class="mph-empty">از بخش درخواست نقش‌ها، نقش درمانگر را تأیید کنید.</div><?php endif;foreach($users as$user):$appointments=count(self::query_appointments('therapist',$user->ID)); ?><article><div><?php echo get_avatar($user->ID,72); ?><i></i></div><h4><?php echo esc_html(MPH_Helpers::display_name($user)); ?></h4><p><?php echo esc_html(get_user_meta($user->ID,'mph_therapist_specialty',true)?:'تخصص ثبت نشده'); ?></p><small><?php echo $appointments; ?> نوبت · <?php echo count(self::available_slots($user->ID)); ?> زمان آزاد</small></article><?php endforeach; ?></div></section><?php return ob_get_clean();
    }

    private static function therapist_profile() {
        if(!self::is_therapist())return'<div class="mph-empty">دسترسی درمانگر لازم است.</div>';$user=wp_get_current_user();ob_start(); ?><section class="mph-section mph-therapist-profile"><div class="mph-section-heading"><div><h3>پروفایل حرفه‌ای درمانگر</h3><p>اطلاعات حرفه‌ای، روش برگزاری جلسه و حساب بانکی تسویه را مدیریت کنید.</p></div><span class="dashicons dashicons-id"></span></div><form class="mph-form" data-mph-action="mph_therapist_profile_save"><div class="mph-field-grid"><label><?php echo MPH_Helpers::required('حوزه تخصص'); ?><input name="specialty" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_therapist_specialty',true)); ?>" required placeholder="مثلاً روان‌شناس بالینی"></label><label>شماره نظام/مجوز<input name="license" value="<?php echo esc_attr(get_user_meta($user->ID,'mph_therapist_license',true)); ?>"></label></div><label>معرفی حرفه‌ای<textarea name="bio" rows="5" maxlength="1500"><?php echo esc_textarea(get_user_meta($user->ID,'mph_therapist_bio',true)); ?></textarea></label><div class="mph-field-grid"><label>شماره تماس جلسات تلفنی<input name="therapy_phone" value="<?php echo esc_attr(MPH_Security::get_user_meta($user->ID,'mph_therapist_phone')?:get_user_meta($user->ID,'mph_phone',true)); ?>" inputmode="numeric" maxlength="11"></label><label>لینک جلسات آنلاین<input type="url" name="online_url" value="<?php echo esc_attr(MPH_Security::get_user_meta($user->ID,'mph_therapist_online_url')); ?>" dir="ltr" placeholder="https://…"></label></div><label>آدرس جلسات حضوری<textarea name="office_address" rows="3"><?php echo esc_textarea(MPH_Security::get_user_meta($user->ID,'mph_therapist_office')); ?></textarea></label><div class="mph-security-hint"><span class="dashicons dashicons-shield"></span> شماره تماس، لینک جلسه و آدرس مطب به‌صورت رمزنگاری‌شده نگهداری می‌شوند.</div><?php echo MPH_Payouts::profile_fields($user); ?><button class="mph-primary" type="submit">ذخیره پروفایل درمانگر</button><div class="mph-message"></div></form><?php echo MPH_Payouts::render_user($user->ID,true); ?></section><?php return ob_get_clean();
    }

    public static function ajax_slot_save() {
        MPH_Helpers::verify_ajax();
        $manager = self::can_manage();
        if (!$manager && !self::is_therapist()) wp_send_json_error(array('message'=>'دسترسی ندارید.'), 403);
        if (!MPH_Security::allow('appointment_slot_save', 40, 10*MINUTE_IN_SECONDS, 'u:'.get_current_user_id())) wp_send_json_error(array('message'=>'تعداد تغییرات برنامه کاری بیش از حد مجاز است؛ کمی بعد دوباره تلاش کنید.'),429);
        $therapist_id = $manager ? absint($_POST['therapist_id'] ?? 0) : get_current_user_id();
        $therapist = get_user_by('id', $therapist_id);
        if (!$therapist || !MPH_Helpers::has_role('mph_therapist', $therapist)) wp_send_json_error(array('message'=>'درمانگر معتبر نیست.'));
        $jdate = MPH_Helpers::jalali_date(MPH_Helpers::posted('slot_jdate'));
        $date = $jdate ? MPH_Helpers::jalali_to_gregorian_date($jdate) : MPH_Helpers::posted('slot_date');
        $time = MPH_Helpers::posted('slot_time');
        $duration_raw = preg_replace('/\D+/', '', MPH_Helpers::normalize_digits(MPH_Helpers::posted('slot_duration')));
        $duration = $duration_raw === '' ? 0 : absint($duration_raw);
        $today = current_time('Y-m-d');
        $now = current_time('H:i');
        if (!$jdate || !self::valid_date($date)) wp_send_json_error(array('message'=>'تاریخ شمسی معتبر نیست؛ نمونه صحیح: ۱۴۰۵/۰۶/۰۲ یا ۱۴۰۵۰۶۰۲'));
        $holiday = self::holiday_info($date);
        if ($holiday) wp_send_json_error(array('message'=>'ثبت زمان در روز تعطیل مجاز نیست: '.$holiday), 409);
        if ($date < $today || !self::valid_time($time) || ($date === $today && $time <= $now)) wp_send_json_error(array('message'=>'ساعت شروع را در آینده قرار دهید.'));
        if ($duration < 1) wp_send_json_error(array('message'=>'مدت جلسه را به دقیقه وارد کنید؛ مثلاً ۴۵ یا ۹۰.'));
        $end_minutes = self::time_to_minutes($time) + $duration;
        if ($end_minutes > 1439) wp_send_json_error(array('message'=>'مدت واردشده از پایان همان روز عبور می‌کند؛ ساعت شروع یا مدت را اصلاح کنید.'));
        $end_time = self::minutes_to_time($end_minutes);
        $modes = array_values(array_intersect(array_keys(self::modes()), array_map('sanitize_key', (array)($_POST['slot_modes'] ?? array()))));
        if (!$modes) wp_send_json_error(array('message'=>'حداقل یک نوع جلسه را انتخاب کنید.'));
        if (in_array('online', $modes, true) && !esc_url_raw(MPH_Security::get_user_meta($therapist_id, 'mph_therapist_online_url'))) wp_send_json_error(array('message'=>'برای فعال‌کردن جلسه آنلاین، ابتدا لینک جلسه را در پروفایل درمانگر ثبت کنید.'));
        if (in_array('inperson', $modes, true) && !trim((string)MPH_Security::get_user_meta($therapist_id, 'mph_therapist_office'))) wp_send_json_error(array('message'=>'برای فعال‌کردن جلسه حضوری، ابتدا آدرس مطب را در پروفایل درمانگر ثبت کنید.'));
        $prices = array();
        foreach ($modes as $mode) {
            $raw = wp_unslash($_POST['slot_price_'.$mode] ?? '');
            $raw = strtr((string)$raw, array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9','٬'=>'','،'=>'','ـ'=>'',' '=>''));
            $price = function_exists('wc_format_decimal') ? wc_format_decimal($raw) : preg_replace('/[^0-9.]/', '', (string)$raw);
            if ($price === '' || (float)$price < 0) wp_send_json_error(array('message'=>'قیمت '.self::mode_label($mode).' معتبر نیست.'));
            $prices[$mode] = $price;
        }
        if (self::slot_overlaps($therapist_id, $date, $time, $duration)) wp_send_json_error(array('message'=>'این بازه با زمان دیگری از برنامه درمانگر هم‌پوشانی دارد.'));
        $slot_id = wp_insert_post(array('post_type'=>self::SLOT_TYPE,'post_status'=>'publish','post_author'=>$therapist_id,'post_title'=>MPH_Helpers::display_name($therapist).' — '.$date.' '.$time), true);
        if (is_wp_error($slot_id)) wp_send_json_error(array('message'=>$slot_id->get_error_message()));
        update_post_meta($slot_id, '_mph_slot_date', $date);
        update_post_meta($slot_id, '_mph_slot_time', $time);
        update_post_meta($slot_id, '_mph_slot_end', $end_time);
        update_post_meta($slot_id, '_mph_slot_duration', $duration);
        update_post_meta($slot_id, '_mph_slot_modes', $modes);
        foreach ($prices as $mode=>$price) update_post_meta($slot_id, '_mph_slot_price_'.$mode, $price);
        $panel = MPH_Helpers::posted('return_panel', 'key');
        wp_send_json_success(array('message'=>'زمان آزاد ثبت شد.','html'=>self::render($panel?:($manager?'manage_appointment_schedule':'therapist_schedule'))));
    }

    public static function ajax_slot_delete() {
        MPH_Helpers::verify_ajax();$slot_id=absint($_POST['slot_id']??0);$slot=get_post($slot_id);if(!$slot||$slot->post_type!==self::SLOT_TYPE)wp_send_json_error(array('message'=>'زمان پیدا نشد.'));if(!self::can_manage()&&(!self::is_therapist()||absint($slot->post_author)!==get_current_user_id()))wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);if(get_post_meta($slot_id,'_mph_slot_booked',true)||get_post_meta($slot_id,'_mph_reserved_appointment',true))wp_send_json_error(array('message'=>'زمان رزروشده قابل حذف نیست.'));wp_delete_post($slot_id,true);$panel=MPH_Helpers::posted('return_panel','key');wp_send_json_success(array('message'=>'زمان آزاد حذف شد.','html'=>self::render($panel?:'therapist_schedule')));
    }

    public static function ajax_holidays_save() {
        MPH_Helpers::verify_ajax();
        if (!self::can_manage()) wp_send_json_error(array('message'=>'فقط مدیر مجموعه اجازه ویرایش تعطیلات تکمیلی را دارد.'), 403);
        $lines = preg_split('/\R/u', (string)MPH_Helpers::posted('holiday_dates', 'textarea'));
        $holidays = array();
        foreach (array_slice((array)$lines, 0, 150) as $index=>$line) {
            $line = trim((string)$line);
            if ($line === '') continue;
            $parts = preg_split('/\s*[|｜]\s*/u', $line, 2);
            $date = MPH_Helpers::jalali_date($parts[0] ?? '');
            if (!$date) wp_send_json_error(array('message'=>'تاریخ خط '.($index+1).' معتبر نیست؛ نمونه: ۱۴۰۵/۰۶/۱۰ | تعطیلی مجموعه'));
            $label = sanitize_text_field($parts[1] ?? 'تعطیلی مجموعه');
            $holidays[$date] = $label ?: 'تعطیلی مجموعه';
        }
        ksort($holidays);
        update_option(self::HOLIDAY_OPTION, $holidays, false);
        MPH_Helpers::audit('appointment_holidays_updated', 'count='.count($holidays));
        $panel = MPH_Helpers::posted('return_panel', 'key');
        wp_send_json_success(array('message'=>'تعطیلات تکمیلی ذخیره شد و در هر سه سطح کاربر، درمانگر و مدیر اعمال می‌شود.','html'=>self::render($panel?:'manage_appointment_schedule')));
    }

    public static function ajax_book() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in()) wp_send_json_error(array('message'=>'ابتدا وارد حساب شوید.'),401);
        if (!MPH_Security::allow('appointment_book',12,5*MINUTE_IN_SECONDS,'u:'.get_current_user_id())) wp_send_json_error(array('message'=>'تعداد درخواست‌ها زیاد است؛ کمی بعد تلاش کنید.'),429);
        $saved=MPH_Appointment_Cart::add(get_current_user_id(),absint($_POST['slot_id']??0),MPH_Helpers::posted('appointment_mode','key'),MPH_Helpers::posted('patient_note','textarea'));
        if (is_wp_error($saved)) wp_send_json_error(array('message'=>$saved->get_error_message()),409);
        MPH_Shared_Cart::sync();
        wp_send_json_success(array('message'=>'نوبت به سبد اضافه شد؛ انتخاب‌های قبلی محفوظ‌اند و ظرفیت هنگام پرداخت بررسی می‌شود.','redirect'=>MPH_Commerce::cart_redirect()));
    }

    public static function service_product_id() {return self::ensure_service_product();}

    public static function cart_slot($slot_id,$mode,$own_appointment=0) {
        $slot=get_post(absint($slot_id));
        if (!$slot || $slot->post_type!==self::SLOT_TYPE || $slot->post_status!=='publish') return new WP_Error('mph_slot','زمان انتخابی معتبر نیست.');
        $therapist=get_user_by('id',$slot->post_author);
        if (!$therapist || !MPH_Helpers::has_role('mph_therapist',$therapist)) return new WP_Error('mph_therapist','درمانگر در دسترس نیست.');
        $date=get_post_meta($slot_id,'_mph_slot_date',true);$time=get_post_meta($slot_id,'_mph_slot_time',true);
        if (!self::valid_date($date) || !self::valid_time($time) || $date<current_time('Y-m-d') || ($date===current_time('Y-m-d') && $time<=current_time('H:i'))) return new WP_Error('mph_slot_past','زمان انتخابی گذشته است؛ انتخاب در سبد محفوظ است و می‌توانید زمان دیگری انتخاب کنید.');
        if (self::holiday_info($date)) return new WP_Error('mph_holiday','این روز تعطیل است و قابل رزرو نیست.');
        if (!in_array($mode,(array)get_post_meta($slot_id,'_mph_slot_modes',true),true)) return new WP_Error('mph_slot_mode','این نوع جلسه برای ساعت انتخابی فعال نیست.');
        self::release_stale_slot($slot_id);$state=MPH_Appointment_Repository::slot_state($slot_id);
        if (($state['booked'] && $state['booked']!==absint($own_appointment)) || ($state['reserved'] && $state['reserved']!==absint($own_appointment))) return new WP_Error('mph_slot_full','این ساعت اکنون در دسترس نیست؛ انتخاب شما در سبد حفظ شده است.');
        return array('slot_id'=>absint($slot_id),'therapist_id'=>(int)$slot->post_author,'date'=>$date,'time'=>$time,'end'=>self::slot_end($slot),'duration'=>absint(get_post_meta($slot_id,'_mph_slot_duration',true)),'mode'=>$mode,'price'=>(string)(float)get_post_meta($slot_id,'_mph_slot_price_'.$mode,true),'label'=>'نوبت '.self::mode_label($mode).' با '.MPH_Helpers::display_name($therapist).' — '.self::jalali_date_label($date,false).' ساعت '.$time);
    }

    public static function ajax_cancel() {
        MPH_Helpers::verify_ajax();
        if (!is_user_logged_in()) wp_send_json_error(array('message'=>'ابتدا وارد حساب شوید.'), 401);
        $id = absint($_POST['appointment_id'] ?? 0);
        $appointment = get_post($id);
        if (!$appointment || $appointment->post_type !== self::APPOINTMENT_TYPE) wp_send_json_error(array('message'=>'نوبت پیدا نشد.'), 404);
        if (absint(get_post_meta($id, '_mph_appointment_patient', true)) !== get_current_user_id()) wp_send_json_error(array('message'=>'شما اجازه لغو این نوبت را ندارید.'), 403);
        $cancellation = self::cancellation_info($id);
        if (!$cancellation['allowed']) wp_send_json_error(array('message'=>$cancellation['message']), 409);
        self::cancel_appointment($id, 'لغو توسط کاربر');
        wp_send_json_success(array('message'=>'نوبت با موفقیت لغو شد.','html'=>self::appointment_list('user')));
    }

    public static function ajax_decision() {
        MPH_Helpers::verify_ajax();$id=absint($_POST['appointment_id']??0);$appointment=get_post($id);if(!$appointment||$appointment->post_type!==self::APPOINTMENT_TYPE)wp_send_json_error(array('message'=>'نوبت پیدا نشد.'));$therapist_id=absint(get_post_meta($id,'_mph_appointment_therapist',true));if(!self::can_manage()&&(!self::is_therapist()||$therapist_id!==get_current_user_id()))wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$decision=MPH_Helpers::posted('decision','key');$status=get_post_meta($id,'_mph_appointment_status',true);if($decision==='complete'&&$status==='confirmed')update_post_meta($id,'_mph_appointment_status','completed');elseif($decision==='cancel'&&in_array($status,array('confirmed','completed'),true))self::cancel_appointment($id,'لغو توسط درمانگر یا مدیر');else wp_send_json_error(array('message'=>'این عملیات برای وضعیت فعلی مجاز نیست.'));$panel=MPH_Helpers::posted('return_panel','key');wp_send_json_success(array('message'=>$decision==='complete'?'جلسه انجام‌شده ثبت شد.':'نوبت لغو شد.','html'=>self::render($panel?:'therapist_appointments')));
    }

    public static function ajax_therapist_profile() {
        MPH_Helpers::verify_ajax();if(!self::is_therapist())wp_send_json_error(array('message'=>'دسترسی ندارید.'),403);$specialty=MPH_Helpers::posted('specialty');if(!$specialty)wp_send_json_error(array('message'=>'حوزه تخصص را وارد کنید.'));$phone=MPH_Helpers::posted('therapy_phone');if($phone&&!MPH_Helpers::phone($phone))wp_send_json_error(array('message'=>'شماره تماس جلسات باید با 09 شروع شود و ۱۱ رقم باشد.'));$online=esc_url_raw(MPH_Helpers::posted('online_url','raw'));$id=get_current_user_id();$card_saved=MPH_Payouts::save_profile_card($id);if(is_wp_error($card_saved))wp_send_json_error(array('message'=>$card_saved->get_error_message()));update_user_meta($id,'mph_therapist_specialty',$specialty);update_user_meta($id,'mph_therapist_license',MPH_Helpers::posted('license'));update_user_meta($id,'mph_therapist_bio',MPH_Helpers::posted('bio','textarea'));MPH_Security::update_user_meta($id,'mph_therapist_phone',$phone?MPH_Helpers::phone($phone):'');MPH_Security::update_user_meta($id,'mph_therapist_online_url',$online);MPH_Security::update_user_meta($id,'mph_therapist_office',MPH_Helpers::posted('office_address','textarea'));MPH_Security::audit('therapist_profile_updated','encrypted_fields=3',$id);wp_send_json_success(array('message'=>'پروفایل حرفه‌ای و اطلاعات رمزنگاری‌شده ذخیره شد.','html'=>self::therapist_profile()));
    }

    public static function confirm_paid_order($order_id) {
        $order=wc_get_order(absint($order_id));if (!$order || !$order->is_paid()) return;
        $conflicts=array();
        foreach (MPH_Appointment_Cart::order_ids($order) as $id) if (!self::confirm_appointment($id)) $conflicts[]=$id;
        if ($conflicts) {$order->update_meta_data('_mph_appointment_conflicts',$conflicts);$order->add_order_note('پرداخت ثبت شد اما ظرفیت برخی نوبت‌ها نیازمند بررسی مدیر و تعیین تکلیف وجه است.');$order->save();MPH_Payment_Attempts::event($order,'appointment_review','ظرفیت نوبت پس از پرداخت نیازمند بررسی مدیر است.');}
        elseif(MPH_Appointment_Cart::order_ids($order)){$order->delete_meta_data('_mph_appointment_conflicts');$order->save();MPH_Payment_Attempts::event($order,'appointment_confirmed','نوبت‌های خریداری‌شده قطعی شدند.');}
    }

    public static function handle_receipt_decision($order,$decision) {
        if (!$order) return false;
        foreach (MPH_Appointment_Cart::order_ids($order) as $id) {
            if ($decision==='approve') self::confirm_appointment($id);
            elseif ($decision==='reject') self::cancel_appointment($id,'رد فیش توسط مدیر');
        }
        return true;
    }

    private static function confirm_appointment($appointment_id) {
        $slot=absint(get_post_meta($appointment_id,'_mph_appointment_slot',true));$lease=MPH_Appointment_Lock::acquire($slot,90);
        if (!$lease) return false;
        try {wp_cache_delete($slot,'post_meta');return self::confirm_appointment_locked($appointment_id);}
        finally {MPH_Appointment_Lock::release($slot,$lease);}
    }

    private static function confirm_appointment_locked($appointment_id) {
        $appointment=get_post(absint($appointment_id));if(!$appointment||$appointment->post_type!==self::APPOINTMENT_TYPE)return false;$slot_id=absint(get_post_meta($appointment_id,'_mph_appointment_slot',true));if(!$slot_id)return false;$current=get_post_meta($appointment_id,'_mph_appointment_status',true);$state=MPH_Appointment_Repository::slot_state($slot_id);if(in_array($current,array('confirmed','completed'),true)&&$state['booked']===absint($appointment_id))return true;if($current==='cancelled'||($state['booked']&&$state['booked']!==absint($appointment_id)))return false;if(!MPH_Appointment_Repository::confirm_slot($slot_id,$appointment_id))return false;update_post_meta($appointment_id,'_mph_appointment_status','confirmed');$patient_id=absint(get_post_meta($appointment_id,'_mph_appointment_patient',true));$therapist_id=absint(get_post_meta($appointment_id,'_mph_appointment_therapist',true));$therapist=get_user_by('id',$therapist_id);$patient=get_user_by('id',$patient_id);$date=get_post_meta($appointment_id,'_mph_appointment_date',true);$time=get_post_meta($appointment_id,'_mph_appointment_time',true);$date_label=self::jalali_date_label($date,true);MPH_Tickets::create_system_notification($patient_id,'نوبت شما قطعی شد','نوبت شما با '.($therapist?MPH_Helpers::display_name($therapist):'درمانگر').' در '.$date_label.' ساعت '.$time.' قطعی شد.','appointment');MPH_Tickets::create_system_notification($therapist_id,'نوبت جدید قطعی شد','یک نوبت جدید برای '.($patient?MPH_Helpers::display_name($patient):'مراجع').' در '.$date_label.' ساعت '.$time.' ثبت شد.','appointment');return true;
    }

    public static function release_hold($appointment_id) {if(get_post_meta($appointment_id,'_mph_cart_booking',true)){MPH_Appointment_Cart::expire($appointment_id);return;}$appointment=get_post(absint($appointment_id));if(!$appointment||$appointment->post_type!==self::APPOINTMENT_TYPE)return;if(get_post_meta($appointment_id,'_mph_appointment_status',true)!=='awaiting_payment')return;$order_id=absint(get_post_meta($appointment_id,'_mph_appointment_order',true));$order=$order_id&&function_exists('wc_get_order')?wc_get_order($order_id):false;if($order&&$order->is_paid()){self::confirm_appointment($appointment_id);return;}self::cancel_appointment($appointment_id,'انقضای مهلت پرداخت');if($order&&!$order->has_status(array('cancelled','failed'))) $order->update_status('cancelled','مهلت پرداخت رزرو نوبت تمام شد.');}

    private static function cancel_appointment($appointment_id,$reason) {
        $appointment_id=absint($appointment_id);$previous=get_post_meta($appointment_id,'_mph_appointment_status',true);if($previous==='cancelled')return;
        $slot_id=absint(get_post_meta($appointment_id,'_mph_appointment_slot',true));if($slot_id)MPH_Appointment_Repository::release_slot($slot_id,$appointment_id);
        update_post_meta($appointment_id,'_mph_appointment_status','cancelled');update_post_meta($appointment_id,'_mph_appointment_cancel_reason',sanitize_text_field($reason));
        $order_id=absint(get_post_meta($appointment_id,'_mph_appointment_order',true));$order=$order_id&&function_exists('wc_get_order')?wc_get_order($order_id):false;if($order){if($order->get_meta(MPH_Commerce::RECEIPT_META)==='yes')$order->update_meta_data(MPH_Commerce::RECEIPT_STATUS,'cancelled');if(!$order->is_paid()&&!$order->has_status(array('cancelled','refunded'))) $order->update_status('cancelled','نوبت مرتبط لغو شد.');elseif(in_array($previous,array('confirmed','completed'),true))$order->add_order_note('نوبت پس از قطعی‌شدن لغو شد؛ وضعیت بازپرداخت باید توسط مدیر بررسی شود.');$order->save();}
        $patient_id=absint(get_post_meta($appointment_id,'_mph_appointment_patient',true));$therapist_id=absint(get_post_meta($appointment_id,'_mph_appointment_therapist',true));if($patient_id)MPH_Tickets::create_system_notification($patient_id,'نوبت لغو شد','نوبت شما لغو شد. دلیل: '.sanitize_text_field($reason),'appointment');if($therapist_id&&$reason!=='انقضای مهلت پرداخت')MPH_Tickets::create_system_notification($therapist_id,'نوبت لغو شد','یکی از نوبت‌های شما لغو شد. دلیل: '.sanitize_text_field($reason),'appointment');
    }

    private static function release_stale_slot($slot_id) {$appointment_id=absint(get_post_meta($slot_id,'_mph_reserved_appointment',true));if(!$appointment_id)return;$status=get_post_meta($appointment_id,'_mph_appointment_status',true);$created=get_post_time('U',true,$appointment_id);if(get_post_meta($appointment_id,'_mph_cart_booking',true)){if((int)get_post_meta($appointment_id,'_mph_appointment_hold_until',true)<=time())MPH_Appointment_Cart::expire($appointment_id);return;}if($status==='awaiting_payment'&&$created&&time()-$created>self::HOLD_MINUTES*MINUTE_IN_SECONDS)self::release_hold($appointment_id);elseif(!$status)delete_post_meta($slot_id,'_mph_reserved_appointment');}

    private static function create_order($appointment_id,$price,$user,$therapist,$slot,$mode) {
        $product_id=self::ensure_service_product();$product=$product_id?wc_get_product($product_id):false;if(!$product)throw new Exception('محصول خدمات نوبت‌دهی ساخته نشد.');$order=wc_create_order(array('customer_id'=>$user->ID,'created_via'=>'mph-appointment'));if(is_wp_error($order))throw new Exception($order->get_error_message());$item=new WC_Order_Item_Product();$item->set_product($product);$item->set_name('رزرو نوبت '.self::mode_label($mode).' با '.MPH_Helpers::display_name($therapist));$item->set_quantity(1);$item->set_subtotal((float)$price);$item->set_total((float)$price);$item->add_meta_data('تاریخ جلسه',self::jalali_date_label(get_post_meta($slot->ID,'_mph_slot_date',true),true),true);$item->add_meta_data('ساعت جلسه',get_post_meta($slot->ID,'_mph_slot_time',true).' تا '.self::slot_end($slot),true);$item->add_meta_data('نوع جلسه',self::mode_label($mode),true);$item->add_meta_data(self::ORDER_META,absint($appointment_id),true);$order->add_item($item);$email=substr((string)$user->user_email,-8)==='.invalid'?'':$user->user_email;$order->set_address(array('first_name'=>$user->first_name,'last_name'=>$user->last_name,'email'=>$email,'phone'=>get_user_meta($user->ID,'mph_phone',true),'address_1'=>get_user_meta($user->ID,'mph_address',true),'postcode'=>get_user_meta($user->ID,'mph_postal_code',true),'country'=>'IR'),'billing');$order->update_meta_data(self::ORDER_META,absint($appointment_id));$order->update_meta_data('_mph_appointment_tracking',get_post_meta($appointment_id,'_mph_appointment_tracking',true));$order->set_currency(get_woocommerce_currency());$order->calculate_totals();$order->set_status('pending','سفارش رزرو نوبت ساخته شد.');$order->save();return$order;
    }

    private static function ensure_service_product() {$id=absint(get_option(self::SERVICE_PRODUCT_OPTION));$product=$id&&function_exists('wc_get_product')?wc_get_product($id):false;if($product)return$id;if(!class_exists('WC_Product_Simple'))return 0;$product=new WC_Product_Simple();$product->set_name('خدمات رزرو نوبت درمانی');$product->set_status('publish');$product->set_catalog_visibility('hidden');$product->set_virtual(true);$product->set_regular_price('0');$product->set_price('0');$product->set_sold_individually(false);$product->set_description('محصول سیستمی افزونه برای ثبت امن پرداخت نوبت‌های درمانی.');$id=$product->save();if($id)update_option(self::SERVICE_PRODUCT_OPTION,absint($id),false);return absint($id);}

    private static function upload_receipt() {if(empty($_FILES['appointment_receipt'])||!is_array($_FILES['appointment_receipt']))return new WP_Error('missing','فایل فیش را انتخاب کنید.');$file=$_FILES['appointment_receipt'];if(!empty($file['error'])||empty($file['tmp_name'])||!is_uploaded_file($file['tmp_name']))return new WP_Error('upload','آپلود فیش کامل نشد.');if(absint($file['size']??0)>self::MAX_RECEIPT_SIZE)return new WP_Error('large','حجم فیش باید حداکثر ۲ مگابایت باشد.');$allowed=array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf');$check=wp_check_filetype_and_ext($file['tmp_name'],sanitize_file_name($file['name']??''),$allowed);if(empty($check['type'])||!in_array($check['type'],array_values($allowed),true))return new WP_Error('type','فقط تصویر یا PDF واقعی مجاز است.');$scan=apply_filters('mph_scan_uploaded_file',true,$file['tmp_name'],$check['type'],sanitize_file_name($file['name']??''));if(is_wp_error($scan))return$scan;if($scan!==true)return new WP_Error('unsafe_file','فایل توسط کنترل امنیتی رد شد.');require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$id=media_handle_upload('appointment_receipt',0,array(),array('test_form'=>false,'mimes'=>$allowed));return is_wp_error($id)?$id:absint($id);}

    private static function slot_overlaps($therapist_id,$date,$time,$duration) {
        $start = self::time_to_minutes($time);
        $end = $start + absint($duration);
        $slots = get_posts(array('post_type'=>self::SLOT_TYPE,'post_status'=>'publish','author'=>absint($therapist_id),'numberposts'=>-1,'meta_key'=>'_mph_slot_date','meta_value'=>$date));
        foreach ($slots as $slot) {
            $existing_start = self::time_to_minutes(get_post_meta($slot->ID, '_mph_slot_time', true));
            $existing_end = $existing_start + max(15, absint(get_post_meta($slot->ID, '_mph_slot_duration', true)));
            if ($start < $existing_end && $end > $existing_start) return true;
        }
        return false;
    }

    private static function time_to_minutes($time) {
        if (!self::valid_time($time) || !preg_match('/^(\d{2}):(\d{2})$/', (string)$time, $match)) return 0;
        return absint($match[1]) * 60 + absint($match[2]);
    }

    private static function valid_time($time) {
        if (!preg_match('/^(\d{2}):(\d{2})$/', (string)$time, $match)) return false;
        return absint($match[1]) <= 23 && absint($match[2]) <= 59;
    }

    private static function valid_date($date) {
        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', (string)$date, $match)) return false;
        return checkdate(absint($match[2]), absint($match[3]), absint($match[1]));
    }

    private static function minutes_to_time($minutes) {
        $minutes = max(0, min(1439, absint($minutes)));
        return sprintf('%02d:%02d', (int)floor($minutes / 60), $minutes % 60);
    }

    private static function slot_end($slot) {
        $end = (string)get_post_meta($slot->ID, '_mph_slot_end', true);
        if (self::valid_time($end)) return $end;
        $start = self::time_to_minutes(get_post_meta($slot->ID, '_mph_slot_time', true));
        return self::minutes_to_time($start + absint(get_post_meta($slot->ID, '_mph_slot_duration', true)));
    }

    private static function appointment_timestamp($appointment_id) {
        $date = (string)get_post_meta($appointment_id, '_mph_appointment_date', true);
        $time = (string)get_post_meta($appointment_id, '_mph_appointment_time', true);
        if (!self::valid_date($date) || !self::valid_time($time)) return 0;
        $value = DateTimeImmutable::createFromFormat('!Y-m-d H:i', $date.' '.$time, wp_timezone());
        return $value ? $value->getTimestamp() : 0;
    }

    private static function cancellation_info($appointment_id) {
        $status = sanitize_key(get_post_meta($appointment_id, '_mph_appointment_status', true));
        $eligible = in_array($status, array('awaiting_payment','pending_receipt','confirmed'), true);
        $start = self::appointment_timestamp($appointment_id);
        $deadline = $start ? $start - DAY_IN_SECONDS : 0;
        $allowed = $eligible && $deadline && time() <= $deadline;
        $date = $deadline ? wp_date('Y-m-d', $deadline, wp_timezone()) : '';
        $label = $deadline ? self::jalali_date_label($date, true).' ساعت '.wp_date('H:i', $deadline, wp_timezone()) : '';
        $message = !$eligible ? 'این نوبت در وضعیت قابل لغو نیست.' : (!$start ? 'زمان نوبت معتبر نیست.' : 'لغو فقط تا ۲۴ ساعت پیش از ساعت مراجعه امکان‌پذیر است و مهلت آن پایان یافته است.');
        return array('eligible'=>$eligible,'allowed'=>$allowed,'deadline'=>$label,'message'=>$message);
    }

    private static function available_slots($therapist_id=0) {
        static $cache=array();$cache_key=absint($therapist_id);
        if(isset($cache[$cache_key]))return$cache[$cache_key];
        $args=array('post_type'=>self::SLOT_TYPE,'post_status'=>'publish','numberposts'=>300,'meta_key'=>'_mph_slot_date','orderby'=>'meta_value','order'=>'ASC');
        if($therapist_id)$args['author']=absint($therapist_id);
        $posts=get_posts($args);$today=current_time('Y-m-d');$now=current_time('H:i');$result=array();
        foreach($posts as$post){
            self::release_stale_slot($post->ID);
            $date=get_post_meta($post->ID,'_mph_slot_date',true);$time=get_post_meta($post->ID,'_mph_slot_time',true);
            if($date<$today||($date===$today&&$time<=$now)||self::holiday_info($date)||get_post_meta($post->ID,'_mph_slot_booked',true)||get_post_meta($post->ID,'_mph_reserved_appointment',true))continue;
            $result[]=$post;
        }
        $cache[$cache_key]=$result;return$result;
    }

    /**
     * تعطیلات ثابت شمسی. تعطیلات قمری متغیر در نگاشت سالانه یا فهرست تکمیلی مدیر نگهداری می‌شوند.
     */
    private static function recurring_holidays() {
        return array(
            '01/01'=>'نوروز','01/02'=>'تعطیلات نوروز','01/03'=>'تعطیلات نوروز','01/04'=>'تعطیلات نوروز',
            '01/12'=>'روز جمهوری اسلامی','01/13'=>'روز طبیعت','03/14'=>'رحلت امام خمینی','03/15'=>'قیام پانزده خرداد',
            '11/22'=>'پیروزی انقلاب اسلامی','12/29'=>'ملی‌شدن صنعت نفت ایران',
        );
    }

    /**
     * نگاشت داخلی تعطیلات رسمی سال‌های فعال. مدیر می‌تواند مناسبت‌های جدید، محلی یا تغییرات رسمی را تکمیل کند.
     */
    private static function dated_holidays() {
        $dates=array(
            '1405/01/01','1405/01/02','1405/01/03','1405/01/04','1405/01/12','1405/01/13','1405/01/24',
            '1405/03/03','1405/03/06','1405/03/14','1405/03/15','1405/04/03','1405/04/04','1405/05/13',
            '1405/05/21','1405/05/22','1405/05/30','1405/06/08','1405/08/22','1405/10/02','1405/10/16',
            '1405/11/04','1405/11/22','1405/12/09','1405/12/19','1405/12/20','1405/12/29',
            '1406/01/01','1406/01/02','1406/01/03','1406/01/04','1406/01/12','1406/01/13','1406/01/14',
            '1406/02/24','1406/02/27','1406/03/04','1406/03/14','1406/03/15','1406/03/24','1406/03/25',
            '1406/05/03','1406/05/11','1406/05/12','1406/05/20','1406/05/29','1406/08/12','1406/09/21',
            '1406/10/05','1406/10/23','1406/11/22','1406/11/28','1406/12/08','1406/12/09','1406/12/29',
        );
        return array_fill_keys($dates, 'تعطیل رسمی');
    }

    private static function custom_holidays() {
        static $cache=null;if($cache!==null)return$cache;
        $stored=get_option(self::HOLIDAY_OPTION,array());$result=array();
        foreach((array)$stored as$date=>$label){$valid=MPH_Helpers::jalali_date($date);if($valid)$result[$valid]=sanitize_text_field($label?:'تعطیلی مجموعه');}
        ksort($result);$cache=$result;return$cache;
    }

    private static function holiday_map() {
        static $cache=null;if($cache===null)$cache=array_replace(self::dated_holidays(),self::custom_holidays());return$cache;
    }

    private static function holiday_client_data() {
        return array('dates'=>self::holiday_map(),'recurring'=>self::recurring_holidays(),'fridays'=>true);
    }

    private static function holiday_info($gregorian_date) {
        if(!self::valid_date($gregorian_date))return false;
        $date=DateTimeImmutable::createFromFormat('!Y-m-d',$gregorian_date,wp_timezone());
        if($date&&$date->format('w')==='5')return'جمعه';
        $jalali=MPH_Helpers::gregorian_to_jalali_date($gregorian_date);
        if(!$jalali)return false;
        $dates=self::holiday_map();
        if(isset($dates[$jalali]))return$dates[$jalali];
        $recurring=self::recurring_holidays();$key=substr($jalali,5);
        return isset($recurring[$key])?$recurring[$key]:false;
    }

    private static function next_working_date($gregorian_date) {
        $cursor=DateTimeImmutable::createFromFormat('!Y-m-d',(string)$gregorian_date,wp_timezone());
        if(!$cursor)$cursor=new DateTimeImmutable('today',wp_timezone());
        for($index=0;$index<370;$index++){
            $value=$cursor->format('Y-m-d');if(!self::holiday_info($value))return$value;$cursor=$cursor->modify('+1 day');
        }
        return$cursor->format('Y-m-d');
    }

    private static function query_appointments($view,$user_id) {return MPH_Appointment_Repository::query($view,$user_id);}

    private static function modes() {return array('phone'=>array('label'=>'تلفنی','icon'=>'dashicons-phone','hint'=>'تماس در زمان رزروشده'),'online'=>array('label'=>'آنلاین','icon'=>'dashicons-video-alt3','hint'=>'جلسه تصویری یا آنلاین'),'inperson'=>array('label'=>'حضوری','icon'=>'dashicons-location-alt','hint'=>'مراجعه به محل درمانگر'));}
    private static function session_details($therapist_id,$mode) {
        if ($mode === 'phone') {
            $value = MPH_Security::get_user_meta($therapist_id, 'mph_therapist_phone') ?: get_user_meta($therapist_id, 'mph_phone', true);
            return $value ? array('label'=>'شماره تماس جلسه','value'=>$value,'url'=>'','icon'=>'dashicons-phone') : array();
        }
        if ($mode === 'online') {
            $url = esc_url_raw(MPH_Security::get_user_meta($therapist_id, 'mph_therapist_online_url'));
            return $url ? array('label'=>'لینک اختصاصی جلسه','value'=>$url,'url'=>$url,'icon'=>'dashicons-video-alt3') : array();
        }
        if ($mode === 'inperson') {
            $value = MPH_Security::get_user_meta($therapist_id, 'mph_therapist_office');
            return $value ? array('label'=>'آدرس مراجعه حضوری','value'=>$value,'url'=>'','icon'=>'dashicons-location-alt') : array();
        }
        return array();
    }
    public static function mode_label($mode) {$modes=self::modes();return $modes[sanitize_key($mode)]['label']??'جلسه';}
    private static function status_label($status) {$labels=array('awaiting_payment'=>'در انتظار پرداخت','pending_receipt'=>'در انتظار تأیید فیش','confirmed'=>'قطعی','completed'=>'انجام‌شده','cancelled'=>'لغوشده','expired'=>'مهلت نگهداری ساعت پایان یافته');return $labels[sanitize_key($status)]??'نامشخص';}
    private static function slot_label($slot) {$duration=absint(get_post_meta($slot->ID,'_mph_slot_duration',true));return self::jalali_date_label(get_post_meta($slot->ID,'_mph_slot_date',true),true).' · '.get_post_meta($slot->ID,'_mph_slot_time',true).' تا '.self::slot_end($slot).' · '.$duration.' دقیقه';}
    private static function jalali_date_label($date,$weekday=true) {
        if (!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', (string)$date, $match)) return (string)$date;
        $jalali = self::gregorian_to_jalali(absint($match[1]), absint($match[2]), absint($match[3]));
        $months = array(1=>'فروردین',2=>'اردیبهشت',3=>'خرداد',4=>'تیر',5=>'مرداد',6=>'شهریور',7=>'مهر',8=>'آبان',9=>'آذر',10=>'دی',11=>'بهمن',12=>'اسفند');
        $numeric = sprintf('%04d/%02d/%02d', $jalali[0], $jalali[1], $jalali[2]);
        if (!$weekday) return self::persian_number($numeric);
        $stamp = strtotime(sprintf('%04d-%02d-%02d 12:00:00', $match[1], $match[2], $match[3]));
        $weekdays = array('یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه');
        $day_name = $stamp ? $weekdays[(int)wp_date('w', $stamp, wp_timezone())] : '';
        return trim($day_name.' '.self::persian_number($jalali[2]).' '.$months[$jalali[1]].' '.self::persian_number($jalali[0]));
    }
    private static function gregorian_to_jalali($gy,$gm,$gd) {
        $gdm=array(0,31,59,90,120,151,181,212,243,273,304,334);$gy2=$gm>2?$gy+1:$gy;
        $days=355666+(365*$gy)+(int)floor(($gy2+3)/4)-(int)floor(($gy2+99)/100)+(int)floor(($gy2+399)/400)+$gd+$gdm[$gm-1];
        $jy=-1595+33*(int)floor($days/12053);$days%=12053;$jy+=4*(int)floor($days/1461);$days%=1461;
        if($days>365){$jy+=(int)floor(($days-1)/365);$days=($days-1)%365;}
        if($days<186){$jm=1+(int)floor($days/31);$jd=1+($days%31);}else{$jm=7+(int)floor(($days-186)/30);$jd=1+(($days-186)%30);}
        return array($jy,$jm,$jd);
    }
    private static function persian_number($value) {return strtr((string)$value,array('0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹'));}
    private static function online_gateway_names() {if(!function_exists('WC'))return array();if(!WC()->payment_gateways())return class_exists('MPH_Payments')?MPH_Payments::enabled_names():array();$names=array();foreach(WC()->payment_gateways()->payment_gateways()as$gateway){if(($gateway->enabled??'no')!=='yes'||in_array($gateway->id,array('bacs','cheque','cod'),true))continue;$names[]=wp_strip_all_tags($gateway->get_title());}return array_values(array_unique(array_filter($names)));}
    private static function is_therapist() {return is_user_logged_in()&&MPH_Helpers::has_role('mph_therapist');}
    private static function can_manage() {return is_user_logged_in()&&(current_user_can('manage_options')||current_user_can('mph_manage_portal')||MPH_Helpers::has_role('mph_manager'));}

    public static function return_url($url,$order) {if(!$order||!$order->get_meta(self::ORDER_META))return$url;return MPH_Payment_Result::url($order);}
    private static function pdf_url($appointment_id) {return wp_nonce_url(admin_url('admin-post.php?action=mph_appointment_pdf&appointment_id='.absint($appointment_id)),'mph_appointment_pdf_'.absint($appointment_id));}

    public static function pdf() {
        if (!is_user_logged_in()) auth_redirect();
        $id = absint($_GET['appointment_id'] ?? 0);
        $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? ''));
        $appointment = get_post($id);
        if (!$appointment || $appointment->post_type !== self::APPOINTMENT_TYPE || !wp_verify_nonce($nonce, 'mph_appointment_pdf_'.$id)) wp_die('فایل نوبت معتبر نیست.','',array('response'=>403));
        $patient_id = absint(get_post_meta($id, '_mph_appointment_patient', true));
        $therapist_id = absint(get_post_meta($id, '_mph_appointment_therapist', true));
        if (get_current_user_id() !== $patient_id && get_current_user_id() !== $therapist_id && !self::can_manage()) wp_die('دسترسی ندارید.','',array('response'=>403));
        $status = get_post_meta($id, '_mph_appointment_status', true);
        if (!in_array($status, array('confirmed','completed'), true)) wp_die('رسید پس از قطعی‌شدن نوبت صادر می‌شود.','',array('response'=>409));
        $patient = get_user_by('id', $patient_id);
        $therapist = get_user_by('id', $therapist_id);
        $mode = get_post_meta($id, '_mph_appointment_mode', true);
        $session = self::session_details($therapist_id, $mode);
        $order_id = absint(get_post_meta($id, '_mph_appointment_order', true));
        $order = $order_id && function_exists('wc_get_order') ? wc_get_order($order_id) : false;
        $date = get_post_meta($id, '_mph_appointment_date', true);
        $start = get_post_meta($id, '_mph_appointment_time', true);
        $end = get_post_meta($id, '_mph_appointment_end', true) ?: self::minutes_to_time(self::time_to_minutes($start) + absint(get_post_meta($id, '_mph_appointment_duration', true)));
        $tracking = get_post_meta($id, '_mph_appointment_tracking', true);
        $logo = defined('MPH_LOGO_URL') ? MPH_LOGO_URL : '';
        nocache_headers(); ?>
        <!doctype html><html lang="fa" dir="rtl"><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><title>رسید نوبت <?php echo esc_html($tracking); ?></title>
        <style>body{margin:0;background:#eef4f3;color:#17343a;font-family:Tahoma,Arial,sans-serif;line-height:1.9}.page{width:800px;max-width:calc(100% - 30px);margin:30px auto;padding:36px;background:#fff;border-radius:24px;box-sizing:border-box;box-shadow:0 20px 60px #17343a18}.head{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #1f7a6d;padding-bottom:20px}.brand{display:flex;align-items:center;gap:14px}.brand img{width:68px;height:68px;object-fit:contain}.head h1{margin:0;font-size:23px}.head small{display:block;color:#67807d}.badge{background:#e4f6f1;color:#17695e;border-radius:999px;padding:7px 14px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:26px 0}.grid div{border:1px solid #dce8e6;border-radius:14px;padding:14px}.grid small{display:block;color:#738789}.session{margin:0 0 18px;padding:14px;border:1px solid #bfe1db;border-radius:14px;background:#effaf8}.session small{display:block;color:#66827f}.session a,.session b{color:#174d47;overflow-wrap:anywhere}.track{text-align:center;background:#17343a;color:#fff;border-radius:16px;padding:18px;margin-top:22px}.track b{display:block;font-size:25px;letter-spacing:3px}.foot{margin-top:24px;border-top:1px solid #dce8e6;padding-top:14px;color:#738789;font-size:12px}.print{position:fixed;left:20px;bottom:20px;border:0;border-radius:12px;padding:12px 20px;background:#1f7a6d;color:#fff;font:inherit;cursor:pointer}@media(max-width:620px){.page{padding:20px}.grid{grid-template-columns:1fr}.head{align-items:flex-start;flex-direction:column;gap:12px}}@media print{body{background:#fff}.page{width:100%;max-width:none;margin:0;box-shadow:none}.print{display:none}}</style></head><body><main class="page"><header class="head"><div class="brand"><?php if($logo): ?><img src="<?php echo esc_url($logo); ?>" alt="لوگو"><?php endif; ?><div><small><?php echo esc_html(get_bloginfo('name')); ?></small><h1>رسید رسمی رزرو نوبت</h1></div></div><span class="badge"><?php echo esc_html(self::status_label($status)); ?></span></header><section class="grid"><div><small>نام مراجع</small><b><?php echo esc_html($patient?MPH_Helpers::display_name($patient):'—'); ?></b></div><div><small>درمانگر</small><b><?php echo esc_html($therapist?MPH_Helpers::display_name($therapist):'—'); ?></b></div><div><small>تاریخ شمسی جلسه</small><b><?php echo esc_html(self::jalali_date_label($date,true)); ?></b></div><div><small>بازه مراجعه</small><b><?php echo esc_html($start.' تا '.$end); ?></b></div><div><small>نوع جلسه</small><b><?php echo esc_html(self::mode_label($mode)); ?></b></div><div><small>مبلغ پرداخت</small><b><?php echo $order?wp_kses_post($order->get_formatted_order_total()):'—'; ?></b></div></section><?php if($session): ?><div class="session"><small><?php echo esc_html($session['label']); ?></small><?php if(!empty($session['url'])): ?><a href="<?php echo esc_url($session['url']); ?>"><?php echo esc_html($session['value']); ?></a><?php else: ?><b dir="auto"><?php echo esc_html($session['value']); ?></b><?php endif; ?></div><?php endif; ?><div class="track"><small>کد پیگیری نوبت</small><b dir="ltr"><?php echo esc_html($tracking); ?></b></div><footer class="foot">این رسید به‌صورت خودکار صادر شده است. برای دریافت PDF، دکمه چاپ را بزنید و گزینه «ذخیره به‌صورت PDF» را انتخاب کنید.</footer></main><button class="print" onclick="window.print()">چاپ رسید / ذخیره PDF</button></body></html><?php exit;
    }

    private static function legacy_pdf() {
        if(!is_user_logged_in())auth_redirect();$id=absint($_GET['appointment_id']??0);$nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));$appointment=get_post($id);if(!$appointment||$appointment->post_type!==self::APPOINTMENT_TYPE||!wp_verify_nonce($nonce,'mph_appointment_pdf_'.$id))wp_die('فایل نوبت معتبر نیست.','',array('response'=>403));$patient_id=absint(get_post_meta($id,'_mph_appointment_patient',true));$therapist_id=absint(get_post_meta($id,'_mph_appointment_therapist',true));if(get_current_user_id()!==$patient_id&&get_current_user_id()!==$therapist_id&&!self::can_manage())wp_die('دسترسی ندارید.','',array('response'=>403));$status=get_post_meta($id,'_mph_appointment_status',true);if(!in_array($status,array('confirmed','completed'),true))wp_die('PDF پس از قطعی‌شدن نوبت صادر می‌شود.','',array('response'=>409));$patient=get_user_by('id',$patient_id);$therapist=get_user_by('id',$therapist_id);$mode=get_post_meta($id,'_mph_appointment_mode',true);$session=self::session_details($therapist_id,$mode);$order_id=absint(get_post_meta($id,'_mph_appointment_order',true));$order=$order_id&&function_exists('wc_get_order')?wc_get_order($order_id):false;nocache_headers();?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تأیید نوبت <?php echo esc_html(get_post_meta($id,'_mph_appointment_tracking',true)); ?></title><style>body{margin:0;background:#eef4f3;color:#17343a;font-family:Tahoma,Arial,sans-serif;line-height:1.9}.page{width:800px;max-width:calc(100% - 30px);margin:30px auto;padding:36px;background:#fff;border-radius:24px;box-sizing:border-box;box-shadow:0 20px 60px #17343a18}.head{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #1f7a6d;padding-bottom:20px}.head h1{margin:0;font-size:23px}.badge{background:#e4f6f1;color:#17695e;border-radius:999px;padding:7px 14px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:26px 0}.grid div{border:1px solid #dce8e6;border-radius:14px;padding:14px}.grid small{display:block;color:#738789}.session{margin:0 0 18px;padding:14px;border:1px solid #bfe1db;border-radius:14px;background:#effaf8}.session small{display:block;color:#66827f}.session a,.session b{color:#174d47;overflow-wrap:anywhere}.track{text-align:center;background:#17343a;color:#fff;border-radius:16px;padding:18px;margin-top:22px}.track b{display:block;font-size:25px;letter-spacing:3px}.foot{margin-top:24px;border-top:1px solid #dce8e6;padding-top:14px;color:#738789;font-size:12px}.print{position:fixed;left:20px;bottom:20px;border:0;border-radius:12px;padding:12px 20px;background:#1f7a6d;color:#fff;font:inherit;cursor:pointer}@media(max-width:620px){.page{padding:20px}.grid{grid-template-columns:1fr}.head{align-items:flex-start;flex-direction:column;gap:12px}}@media print{body{background:#fff}.page{width:100%;max-width:none;margin:0;box-shadow:none}.print{display:none}}</style></head><body onload="setTimeout(function(){window.print()},500)"><main class="page"><header class="head"><div><small><?php echo esc_html(get_bloginfo('name')); ?></small><h1>تأییدیه رسمی رزرو نوبت</h1></div><span class="badge"><?php echo esc_html(self::status_label($status)); ?></span></header><section class="grid"><div><small>نام مراجع</small><b><?php echo esc_html($patient?MPH_Helpers::display_name($patient):'—'); ?></b></div><div><small>درمانگر</small><b><?php echo esc_html($therapist?MPH_Helpers::display_name($therapist):'—'); ?></b></div><div><small>تاریخ جلسه</small><b><?php echo esc_html(get_post_meta($id,'_mph_appointment_date',true)); ?></b></div><div><small>ساعت و مدت</small><b><?php echo esc_html(get_post_meta($id,'_mph_appointment_time',true).' · '.absint(get_post_meta($id,'_mph_appointment_duration',true)).' دقیقه'); ?></b></div><div><small>نوع جلسه</small><b><?php echo esc_html(self::mode_label($mode)); ?></b></div><div><small>مبلغ پرداخت</small><b><?php echo $order?wp_kses_post($order->get_formatted_order_total()):'—'; ?></b></div></section><?php if($session): ?><div class="session"><small><?php echo esc_html($session['label']); ?></small><?php if(!empty($session['url'])): ?><a href="<?php echo esc_url($session['url']); ?>"><?php echo esc_html($session['value']); ?></a><?php else: ?><b dir="auto"><?php echo esc_html($session['value']); ?></b><?php endif; ?></div><?php endif; ?><div class="track"><small>کد پیگیری نوبت</small><b dir="ltr"><?php echo esc_html(get_post_meta($id,'_mph_appointment_tracking',true)); ?></b></div><footer class="foot">این تأییدیه به‌صورت خودکار صادر شده است. برای ذخیره فایل، در پنجره چاپ گزینه Save as PDF را انتخاب کنید.</footer></main><button class="print" onclick="window.print()">ذخیره PDF / چاپ</button></body></html><?php exit;
    }
}
