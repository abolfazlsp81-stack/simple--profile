<?php
defined('ABSPATH') || exit;

/**
 * پل حداقلی و امن ربات بله.
 *
 * این کلاس هیچ رابط ظاهری به افزونه اضافه نمی‌کند. داده‌های ربات را مستقیماً
 * به کاربران، نقش‌ها، منوها، دوره‌ها، سفارش‌ها، نوبت‌ها، اطلاعیه‌ها و تیکت‌های
 * موجود سایت متصل می‌کند و فقط وضعیت موقت گفت‌وگو را در جدول وردپرس نگه می‌دارد.
 */
final class MPH_Bale_Sync {
    const REST_NAMESPACE = 'mph-bale/v1';
    const STATE_DB_VERSION = '1.1.0';
    const NEWS_POST_OFFSET = 1000000000;
    const CHAT_META = '_mph_bale_chat_id';
    const BLOCK_META = '_mph_bale_blocked';
    const MODE_META = '_mph_bale_active_mode';

    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
    }

    public static function install() {
        if (get_option('mph_bale_state_db_version') === self::STATE_DB_VERSION && self::tables_ready()) return true;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $states = self::states_table();
        $assets = self::assets_table();
        $updates = self::updates_table();
        dbDelta("CREATE TABLE {$states} (
            chat_id varchar(64) NOT NULL,
            step varchar(100) NOT NULL DEFAULT '',
            data longtext NOT NULL,
            reminded tinyint(1) NOT NULL DEFAULT 0,
            updated_at bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (chat_id),
            KEY updated_at (updated_at),
            KEY step (step)
        ) {$charset};");
        dbDelta("CREATE TABLE {$assets} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            object_type varchar(30) NOT NULL,
            object_id bigint(20) unsigned NOT NULL,
            owner_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            bale_file_id varchar(255) NOT NULL,
            file_type varchar(30) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY object_lookup (object_type, object_id),
            KEY owner_user_id (owner_user_id)
        ) {$charset};");
        dbDelta("CREATE TABLE {$updates} (
            update_key varchar(100) NOT NULL,
            created_at bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (update_key),
            KEY created_at (created_at)
        ) {$charset};");
        if (!self::tables_ready(true)) return false;
        update_option('mph_bale_state_db_version', self::STATE_DB_VERSION, false);
        return true;
    }

    public static function register_routes() {
        register_rest_route(self::REST_NAMESPACE, '/rpc', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'rpc'),
            'permission_callback' => array(__CLASS__, 'authenticate'),
        ));
        register_rest_route(self::REST_NAMESPACE, '/asset', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'asset_upload'),
            'permission_callback' => array(__CLASS__, 'authenticate'),
        ));
    }

    public static function authenticate($request) {
        $secret = self::secret();
        if ($secret === '') return new WP_Error('mph_bale_not_configured', 'کلید همگام‌سازی ربات در سایت تنظیم نشده است.', array('status'=>503));
        $body = (string) $request->get_body();
        $is_asset = substr((string)$request->get_route(), -6) === '/asset';
        $max_body = $is_asset ? 20 * MB_IN_BYTES : MB_IN_BYTES;
        if ($body === '' || strlen($body) > $max_body) return new WP_Error('mph_bale_body', 'بدنه درخواست معتبر نیست.', array('status'=>413));
        $timestamp = (string) $request->get_header('x-mph-timestamp');
        $nonce = strtolower((string) $request->get_header('x-mph-nonce'));
        $signature = strtolower((string) $request->get_header('x-mph-signature'));
        if (!preg_match('/^\d{10}$/', $timestamp) || abs(time() - (int)$timestamp) > 300) return new WP_Error('mph_bale_expired', 'زمان درخواست منقضی شده است.', array('status'=>401));
        if (!preg_match('/^[a-f0-9]{32,64}$/', $nonce) || !preg_match('/^[a-f0-9]{64}$/', $signature)) return new WP_Error('mph_bale_signature', 'امضای درخواست معتبر نیست.', array('status'=>401));
        $meta = (string)$request->get_header('x-mph-meta');
        if(strlen($meta)>8192)return new WP_Error('mph_bale_meta','فراداده درخواست معتبر نیست.',array('status'=>413));
        $canonical = $timestamp . "\n" . $nonce . "\n" . hash('sha256', $body) . ($meta!==''?"\n".$meta:'');
        $expected = hash_hmac('sha256', $canonical, $secret);
        if (!hash_equals($expected, $signature)) return new WP_Error('mph_bale_signature', 'امضای درخواست معتبر نیست.', array('status'=>401));
        // INSERT IGNORE روی کلید یکتای wp_options اتمیک است؛ get/set transient
        // در دو درخواست هم‌زمان می‌توانست هر دو Replay را عبور دهد.
        $nonce_key = '_mph_bale_nonce_' . substr(hash('sha256', $nonce), 0, 32);
        global $wpdb;
        $inserted = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')",
            $nonce_key,
            (string)time()
        ));
        if ($inserted === false) return new WP_Error('mph_bale_nonce_store', 'ثبت شناسه امنیتی درخواست انجام نشد.', array('status'=>503));
        if ($inserted !== 1) return new WP_Error('mph_bale_replay', 'این درخواست قبلاً پردازش شده است.', array('status'=>409));
        if (wp_rand(1, 100) === 1) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED)<%d",
                $wpdb->esc_like('_mph_bale_nonce_') . '%',
                time() - 10 * MINUTE_IN_SECONDS
            ));
        }
        return true;
    }

    /** دریافت باینری واقعی فایل بله و ثبت آن در کتابخانه رسانه وردپرس. */
    public static function asset_upload($request) {
        $meta=json_decode((string)base64_decode((string)$request->get_header('x-mph-meta'),true),true);
        if (!is_array($meta)) return self::response_error('invalid_asset_meta','فراداده فایل معتبر نیست.',400,wp_generate_uuid4());
        if (!empty($meta['_job_id'])) {
            $params=$meta; $params['_actor_chat_id']=$meta['actor_chat_id']??'';
            $params['_body_hash']=hash('sha256',(string)$request->get_body());
            $result=MPH_Bale_Runtime::execute('saveAsset',$params,function()use($request){
                $response=self::asset_upload_impl($request);
                return array('status'=>$response->get_status(),'data'=>$response->get_data());
            });
            if (is_wp_error($result)) return self::response_error($result->get_error_code(),$result->get_error_message(),503,wp_generate_uuid4());
            return new WP_REST_Response($result['data'],$result['status']);
        }
        return self::asset_upload_impl($request);
    }
    private static function asset_upload_impl($request) {
        $request_id=wp_generate_uuid4();if(!self::install())return self::response_error('storage_unavailable','جدول همگام‌سازی ربات آماده نیست.',503,$request_id);$encoded=(string)$request->get_header('x-mph-meta');$decoded=$encoded!==''?base64_decode($encoded,true):false;$meta=is_string($decoded)?json_decode($decoded,true):null;
        if(!is_array($meta))return self::response_error('invalid_asset_meta','فراداده فایل معتبر نیست.',400,$request_id);
        $chat=self::chat($meta['actor_chat_id']??'');$actor=self::user_by_chat($chat);if(!$actor)return self::response_error('account_not_linked','حساب بله به سایت متصل نیست.',401,$request_id);
        $purpose=sanitize_key($meta['purpose']??'');$object_id=absint($meta['object_id']??0);$bale_file_id=sanitize_text_field($meta['bale_file_id']??'');$body=(string)$request->get_body();$size=strlen($body);
        $rules=array(
            'profile'=>array('max'=>2*MB_IN_BYTES,'mimes'=>array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp')),
            'receipt'=>array('max'=>2*MB_IN_BYTES,'mimes'=>array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf')),
            'ticket'=>array('max'=>2*MB_IN_BYTES,'mimes'=>array('jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf','txt'=>'text/plain','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','xls'=>'application/vnd.ms-excel','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')),
            'certificate'=>array('max'=>10*MB_IN_BYTES,'mimes'=>array('pdf'=>'application/pdf')),
        );
        $rules['draft_receipt']=$rules['receipt'];
        if(!isset($rules[$purpose])||$size<1||$size>$rules[$purpose]['max'])return self::response_error('invalid_asset','نوع یا اندازه فایل مجاز نیست.',422,$request_id);

        $ticket=null;$order=false;
        if($purpose==='ticket'){$ticket=self::ticket_by_id($object_id);if(!$ticket||($actor->ID!==absint($ticket->user_id)&&!self::is_manager_user($actor)&&$actor->ID!==absint($ticket->assigned_instructor_id)&&$actor->ID!==absint($ticket->assigned_therapist_id)))return self::response_error('forbidden','دسترسی فایل تیکت مجاز نیست.',403,$request_id);}
        elseif($purpose==='receipt'){$order=function_exists('wc_get_order')?wc_get_order($object_id):false;if(!$order||($actor->ID!==absint($order->get_customer_id())&&!self::is_manager_user($actor)))return self::response_error('forbidden','دسترسی فایل فیش مجاز نیست.',403,$request_id);}
        elseif($purpose==='certificate'&&!self::is_manager_user($actor))return self::response_error('forbidden','دسترسی صدور گواهی لازم است.',403,$request_id);

        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
        $name=sanitize_file_name($meta['file_name']??'');if($name==='')$name=$purpose.'-'.wp_date('Ymd-His').'.bin';$tmp=wp_tempnam($name);if(!$tmp||file_put_contents($tmp,$body)!==$size)return self::response_error('asset_write_failed','ذخیره موقت فایل انجام نشد.',500,$request_id);
        $check=wp_check_filetype_and_ext($tmp,$name,$rules[$purpose]['mimes']);if(empty($check['type'])||!in_array($check['type'],$rules[$purpose]['mimes'],true)){@unlink($tmp);return self::response_error('invalid_asset_type','محتوای فایل با نوع مجاز مطابقت ندارد.',422,$request_id);}
        $upload=wp_handle_sideload(array('name'=>$name,'type'=>$check['type'],'tmp_name'=>$tmp,'error'=>0,'size'=>$size),array('test_form'=>false,'mimes'=>$rules[$purpose]['mimes']));if(!empty($upload['error'])){@unlink($tmp);return self::response_error('asset_upload_failed','ثبت فایل در رسانه وردپرس انجام نشد.',500,$request_id);}
        // شناسه تیکت/سفارش الزاماً شناسه post نیست (به‌خصوص با WooCommerce HPOS)،
        // پس فایل ابتدا بدون والد ثبت و سپس فقط در جای درست به موجودیت مقصد متصل می‌شود.
        $attachment_id=wp_insert_attachment(array('post_mime_type'=>$check['type'],'post_title'=>sanitize_text_field(pathinfo($name,PATHINFO_FILENAME)),'post_status'=>'inherit','post_author'=>$actor->ID),$upload['file'],0,true);if(is_wp_error($attachment_id)){@unlink($upload['file']);return self::response_error('attachment_failed','ساخت پیوست وردپرس انجام نشد.',500,$request_id);}
        $metadata=wp_generate_attachment_metadata($attachment_id,$upload['file']);if(is_array($metadata))wp_update_attachment_metadata($attachment_id,$metadata);

        if($purpose==='profile'){update_user_meta($actor->ID,'mph_avatar_id',$attachment_id);update_user_meta($actor->ID,'_mph_bale_profile_file_id',$bale_file_id);if(class_exists('MPH_Tutor'))MPH_Tutor::sync_avatar($actor->ID,$attachment_id);}
        elseif($purpose==='ticket'){global$wpdb;$wpdb->update($wpdb->prefix.'mph_tickets',array('attachment_id'=>$attachment_id,'updated_at'=>current_time('mysql')),array('id'=>$ticket->id),array('%d','%s'),array('%d'));if($bale_file_id)self::save_asset('ticket',$ticket->id,$actor->ID,$bale_file_id,$check['type']);}
        elseif($purpose==='receipt'){if(class_exists('MPH_Commerce'))$order->update_meta_data(MPH_Commerce::RECEIPT_FILE,$attachment_id);$order->update_meta_data('_mph_bale_receipt_file_id',$bale_file_id);$order->save();}

        if(in_array($purpose,array('ticket','receipt'),true)){$safe=MPH_Private_Files::protect($attachment_id,$purpose,$object_id,$actor->ID);if(is_wp_error($safe)){wp_delete_attachment($attachment_id,true);return self::response_error('private_file',$safe->get_error_message(),500,$request_id);}}
        if($purpose==='draft_receipt'){$safe=MPH_Private_Files::protect($attachment_id,'draft',0,$actor->ID);if(is_wp_error($safe)){wp_delete_attachment($attachment_id,true);return self::response_error('private_file',$safe->get_error_message(),500,$request_id);}update_post_meta($attachment_id,'_mph_upload_purpose','receipt');}
        return new WP_REST_Response(array('success'=>true,'data'=>array('attachment_id'=>absint($attachment_id),'url'=>(string)wp_get_attachment_url($attachment_id),'mime'=>(string)$check['type']),'request_id'=>$request_id),200);
    }

    public static function rpc($request) {
        $payload = json_decode((string)$request->get_body(), true);
        $method = is_array($payload) ? (string)($payload['method'] ?? '') : '';
        $params = is_array($payload['params'] ?? null) ? $payload['params'] : array();
        if(time()-(int)get_option('mph_bale_last_seen',0)>60)update_option('mph_bale_last_seen',time(),false);
        $request_id = wp_generate_uuid4();
        if (!preg_match('/^[A-Za-z][A-Za-z0-9]{1,63}$/', $method)) return self::response_error('invalid_method', 'متد درخواست معتبر نیست.', 400, $request_id);
        if (!self::install()) return self::response_error('storage_unavailable', 'جدول وضعیت ربات ساخته نشد.', 503, $request_id);

        $methods = array(
            'health','context','getUser','linkAccount','createUser','updateUserField','updatePhoneByContact','syncFullName','updateProfilePhoto','getAllUsers','blockUser','getUserByPhone','resolveUserIdentifier',
            'isAdmin','isOwner','addAdmin','getAllAdmins','removeAdmin','getSetting','setSetting','getPaymentMethod','setPaymentMethod','getPaymentCardNumber','setPaymentCardNumber','getPaymentCardHolder','setPaymentCardHolder',
            'saveReceipt','getActiveCourses','getAllCourses','getCourse','updateCourseField','toggleCourseActive','createCourse','generateTrackingCode','getCourseEnrollCount','deleteCourse','isUserEnrolled','enrollUser','enrollUserPending','getEnrollmentByUserCourse','getEnrollmentById','confirmEnrollment','confirmEnrollmentById','getAllPayments','getEnrollments','getUserCourses',
            'issueCertificate','getCertificateById','getUserCertificates','createAppointment','getUserAppointments','getAppointmentById','cancelAppointment','getAllAppointments','cleanupExpiredAppointments',
            'createNews','getLatestNews','getNewsByType','countNews','getNewsById','deleteNews','saveMessage','getUserMessageHistory','getMessageById','replyToMessage','markMessageRead','getUnreadMessages','getAllMessages','getRepliedMessages','openOrCreateChat','closeChat','isChatOpen','getBookedSlotsForDay','setActiveMode',
            'stateGet','stateSet','stateClear','stateAll','stateMarkReminded','claimUpdate',
            'beginUpdate','finishUpdate','pendingUpdates','runtimeDiagnostics','heartbeatUpdate','coursePage','native'
        );
        if (!in_array($method, $methods, true)) return self::response_error('method_not_allowed', 'این عملیات در پل ربات مجاز نیست.', 404, $request_id);
        $callback = array(__CLASS__, 'rpc_' . $method);
        if (!is_callable($callback)) return self::response_error('method_unavailable', 'پیاده‌سازی عملیات در دسترس نیست.', 501, $request_id);
        try {
            $result = in_array($method,array('beginUpdate','finishUpdate','pendingUpdates','runtimeDiagnostics','heartbeatUpdate'),true)
                ? call_user_func($callback,$params) : MPH_Bale_Runtime::execute($method,$params,$callback);
            if (is_wp_error($result)) {
                $error_data = $result->get_error_data();
                $status = is_array($error_data) ? (absint($error_data['status'] ?? 400) ?: 400) : 400;
                return self::response_error($result->get_error_code(), $result->get_error_message(), $status, $request_id);
            }
            return new WP_REST_Response(array('success'=>true, 'data'=>$result, 'request_id'=>$request_id), 200);
        } catch (Throwable $error) {
            if (class_exists('MPH_Helpers')) MPH_Helpers::audit('bale_sync_error', 'method='.$method.';type='.get_class($error));
            return self::response_error('server_error', 'اجرای درخواست همگام‌سازی ممکن نبود.', 500, $request_id);
        }
    }

    public static function rpc_native($params) {return MPH_Bale_Native::call($params);}

    public static function rpc_health($params) {
        return array(
            'features'=>array('durable_updates'=>true,'bootstrap'=>true),
            'site_name'=>get_bloginfo('name'),
            'site_url'=>home_url('/'),
            'plugin_version'=>defined('MPH_VERSION') ? MPH_VERSION : '',
            'wordpress_version'=>get_bloginfo('version'),
            'database'=>'wordpress',
            'store_currency'=>function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : '',
            'bot_price_unit'=>'IRT',
            'server_time'=>time(),
        );
    }

    public static function rpc_context($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        if (!$chat_id || !self::actor_matches($params, $chat_id)) return new WP_Error('forbidden', 'شناسه گفت‌وگو معتبر نیست.', array('status'=>403));
        $user = self::user_by_chat($chat_id);
        return array(
            'bot_active'=>get_option('mph_bale_bot_active', '1') !== '0',
            'is_admin'=>$user ? self::is_bot_admin($user) : false,
            'is_owner'=>$user ? self::is_owner_user($user) : false,
            'user'=>$user ? self::user_payload($user, true) : null,
            'account_url'=>MPH_Helpers::account_page_url(),
            'site_name'=>get_bloginfo('name'),
            'logo_url'=>defined('MPH_LOGO_URL') ? MPH_LOGO_URL : '',
        );
    }

    public static function rpc_beginUpdate($p) { return MPH_Bale_Runtime::begin($p,array(__CLASS__,'rpc_context'),array(__CLASS__,'rpc_stateGet')); }
    public static function rpc_finishUpdate($p) { return MPH_Bale_Runtime::finish($p); }
    public static function rpc_heartbeatUpdate($p) { return MPH_Bale_Runtime::heartbeat($p); }
    public static function rpc_pendingUpdates($p) { return MPH_Bale_Runtime::pending(); }
    public static function rpc_runtimeDiagnostics($p) { return MPH_Bale_Runtime::diagnostics($p); }

    public static function rpc_getUser($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        if (!$chat_id || !self::actor_matches($params, $chat_id)) return new WP_Error('forbidden', 'دسترسی ندارید.', array('status'=>403));
        $user = self::user_by_chat($chat_id);
        return $user ? self::user_payload($user, true) : null;
    }

    /** A signed bot request must attest an own-contact payload received from Bale. */
    public static function rpc_linkAccount($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        $contact_id = self::chat($params['contact_user_id'] ?? '');
        if (!$chat_id || !$contact_id || !hash_equals($chat_id, $contact_id) || !self::actor_matches($params, $chat_id)) {
            return new WP_Error('contact_required', 'شماره باید با دکمه اشتراک شماره خودتان در بله تأیید شود.', array('status'=>403));
        }
        $phone = MPH_Helpers::phone($params['phone'] ?? '');
        if (!$phone) return new WP_Error('invalid_phone', 'شماره موبایل معتبر نیست.', array('status'=>422));
        $matches = self::phone_users($phone);
        if (count($matches) > 1) return new WP_Error('duplicate_phone', 'این شماره روی چند حساب سایت ثبت شده؛ مدیر باید حساب‌ها را بررسی کند.', array('status'=>409));
        $user = $matches ? $matches[0] : false;
        $chat_owner = self::user_by_chat($chat_id);
        if ($chat_owner && (!$user || $chat_owner->ID !== $user->ID)) return new WP_Error('link_conflict', 'این حساب بله به حساب دیگری در سایت متصل است.', array('status'=>409));
        if ($user) {
            $linked = self::chat(get_user_meta($user->ID, self::CHAT_META, true));
            if ($linked && $linked !== $chat_id) return new WP_Error('link_conflict', 'این حساب سایت به حساب بله دیگری متصل است؛ با مدیر تماس بگیرید.', array('status'=>409));
            if (get_user_meta($user->ID, self::BLOCK_META, true)) return new WP_Error('account_blocked', 'دسترسی این حساب محدود شده است.', array('status'=>403));
            update_user_meta($user->ID, self::CHAT_META, $chat_id);
            delete_transient('mph_bale_contact_' . hash('sha256', $chat_id));
            MPH_Helpers::audit('bale_account_linked', 'user='.$user->ID, $user->ID);
            // Existing names, roles and profile fields remain the website's values.
            return array('linked'=>true);
        }
        set_transient('mph_bale_contact_' . hash('sha256', $chat_id), $phone, 2 * HOUR_IN_SECONDS);
        return array('linked'=>false, 'phone_verified'=>true);
    }

    public static function rpc_createUser($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        if (!$chat_id || !self::actor_matches($params, $chat_id)) return new WP_Error('forbidden', 'شناسه بله با درخواست مطابقت ندارد.', array('status'=>403));
        $phone = MPH_Helpers::phone($params['phone'] ?? '');
        $first = sanitize_text_field($params['first_name'] ?? '');
        $last = sanitize_text_field($params['last_name'] ?? '');
        if (!$phone || !MPH_Helpers::valid_person_name($first) || !MPH_Helpers::valid_person_name($last)) return new WP_Error('invalid_profile', 'نام، نام خانوادگی یا شماره موبایل معتبر نیست.', array('status'=>422));

        $chat_owner = self::user_by_chat($chat_id);
        if ($chat_owner && MPH_Helpers::phone(get_user_meta($chat_owner->ID, 'mph_phone', true)) === $phone) return true;
        $verified_phone = get_transient('mph_bale_contact_' . hash('sha256', $chat_id));
        if (!is_string($verified_phone) || !hash_equals($verified_phone, $phone)) return new WP_Error('contact_required', 'تأیید شماره منقضی شده؛ /start را بزنید و شماره خودتان را دوباره تأیید کنید.', array('status'=>403));
        $phone_matches = self::phone_users($phone);
        $phone_owner = $phone_matches ? $phone_matches[0] : false;
        if ($chat_owner || $phone_owner) return new WP_Error('link_conflict', 'حساب این شماره تغییر کرده؛ با /start دوباره اتصال حساب را انجام دهید.', array('status'=>409));
        {
            $login = 'mph_' . $phone;
            if (username_exists($login)) $login .= '_' . wp_generate_password(4, false, false);
            $user_id = wp_insert_user(array(
                'user_login'=>$login,
                'user_pass'=>wp_generate_password(32, true, true),
                'user_email'=>$login . '@users.invalid',
                'first_name'=>$first,
                'last_name'=>$last,
                'display_name'=>trim($first . ' ' . $last),
                'role'=>'subscriber',
            ));
            if (is_wp_error($user_id)) return $user_id;
            $user = get_user_by('id', $user_id);
        }
        if (!$user) return new WP_Error('user_create_failed', 'ساخت یا یافتن حساب انجام نشد.', array('status'=>500));

        $saved = wp_update_user(array('ID'=>$user->ID, 'first_name'=>$first, 'last_name'=>$last, 'display_name'=>trim($first.' '.$last)));
        if (is_wp_error($saved)) return $saved;
        update_user_meta($user->ID, self::CHAT_META, $chat_id);
        update_user_meta($user->ID, 'mph_phone', $phone);
        update_user_meta($user->ID, 'billing_phone', $phone);
        $map = array(
            'mph_birth_date'=>sanitize_text_field($params['birthdate'] ?? ''),
            'mph_national_code'=>preg_replace('/\D+/', '', MPH_Helpers::normalize_digits($params['id_card'] ?? '')),
            'mph_major'=>sanitize_text_field($params['field_of_study'] ?? ''),
            'mph_education'=>sanitize_text_field($params['education_level'] ?? ''),
            'mph_first_name_en'=>sanitize_text_field($params['first_name_en'] ?? ''),
            'mph_last_name_en'=>sanitize_text_field($params['last_name_en'] ?? ''),
            '_mph_bale_profile_file_id'=>sanitize_text_field($params['profile_photo'] ?? ''),
        );
        foreach ($map as $key=>$value) if ($value !== '') update_user_meta($user->ID, $key, $value);
        if (class_exists('MPH_Tutor')) MPH_Tutor::sync_profile($user->ID, $phone, get_user_meta($user->ID, 'mph_major', true), get_user_meta($user->ID, 'mph_address', true));
        delete_transient('mph_bale_contact_' . hash('sha256', $chat_id));
        if (class_exists('MPH_Helpers')) MPH_Helpers::audit('bale_account_linked', 'user='.$user->ID, $user->ID);
        return true;
    }

    public static function rpc_updateUserField($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        $user = self::require_self($params, $chat_id);
        if (is_wp_error($user)) return $user;
        $field = (string)($params['field'] ?? '');
        $value = sanitize_text_field($params['value'] ?? '');
        $meta = array(
            'phone'=>'mph_phone','id_card'=>'mph_national_code','birthday'=>'mph_birth_date','birthdate'=>'mph_birth_date',
            'address'=>'mph_address','field_of_study'=>'mph_major','education_level'=>'mph_education',
            'name_en'=>'mph_name_en','first_name_en'=>'mph_first_name_en','last_name_en'=>'mph_last_name_en'
        );
        if (in_array($field, array('first_name','last_name','fl_name'), true)) {
            if (!MPH_Helpers::valid_person_name($value)) return new WP_Error('invalid_name', 'نام باید شامل حروف باشد.', array('status'=>422));
            $data = array('ID'=>$user->ID);
            if ($field === 'first_name') $data['first_name'] = $value;
            elseif ($field === 'last_name') $data['last_name'] = $value;
            else {
                $parts = preg_split('/\s+/u', trim($value), 2);
                $data['first_name'] = $parts[0] ?? '';
                $data['last_name'] = $parts[1] ?? '';
            }
            $first = $data['first_name'] ?? $user->first_name;
            $last = $data['last_name'] ?? $user->last_name;
            $data['display_name'] = trim($first.' '.$last);
            return !is_wp_error(wp_update_user($data));
        }
        if (!isset($meta[$field])) return new WP_Error('invalid_field', 'فیلد قابل ویرایش نیست.', array('status'=>422));
        if ($field === 'phone') return new WP_Error('phone_verification_required', 'برای تغییر شماره از بخش تنظیمات حساب در سایت و تأیید شماره استفاده کنید.', array('status'=>403));
        update_user_meta($user->ID, $meta[$field], $value);
        return true;
    }

    public static function rpc_updatePhoneByContact($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        $contact_id = self::chat($params['contact_user_id'] ?? '');
        $user = self::require_self($params, $chat_id);
        if (is_wp_error($user)) return $user;
        if (!$contact_id || !hash_equals($chat_id, $contact_id)) return new WP_Error('contact_required', 'شماره باید از دکمه تأیید شماره خودتان در بله دریافت شود.', array('status'=>403));
        $phone = MPH_Helpers::phone($params['phone'] ?? '');
        if (!$phone) return new WP_Error('invalid_phone', 'شماره موبایل معتبر نیست.', array('status'=>422));
        foreach (self::phone_users($phone) as $owner) {
            if ($owner->ID !== $user->ID) return new WP_Error('phone_exists', 'این شماره برای حساب دیگری در سایت ثبت شده است.', array('status'=>409));
        }
        update_user_meta($user->ID, 'mph_phone', $phone);
        update_user_meta($user->ID, 'billing_phone', $phone);
        if (class_exists('MPH_Tutor')) MPH_Tutor::sync_profile($user->ID, $phone, get_user_meta($user->ID, 'mph_major', true), get_user_meta($user->ID, 'mph_address', true));
        MPH_Helpers::audit('bale_phone_updated', 'user='.$user->ID, $user->ID);
        return true;
    }

    public static function rpc_syncFullName($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        $user = self::require_self($params, $chat_id);
        if (is_wp_error($user)) return $user;
        if (!empty($params['english'])) {
            update_user_meta($user->ID, 'mph_name_en', trim(get_user_meta($user->ID,'mph_first_name_en',true).' '.get_user_meta($user->ID,'mph_last_name_en',true)));
        } else {
            wp_update_user(array('ID'=>$user->ID, 'display_name'=>MPH_Helpers::display_name($user)));
        }
        return true;
    }

    public static function rpc_updateProfilePhoto($params) {
        $chat_id = self::chat($params['chat_id'] ?? '');
        $user = self::require_self($params, $chat_id);
        if (is_wp_error($user)) return $user;
        update_user_meta($user->ID, '_mph_bale_profile_file_id', sanitize_text_field($params['file_id'] ?? ''));
        return true;
    }

    public static function rpc_getAllUsers($params) {
        $actor = self::require_actor($params, true); if (is_wp_error($actor)) return $actor;
        $users = get_users(array('meta_key'=>self::CHAT_META, 'meta_compare'=>'EXISTS', 'number'=>-1, 'orderby'=>'registered', 'order'=>'DESC'));
        return array_values(array_map(function($user){ return self::user_payload($user, false); }, $users));
    }

    public static function rpc_blockUser($params) {
        $actor = self::require_actor($params, true); if (is_wp_error($actor)) return $actor;
        $target = self::user_by_chat(self::chat($params['chat_id'] ?? ''));
        if (!$target || self::is_owner_user($target)) return new WP_Error('protected_user', 'کاربر پیدا نشد یا حساب محافظت‌شده است.', array('status'=>403));
        update_user_meta($target->ID, self::BLOCK_META, empty($params['status']) ? 0 : 1);
        return true;
    }

    public static function rpc_getUserByPhone($params) {
        $actor = self::require_actor($params, false); if (is_wp_error($actor)) return $actor;
        $user = MPH_Helpers::user_by_phone(MPH_Helpers::phone($params['phone'] ?? ''));
        if (!$user) return null;
        if ($actor->ID !== $user->ID && !self::is_manager_user($actor)) return new WP_Error('forbidden', 'دسترسی ندارید.', array('status'=>403));
        return self::user_payload($user, false);
    }

    public static function rpc_resolveUserIdentifier($params) {
        $actor = self::require_actor($params, true); if (is_wp_error($actor)) return $actor;
        $input = trim((string)($params['input'] ?? ''));
        $user = self::user_by_chat(self::chat($input));
        if (!$user) $user = MPH_Helpers::user_by_phone(MPH_Helpers::phone($input));
        return $user ? self::user_payload($user, false) : null;
    }

    public static function rpc_isAdmin($params) {
        $chat = self::chat($params['chat_id'] ?? '');
        $actor = self::require_actor($params, false); if (is_wp_error($actor)) return $actor;
        $user = self::user_by_chat($chat);
        if ($user && $actor->ID !== $user->ID && !self::is_manager_user($actor)) return new WP_Error('forbidden', 'دسترسی ندارید.', array('status'=>403));
        return $user ? self::is_bot_admin($user) : false;
    }

    public static function rpc_isOwner($params) {
        $chat = self::chat($params['chat_id'] ?? '');
        $actor = self::require_actor($params, false); if (is_wp_error($actor)) return $actor;
        $user = self::user_by_chat($chat);
        if ($user && $actor->ID !== $user->ID && !self::is_manager_user($actor)) return new WP_Error('forbidden', 'دسترسی ندارید.', array('status'=>403));
        return $user ? self::is_owner_user($user) : false;
    }

    public static function rpc_addAdmin($params) {
        $actor=self::require_bot_admin($params);if(is_wp_error($actor))return $actor;
        $target=self::user_by_chat(self::chat($params['chat_id']??''));if(!$target)return new WP_Error('not_found','حساب متصل پیدا نشد.',array('status'=>404));
        update_user_meta($target->ID,'_mph_bale_admin_v28','1');MPH_Security::audit('bale_bot_admin_added','target='.$target->ID,$actor->ID);return true;
    }

    public static function rpc_getAllAdmins($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return $actor;
        self::migrate_bot_admins();$users=get_users(array('meta_key'=>'_mph_bale_admin_v28','meta_value'=>'1','number'=>-1));$rows=array();
        foreach($users as $user){$chat=self::chat(get_user_meta($user->ID,self::CHAT_META,true));if($chat)$rows[]=array('chat_id'=>$chat,'role'=>self::is_owner_user($user)?'owner':'admin','fl_name'=>MPH_Helpers::display_name($user),'wp_user_id'=>$user->ID);}
        return $rows;
    }

    public static function rpc_removeAdmin($params) {
        $actor=self::require_bot_admin($params);if(is_wp_error($actor))return $actor;
        $target=self::user_by_chat(self::chat($params['chat_id']??''));if(!$target)return new WP_Error('not_found','حساب پیدا نشد.');
        if(self::is_owner_user($target)||$target->ID===$actor->ID)return new WP_Error('protected_user','حذف سوپرادمین یا دسترسی خودتان مجاز نیست.',array('status'=>403));
        update_user_meta($target->ID,'_mph_bale_admin_v28','0');MPH_Security::audit('bale_bot_admin_removed','target='.$target->ID,$actor->ID);return true;
    }

    public static function rpc_getSetting($params) {
        $actor = self::require_bot_admin($params); if (is_wp_error($actor)) return $actor;
        $key = sanitize_key($params['key'] ?? '');
        $default = sanitize_text_field($params['default'] ?? '');
        if ($key === 'bot_active') return get_option('mph_bale_bot_active', '1');
        if ($key === 'payment_method') return get_option('mph_bale_payment_method', $default ?: 'card');
        return $default;
    }

    public static function rpc_setSetting($params) {
        $actor = self::require_bot_admin($params); if (is_wp_error($actor)) return $actor;
        $key = sanitize_key($params['key'] ?? '');
        $value = sanitize_text_field($params['value'] ?? '');
        if ($key === 'bot_active') update_option('mph_bale_bot_active', $value === '1' ? '1' : '0', false);
        elseif ($key === 'payment_method') return self::rpc_setPaymentMethod(array_merge($params, array('method'=>$value)));
        else return new WP_Error('invalid_setting', 'تنظیم مجاز نیست.', array('status'=>422));
        return true;
    }

    public static function rpc_getPaymentMethod($params) {
        $actor = self::require_actor($params, false); if (is_wp_error($actor)) return $actor;
        $default = class_exists('MPH_Payments') && MPH_Payments::enabled_names() ? 'both' : 'card';
        $method = get_option('mph_bale_payment_method', $default);
        return in_array($method, array('bale','card','both'), true) ? $method : 'card';
    }

    public static function rpc_setPaymentMethod($params) {
        $actor = self::require_actor($params, true); if (is_wp_error($actor)) return $actor;
        $method = sanitize_key($params['method'] ?? '');
        if (!in_array($method, array('bale','card','both'), true)) $method = 'card';
        update_option('mph_bale_payment_method', $method, false);
        return true;
    }

    public static function rpc_getPaymentCardNumber($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        return class_exists('MPH_Security') ? (string)MPH_Security::get_secret_option('mph_bank_card_number', '') : '';
    }
    public static function rpc_setPaymentCardNumber($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $value=sanitize_text_field($params['number']??'');
        if(class_exists('MPH_Security'))MPH_Security::update_secret_option('mph_bank_card_number',$value);else update_option('mph_bank_card_number',$value,false);
        return true;
    }
    public static function rpc_getPaymentCardHolder($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        return class_exists('MPH_Security') ? (string)MPH_Security::get_secret_option('mph_bank_card_owner', '') : '';
    }
    public static function rpc_setPaymentCardHolder($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $value=sanitize_text_field($params['holder']??'');
        if(class_exists('MPH_Security'))MPH_Security::update_secret_option('mph_bank_card_owner',$value);else update_option('mph_bank_card_owner',$value,false);
        return true;
    }

    public static function rpc_setActiveMode($params) {
        $chat = self::chat($params['chat_id'] ?? '');
        $user = self::require_self($params, $chat); if (is_wp_error($user)) return $user;
        $mode = sanitize_key($params['mode'] ?? 'user');
        if (!in_array($mode, self::available_mode_ids($user), true)) return new WP_Error('invalid_role', 'این نقش برای حساب فعال نیست.', array('status'=>403));
        update_user_meta($user->ID, self::MODE_META, $mode);
        return true;
    }

    // ───── دوره‌ها و سفارش‌ها ────────────────────────────────────
    public static function rpc_getActiveCourses($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        return self::course_rows(true);
    }

    public static function rpc_coursePage($params) {
        $actor=self::require_actor($params,false); if(is_wp_error($actor))return $actor;
        $page=max(1,absint($params['page']??1)); $size=12;
        $query=new WP_Query(array('post_type'=>self::course_type(),'post_status'=>'publish','posts_per_page'=>$size,'paged'=>$page,'orderby'=>array('date'=>'DESC','ID'=>'DESC'),'update_post_term_cache'=>false));
        $items=array();
        foreach($query->posts as $post) { $row=self::course_payload($post); $items[]=array('id'=>$row['id'],'title'=>$row['title'],'price'=>$row['price']); }
        return array('items'=>$items,'page'=>$page,'pages'=>(int)$query->max_num_pages,'total'=>(int)$query->found_posts);
    }

    public static function rpc_getAllCourses($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        return self::course_rows(false);
    }

    public static function rpc_getCourse($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        $post=self::course_post(absint($params['course_id']??0));
        if(!$post)return null;
        if($post->post_status!=='publish'&&!self::is_manager_user($actor)&&!self::enrollment_post($actor->ID,$post->ID))return null;
        return self::course_payload($post);
    }

    public static function rpc_updateCourseField($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $course=self::course_post(absint($params['course_id']??0));if(!$course)return new WP_Error('not_found','دوره پیدا نشد.',array('status'=>404));
        $field=(string)($params['field']??'');$value=$params['value']??'';
        if($field==='title'||$field==='description'){
            $update=array('ID'=>$course->ID,$field==='title'?'post_title':'post_content'=>sanitize_textarea_field($value));
            $saved=wp_update_post($update,true);return!is_wp_error($saved)&&$saved>0;
        }
        if($field==='capacity'){
            $capacity=max(0,absint($value));update_post_meta($course->ID,'_mph_bale_capacity',$capacity);
            foreach(self::course_products($course->ID)as$mode=>$product)if($mode==='inperson'){$product->update_meta_data('_mph_inperson_capacity',$capacity);$product->save();}
            return true;
        }
        if($field==='price'){
            $product=self::primary_course_product($course->ID,true);if(!$product)return new WP_Error('woocommerce_required','برای ثبت قیمت، ووکامرس باید فعال باشد.',array('status'=>409));
            $price=self::toman_to_store(max(0,(float)MPH_Helpers::normalize_digits($value)));$product->set_regular_price((string)$price);$product->set_price((string)$price);$product->save();return true;
        }
        $meta=array('start_date'=>'_mph_bale_start_date','end_date'=>'_mph_bale_end_date','promo_type'=>'_mph_bale_promo_type','promo_content'=>'_mph_bale_promo_content','promo_caption'=>'_mph_bale_promo_caption');
        if(!isset($meta[$field]))return new WP_Error('invalid_field','فیلد دوره قابل ویرایش نیست.',array('status'=>422));
        if($value===null||$value==='')delete_post_meta($course->ID,$meta[$field]);else update_post_meta($course->ID,$meta[$field],sanitize_textarea_field($value));
        return true;
    }

    public static function rpc_toggleCourseActive($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $course=self::course_post(absint($params['course_id']??0));if(!$course)return false;
        return!is_wp_error(wp_update_post(array('ID'=>$course->ID,'post_status'=>$course->post_status==='publish'?'draft':'publish'),true));
    }

    public static function rpc_createCourse($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $title=sanitize_text_field($params['title']??'');$description=sanitize_textarea_field($params['description']??'');
        if($title===''||$description==='')return new WP_Error('invalid_course','عنوان و توضیح دوره الزامی است.',array('status'=>422));
        $course_id=wp_insert_post(array('post_type'=>self::course_type(),'post_status'=>'publish','post_title'=>$title,'post_content'=>$description,'post_author'=>$actor->ID),true);
        if(is_wp_error($course_id))return$course_id;
        update_post_meta($course_id,'_mph_bale_capacity',max(0,absint($params['capacity']??0)));
        update_post_meta($course_id,'_mph_bale_start_date',sanitize_text_field($params['start_date']??''));
        update_post_meta($course_id,'_mph_bale_end_date',sanitize_text_field($params['end_date']??''));
        foreach(array('promo_type','promo_content','promo_caption')as$key)if(isset($params[$key])&&$params[$key]!==null&&$params[$key]!=='')update_post_meta($course_id,'_mph_bale_'.$key,sanitize_textarea_field($params[$key]));
        $price=self::toman_to_store(max(0,(float)MPH_Helpers::normalize_digits($params['price']??0)));
        if(class_exists('WC_Product_Simple')){
            $product=self::primary_course_product($course_id,true);
            if($product){$product->set_regular_price((string)$price);$product->set_price((string)$price);$product->save();}
        }
        update_post_meta($course_id,'_tutor_course_price_type',$price>0?'paid':'free');
        return true;
    }

    public static function rpc_generateTrackingCode($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        $prefix=preg_replace('/[^A-Z0-9]/','',strtoupper((string)($params['prefix']??'TRK')));if($prefix==='')$prefix='TRK';
        return $prefix.'-'.strtoupper(wp_generate_password(8,false,false));
    }

    public static function rpc_getCourseEnrollCount($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        $course_id=absint($params['course_id']??0);if(!$course_id)return 0;
        global$wpdb;return absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT post_author) FROM {$wpdb->posts} WHERE post_type='tutor_enrolled' AND post_parent=%d AND post_status NOT IN ('trash','auto-draft')",$course_id)));
    }

    public static function rpc_deleteCourse($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return $actor;
        $id=absint($params['course_id']??0);$previous=get_current_user_id();wp_set_current_user($actor->ID);
        try{return MPH_Operation_Lock::run('edit:course:'.$id,function()use($id){$r=MPH_Course_Lifecycle::apply($id);return is_wp_error($r)?$r:true;});}finally{wp_set_current_user($previous);}
    }

    public static function rpc_isUserEnrolled($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $course_id=absint($params['course_id']??0);$product_id=absint($params['product_id']??0);
        if($product_id){$product=self::course_product($course_id,$product_id);if(!$product)return false;return self::user_has_product_order($user->ID,$product_id);}
        return(bool)self::enrollment_post($user->ID,$course_id);
    }

    public static function rpc_enrollUser($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $course=self::course_post(absint($params['course_id']??0));if(!$course)return new WP_Error('not_found','دوره پیدا نشد.',array('status'=>404));
        if($course->post_status!=='publish')return new WP_Error('course_unavailable','این دوره در حال حاضر برای ثبت‌نام منتشر نشده است.',array('status'=>409));
        $product_id=absint($params['product_id']??0);
        if($product_id){
            $product=self::course_product($course->ID,$product_id);if(!$product)return new WP_Error('product_missing','شیوه فروش انتخاب‌شده معتبر نیست.',array('status'=>404));if((float)$product->get_price()>0)return new WP_Error('payment_required','این شیوه فروش رایگان نیست.',array('status'=>409));
            $existing=self::bale_order_for($user->ID,$course->ID,$product_id);if($existing)return(string)($existing->get_meta('_mph_bale_tracking')?:self::set_order_tracking($existing));
            $order=self::create_bale_order($user,$course,$product);if(is_wp_error($order))return$order;$order->payment_complete();if(!$order->has_status('completed'))$order->update_status('completed','ثبت‌نام رایگان از ربات بله انجام شد.');$granted=class_exists('MPH_Courses')?MPH_Courses::grant_order_access($order->get_id(),true):self::grant_enrollment($user,$course);if(is_wp_error($granted))return$granted;return(string)$order->get_meta('_mph_bale_tracking');
        }
        if(self::course_products($course->ID))return new WP_Error('delivery_required','مدل دوره را از منوی به‌روز دوره‌ها انتخاب کنید.',array('status'=>409));
        if(get_post_meta($course->ID,'_tutor_course_price_type',true)!=='free')return new WP_Error('payment_required','ثبت‌نام رایگان این دوره فعال نیست.',array('status'=>409));
        return self::grant_enrollment($user,$course);
    }

    public static function rpc_enrollUserPending($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $course=self::course_post(absint($params['course_id']??0));if(!$course)return new WP_Error('not_found','دوره پیدا نشد.',array('status'=>404));
        if($course->post_status!=='publish')return new WP_Error('course_unavailable','این دوره در حال حاضر برای ثبت‌نام منتشر نشده است.',array('status'=>409));
        $product_id=absint($params['product_id']??0);$product=$product_id?self::course_product($course->ID,$product_id):self::primary_course_product($course->ID,false);if(!$product)return new WP_Error('product_missing','محصول متصل به دوره پیدا نشد.',array('status'=>409));
        $product_id=$product->get_id();$existing=self::bale_order_for($user->ID,$course->ID,$product_id);
        if($existing)return(string)($existing->get_meta('_mph_bale_tracking')?:self::set_order_tracking($existing));
        if(!function_exists('wc_create_order'))return new WP_Error('woocommerce_required','ووکامرس برای سفارش پولی فعال نیست.',array('status'=>409));
        $order=self::create_bale_order($user,$course,$product);return is_wp_error($order)?$order:(string)$order->get_meta('_mph_bale_tracking');
    }

    public static function rpc_getEnrollmentByUserCourse($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $course_id=absint($params['course_id']??0);$product_id=absint($params['product_id']??0);$order=self::bale_order_for($user->ID,$course_id,$product_id);if($order)return self::order_enrollment_payload($order);
        if($product_id)return null;
        $enrollment=self::enrollment_post($user->ID,$course_id);return$enrollment?self::post_enrollment_payload($enrollment):null;
    }

    public static function rpc_getEnrollmentById($params) {
        $id=absint($params['enrollment_id']??0);if(!$id)return null;
        $order=function_exists('wc_get_order')?wc_get_order($id):false;
        if($order&&$order->get_meta('_mph_bale_enrollment')==='yes'){
            $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
            if($actor->ID!==$order->get_customer_id()&&!self::is_manager_user($actor))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));
            return self::order_enrollment_payload($order);
        }
        $post=get_post($id);if(!$post||$post->post_type!=='tutor_enrolled')return null;
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;if($actor->ID!==(int)$post->post_author&&!self::is_manager_user($actor))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));
        return self::post_enrollment_payload($post);
    }

    public static function rpc_saveReceipt($params) {
        $order=function_exists('wc_get_order')?wc_get_order(absint($params['enrollment_id']??0)):false;if(!$order||$order->get_meta('_mph_bale_enrollment')!=='yes')return false;
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;if($actor->ID!==$order->get_customer_id()&&!self::is_manager_user($actor))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));
        $file_id=sanitize_text_field($params['file_id']??'');if($file_id==='')return false;
        $order->update_meta_data('_mph_bale_receipt_file_id',$file_id);
        if(class_exists('MPH_Commerce')){$order->update_meta_data(MPH_Commerce::RECEIPT_META,'yes');$order->update_meta_data(MPH_Commerce::RECEIPT_STATUS,'pending');}
        $order->set_payment_method('bacs');$order->set_payment_method_title('فیش ارسالی در ربات بله');$order->set_status('on-hold','فیش از ربات بله دریافت شد.');$order->save();
        return true;
    }

    public static function rpc_confirmEnrollment($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        $chat=self::chat($params['user_chat_id']??'');$user=self::user_by_chat($chat);if(!$user||($actor->ID!==$user->ID&&!self::is_manager_user($actor)))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));
        $order_id=absint($params['enrollment_id']??0);
        $order=$order_id&&function_exists('wc_get_order')?wc_get_order($order_id):self::bale_order_for($user->ID,absint($params['course_id']??0),absint($params['product_id']??0));if(!$order)return false;
        if($order->get_meta('_mph_bale_enrollment')!=='yes'||absint($order->get_customer_id())!==absint($user->ID)||absint($order->get_meta('_mph_bale_course_id'))!==absint($params['course_id']??0))return new WP_Error('order_mismatch','سفارش با حساب یا دوره مطابقت ندارد.',array('status'=>403));
        return self::confirm_order_enrollment($order,sanitize_text_field($params['payment_id']??''));
    }

    public static function rpc_confirmEnrollmentById($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $order=function_exists('wc_get_order')?wc_get_order(absint($params['enrollment_id']??0)):false;if(!$order||$order->get_meta('_mph_bale_enrollment')!=='yes')return false;
        return self::confirm_order_enrollment($order,sanitize_text_field($params['payment_id']??''));
    }

    public static function rpc_getAllPayments($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $limit=max(1,min(500,absint($params['limit']??200)));$rows=array();
        if(!function_exists('wc_get_orders'))return$rows;
        foreach(wc_get_orders(array('limit'=>$limit,'orderby'=>'date','order'=>'DESC','return'=>'objects'))as$order)if($order->get_meta('_mph_bale_enrollment')==='yes')$rows[]=self::order_enrollment_payload($order);
        return$rows;
    }

    public static function rpc_getEnrollments($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $course_id=absint($params['course_id']??0);$rows=array();$seen=array();
        global$wpdb;$posts=get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'any','post_parent'=>$course_id,'numberposts'=>-1,'orderby'=>'date','order'=>'ASC'));
        foreach($posts as$post){if($post->post_status==='trash')continue;$row=self::post_enrollment_payload($post);$rows[]=$row;$seen[absint($post->post_author)]=true;}
        if(function_exists('wc_get_orders'))foreach(wc_get_orders(array('limit'=>500,'orderby'=>'date','order'=>'DESC','return'=>'objects'))as$order){if(absint($order->get_meta('_mph_bale_course_id'))!==$course_id||$order->get_meta('_mph_bale_enrollment')!=='yes'||isset($seen[$order->get_customer_id()]))continue;$rows[]=self::order_enrollment_payload($order);}
        return$rows;
    }

    public static function rpc_getUserCourses($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $rows=array();$seen=array();$ordered_courses=array();
        // مدل‌های خرید یک دوره مستقل هستند؛ هیچ سفارش آفلاین/آنلاین/حضوری
        // جای سفارش مدل دیگر را نمی‌گیرد و هرکدام یک ردیف جدا برمی‌گردانند.
        if(function_exists('wc_get_orders'))foreach(wc_get_orders(array('customer_id'=>$user->ID,'limit'=>200,'orderby'=>'date','order'=>'DESC','return'=>'objects'))as$order){
            if($order->has_status(array('cancelled','failed','refunded','trash')))continue;
            foreach($order->get_items()as$item){
                $product=$item->get_product();$product_id=absint($item->get_product_id());
                $course_id=absint($item->get_meta('_mph_course_id')?:($product?$product->get_meta('_mph_course_id'):0));
                $mode=sanitize_key($item->get_meta('_mph_delivery_type')?:($product?$product->get_meta('_mph_delivery_type'):''));
                if(!$course_id||!in_array($mode,array('offline','online','inperson'),true))continue;
                $key=$course_id.':'.$product_id;if(isset($seen[$key]))continue;$course=self::course_post($course_id);if(!$course)continue;
                $row=self::course_payload($course);$labels=array('offline'=>'آفلاین','online'=>'آنلاین','inperson'=>'حضوری');$paid=$order->is_paid()||$order->has_status(array('processing','completed'));
                $row['order_id']=$order->get_id();$row['product_id']=$product_id;$row['delivery_mode']=$mode;$row['delivery_label']=$labels[$mode];$row['payment_status']=$paid?'paid':'pending';$row['enrolled_at']=$order->get_date_created()?$order->get_date_created()->date('Y-m-d H:i:s'):'';$row['tracking_code']=(string)($order->get_meta('_mph_bale_tracking')?:$item->get_meta('_mph_attendance_tracking'));
                $row['delivery_modes']=array_values(array_filter($row['delivery_modes'],function($variant)use($product_id,$mode){return absint($variant['product_id']??0)===$product_id||($product_id===0&&($variant['mode']??'')===$mode);}));
                $rows[]=$row;$seen[$key]=true;$ordered_courses[$course_id]=true;
            }
        }
        // ثبت‌نام قدیمی Tutor بدون سفارش قابل‌ردیابی حذف نمی‌شود و به‌عنوان
        // دسترسی آفلاین قدیمی در ربات باقی می‌ماند.
        $enrollments=get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'any','author'=>$user->ID,'numberposts'=>-1,'orderby'=>'date','order'=>'DESC'));
        foreach($enrollments as$enrollment){if($enrollment->post_status==='trash'||isset($ordered_courses[$enrollment->post_parent]))continue;$course=self::course_post($enrollment->post_parent);if(!$course)continue;$row=self::course_payload($course);$row['delivery_mode']='offline';$row['delivery_label']='آفلاین (ثبت‌نام قدیمی)';$row['payment_status']='paid';$row['enrolled_at']=$enrollment->post_date;$row['tracking_code']=(string)get_post_meta($enrollment->ID,'_mph_bale_tracking',true);$rows[]=$row;}
        return$rows;
    }

    // ───── گواهی‌نامه و نوبت ─────────────────────────────────────
    public static function rpc_issueCertificate($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $user=self::user_by_chat(self::chat($params['user_chat_id']??''));if(!$user)return new WP_Error('not_found','کاربر متصل پیدا نشد.',array('status'=>404));
        $title=sanitize_text_field($params['title']??'');if($title==='')return new WP_Error('invalid_title','عنوان گواهی الزامی است.',array('status'=>422));
        $course_id=absint($params['course_id']??0);$date=sanitize_text_field($params['issue_date']??wp_date('Y-m-d'));
        $certificate=wp_insert_post(array('post_type'=>class_exists('MPH_Certificates')?MPH_Certificates::POST_TYPE:'mph_certificate','post_status'=>'publish','post_title'=>'گواهی '.$title.' - '.$user->ID,'post_author'=>$actor->ID),true);
        if(is_wp_error($certificate))return$certificate;
        $number='CERT-'.wp_date('Y').'-'.str_pad((string)$certificate,6,'0',STR_PAD_LEFT);
        update_post_meta($certificate,'_mph_certificate_user',$user->ID);update_post_meta($certificate,'_mph_certificate_course_id',$course_id);update_post_meta($certificate,'_mph_certificate_course_title',$course_id?get_the_title($course_id):$title);update_post_meta($certificate,'_mph_certificate_issue_date',$date);update_post_meta($certificate,'_mph_certificate_number',$number);update_post_meta($certificate,'_mph_certificate_issued_by',$actor->ID);
        if(!empty($params['pdf_file_id']))update_post_meta($certificate,'_mph_certificate_bale_file_id',sanitize_text_field($params['pdf_file_id']));
        $attachment_id=absint($params['attachment_id']??0);if($attachment_id&&get_post_type($attachment_id)==='attachment'&&get_post_mime_type($attachment_id)==='application/pdf'){update_post_meta($certificate,'_mph_certificate_file_id',$attachment_id);wp_update_post(array('ID'=>$attachment_id,'post_parent'=>$certificate));}
        if(class_exists('MPH_Tickets'))MPH_Tickets::create_system_notification($user->ID,'گواهی‌نامه شما صادر شد','گواهی‌نامه «'.$title.'» در حساب شما ثبت شد.','certificate');
        return$number;
    }

    public static function rpc_getCertificateById($params) {
        $post=get_post(absint($params['certificate_id']??0));if(!$post||$post->post_type!=='mph_certificate')return null;
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;$owner=absint(get_post_meta($post->ID,'_mph_certificate_user',true));if($actor->ID!==$owner&&!self::is_manager_user($actor))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));
        return self::certificate_payload($post);
    }

    public static function rpc_getUserCertificates($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $posts=get_posts(array('post_type'=>'mph_certificate','post_status'=>'publish','numberposts'=>-1,'orderby'=>'date','order'=>'DESC','meta_key'=>'_mph_certificate_user','meta_value'=>$user->ID));
        return array_values(array_map(array(__CLASS__,'certificate_payload'),$posts));
    }

    public static function rpc_createAppointment($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        return new WP_Error('site_booking_required','رزرو جدید باید از تقویم سایت انجام شود تا درمانگر، زمان، نوع جلسه و پرداخت هم‌زمان قفل شوند.',array('status'=>409));
    }

    public static function rpc_getUserAppointments($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $posts=class_exists('MPH_Appointment_Repository')?MPH_Appointment_Repository::query('user',$user->ID,200):get_posts(array('post_type'=>'mph_appointment','post_status'=>'publish','numberposts'=>200,'meta_key'=>'_mph_appointment_patient','meta_value'=>$user->ID));
        return array_values(array_map(array(__CLASS__,'appointment_payload'),$posts));
    }

    public static function rpc_getAppointmentById($params) {
        $post=get_post(absint($params['appointment_id']??0));if(!$post||$post->post_type!=='mph_appointment')return null;
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;$patient=absint(get_post_meta($post->ID,'_mph_appointment_patient',true));$therapist=absint(get_post_meta($post->ID,'_mph_appointment_therapist',true));if(!in_array($actor->ID,array($patient,$therapist),true)&&!self::is_manager_user($actor))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));
        return self::appointment_payload($post);
    }

    public static function rpc_cancelAppointment($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;
        $post=get_post(absint($params['appointment_id']??0));if(!$post||$post->post_type!=='mph_appointment'||absint(get_post_meta($post->ID,'_mph_appointment_patient',true))!==$user->ID)return false;
        $status=sanitize_key(get_post_meta($post->ID,'_mph_appointment_status',true));if(!in_array($status,array('awaiting_payment','pending_receipt','confirmed'),true))return new WP_Error('not_cancellable','این نوبت در وضعیت قابل لغو نیست.',array('status'=>409));
        $stamp=self::appointment_timestamp($post->ID);if(!$stamp||time()>$stamp-DAY_IN_SECONDS)return new WP_Error('deadline_passed','لغو فقط تا ۲۴ ساعت پیش از نوبت ممکن است.',array('status'=>409));
        $slot=absint(get_post_meta($post->ID,'_mph_appointment_slot',true));if($slot&&class_exists('MPH_Appointment_Repository'))MPH_Appointment_Repository::release_slot($slot,$post->ID);
        update_post_meta($post->ID,'_mph_appointment_status','cancelled');update_post_meta($post->ID,'_mph_appointment_cancel_reason','لغو از ربات بله');
        $order_id=absint(get_post_meta($post->ID,'_mph_appointment_order',true));$order=$order_id&&function_exists('wc_get_order')?wc_get_order($order_id):false;if($order&&!$order->is_paid()&&!$order->has_status(array('cancelled','refunded')))$order->update_status('cancelled','نوبت از ربات بله لغو شد.');
        return true;
    }

    public static function rpc_getAllAppointments($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;$limit=max(1,min(500,absint($params['limit']??200)));
        $posts=class_exists('MPH_Appointment_Repository')?MPH_Appointment_Repository::query('manager',$actor->ID,$limit):get_posts(array('post_type'=>'mph_appointment','post_status'=>'publish','numberposts'=>$limit));
        return array_values(array_map(array(__CLASS__,'appointment_payload'),$posts));
    }

    public static function rpc_cleanupExpiredAppointments($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $posts=get_posts(array('post_type'=>'mph_appointment','post_status'=>'publish','numberposts'=>300,'fields'=>'ids'));
        foreach($posts as$id){$status=get_post_meta($id,'_mph_appointment_status',true);if(!in_array($status,array('cancelled','completed'),true)&&self::appointment_timestamp($id)&&self::appointment_timestamp($id)<time())update_post_meta($id,'_mph_appointment_status','expired');}
        return true;
    }

    public static function rpc_getBookedSlotsForDay($params) {
        $actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;
        $day=sanitize_text_field($params['day']??'');if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$day))return array();
        $slots=get_posts(array('post_type'=>'mph_therapy_slot','post_status'=>'publish','numberposts'=>500,'meta_key'=>'_mph_slot_date','meta_value'=>$day));$times=array();
        foreach($slots as$slot)if(get_post_meta($slot->ID,'_mph_slot_booked',true)||get_post_meta($slot->ID,'_mph_reserved_appointment',true))$times[]=(string)get_post_meta($slot->ID,'_mph_slot_time',true);
        return array_values(array_unique(array_filter($times)));
    }

    // ───── اخبار و اطلاعیه‌ها ─────────────────────────────────────
    public static function rpc_createNews($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;$title=sanitize_text_field($params['title']??'');$content=sanitize_textarea_field($params['content']??'');if($title===''||$content==='')return new WP_Error('invalid_news','عنوان و متن الزامی است.',array('status'=>422));
        $type=($params['type']??'news')==='announcement'?'announcement':'news';
        if($type==='announcement'){
            if(!class_exists('MPH_Notices')||!MPH_Notices::maybe_install())return new WP_Error('notice_unavailable','جدول اطلاعیه در دسترس نیست.',array('status'=>503));global$wpdb;$ok=$wpdb->insert($wpdb->prefix.'mph_announcements',array('author_id'=>$actor->ID,'title'=>$title,'message'=>$content,'audience'=>'all','recipient_count'=>absint(count_users()['total_users']??0),'legacy_id'=>0,'created_at'=>current_time('mysql')),array('%d','%s','%s','%s','%d','%d','%s'));return$ok?absint($wpdb->insert_id):0;
        }
        $post_id=wp_insert_post(array('post_type'=>'post','post_status'=>'publish','post_title'=>$title,'post_content'=>$content,'post_author'=>$actor->ID),true);return is_wp_error($post_id)?$post_id:self::NEWS_POST_OFFSET+absint($post_id);
    }

    public static function rpc_getLatestNews($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;
        $limit=max(1,min(100,absint($params['limit']??10)));$rows=array_merge(self::news_rows('news',$limit,'manager'),self::news_rows('announcement',$limit,'manager'));usort($rows,function($a,$b){return strtotime($b['created_at'])<=>strtotime($a['created_at']);});return array_slice($rows,0,$limit);
    }
    public static function rpc_getNewsByType($params) {$actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;$mode=self::active_mode($actor);return self::news_rows(($params['type']??'news')==='announcement'?'announcement':'news',max(1,min(100,absint($params['limit']??50))),$mode);}
    public static function rpc_countNews($params) {$actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;global$wpdb;$notices=class_exists('MPH_Notices')&&MPH_Notices::table_ready()?absint($wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}mph_announcements")):0;$posts=wp_count_posts('post');return$notices+absint($posts->publish??0);}
    public static function rpc_getNewsById($params) {$actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;return self::news_by_id(absint($params['news_id']??0),self::active_mode($actor));}
    public static function rpc_deleteNews($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;$id=absint($params['news_id']??0);if($id>=self::NEWS_POST_OFFSET)return(bool)wp_trash_post($id-self::NEWS_POST_OFFSET);global$wpdb;if(!class_exists('MPH_Notices')||!MPH_Notices::table_ready())return false;return$wpdb->delete($wpdb->prefix.'mph_announcements',array('id'=>$id),array('%d'))!==false;
    }

    // ───── تیکت‌ها؛ همان جدول و همان گفت‌وگوی سایت ─────────────────
    public static function rpc_saveMessage($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self($params,$chat);if(is_wp_error($user))return$user;if(!class_exists('MPH_Tickets')||!MPH_Tickets::maybe_install())return new WP_Error('tickets_unavailable','سامانه تیکت آماده نیست.',array('status'=>503));
        $message=sanitize_textarea_field($params['message']??'');$file_id=sanitize_text_field($params['file_id']??'');$file_type=sanitize_key($params['file_type']??'');if($message===''&&$file_id==='')return new WP_Error('empty_message','پیام یا پیوست الزامی است.',array('status'=>422));
        $mode=self::active_mode($user);$now=current_time('mysql');global$wpdb;$ok=$wpdb->insert($wpdb->prefix.'mph_tickets',array('user_id'=>$user->ID,'subject'=>'پیام از ربات بله','message'=>$message?:'یک پیوست در ربات بله ارسال شد.','origin_role'=>$mode,'department'=>'other','priority'=>'normal','status'=>'open','attachment_id'=>0,'user_unread'=>0,'manager_unread'=>$mode==='manager'?0:1,'created_at'=>$now,'updated_at'=>$now),array('%d','%s','%s','%s','%s','%s','%s','%d','%d','%d','%s','%s'));if(!$ok)return 0;$ticket_id=absint($wpdb->insert_id);if($file_id)self::save_asset('ticket',$ticket_id,$user->ID,$file_id,$file_type);return$ticket_id;
    }

    public static function rpc_getUserMessageHistory($params) {
        $chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;return self::ticket_rows_for_user($user->ID,max(1,min(100,absint($params['limit']??10))));
    }

    public static function rpc_getMessageById($params) {
        $ticket=self::ticket_by_id(absint($params['message_id']??0));if(!$ticket)return null;$actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;if($actor->ID!==absint($ticket->user_id)&&!self::is_manager_user($actor)&&$actor->ID!==absint($ticket->assigned_instructor_id)&&$actor->ID!==absint($ticket->assigned_therapist_id))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));return self::ticket_payload($ticket);
    }

    public static function rpc_replyToMessage($params) {
        $actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;$ticket=self::ticket_by_id(absint($params['message_id']??0));if(!$ticket)return false;$reply=sanitize_textarea_field($params['reply']??'');if($reply==='')return false;global$wpdb;$now=current_time('mysql');$insert=$wpdb->insert($wpdb->prefix.'mph_ticket_messages',array('ticket_id'=>$ticket->id,'author_id'=>$actor->ID,'author_role'=>'manager','message'=>$reply,'attachment_id'=>0,'legacy_key'=>'bale_'.wp_generate_password(12,false,false),'created_at'=>$now),array('%d','%d','%s','%s','%d','%s','%s'));if(!$insert)return false;$wpdb->update($wpdb->prefix.'mph_tickets',array('status'=>'answered','user_unread'=>1,'manager_unread'=>0,'instructor_unread'=>0,'therapist_unread'=>0,'updated_at'=>$now),array('id'=>$ticket->id),array('%s','%d','%d','%d','%d','%s'),array('%d'));return true;
    }

    public static function rpc_markMessageRead($params) {$actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;global$wpdb;$wpdb->update($wpdb->prefix.'mph_tickets',array('manager_unread'=>0),array('id'=>absint($params['message_id']??0)),array('%d'),array('%d'));return true;}
    public static function rpc_getUnreadMessages($params) {$actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;return self::ticket_query("manager_unread=1",100);}
    public static function rpc_getAllMessages($params) {$actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;return self::ticket_query('1=1',max(1,min(200,absint($params['limit']??20))));}
    public static function rpc_getRepliedMessages($params) {$actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;return self::ticket_query("status IN ('answered','closed')",max(1,min(500,absint($params['limit']??300))));}
    public static function rpc_openOrCreateChat($params) {$chat=self::chat($params['user_chat_id']??'');$user=self::require_self($params,$chat);if(is_wp_error($user))return$user;update_user_meta($user->ID,'_mph_bale_chat_open',1);return true;}
    public static function rpc_closeChat($params) {$actor=self::require_actor($params,true);if(is_wp_error($actor))return$actor;$user=self::user_by_chat(self::chat($params['user_chat_id']??''));if(!$user)return false;update_user_meta($user->ID,'_mph_bale_chat_open',0);return true;}
    public static function rpc_isChatOpen($params) {$chat=self::chat($params['user_chat_id']??'');$user=self::require_self_or_manager($params,$chat);if(is_wp_error($user))return$user;return get_user_meta($user->ID,'_mph_bale_chat_open',true)!=='0';}

    // ───── وضعیت مکالمه در دیتابیس وردپرس ────────────────────────
    public static function rpc_stateGet($params) {
        $chat=self::chat($params['chat_id']??'');if(!$chat||!self::actor_matches($params,$chat))return new WP_Error('forbidden','دسترسی وضعیت مجاز نیست.',array('status'=>403));global$wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::states_table().' WHERE chat_id=%s LIMIT 1',$chat),ARRAY_A);if(!$row)return array('step'=>null,'data'=>array(),'updated_at'=>null,'reminded'=>false);$raw=class_exists('MPH_Security')?MPH_Security::decrypt((string)$row['data']):(string)$row['data'];$data=json_decode($raw,true);return array('step'=>$row['step']?:null,'data'=>is_array($data)?$data:array(),'updated_at'=>absint($row['updated_at']),'reminded'=>!empty($row['reminded']));
    }
    public static function rpc_stateSet($params) {
        $chat=self::chat($params['chat_id']??'');if(!$chat||!self::actor_matches($params,$chat))return new WP_Error('forbidden','دسترسی وضعیت مجاز نیست.',array('status'=>403));$step=sanitize_key($params['step']??'');$data=is_array($params['data']??null)?$params['data']:array();$json=wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(!$step||!is_string($json)||strlen($json)>131072)return new WP_Error('invalid_state','وضعیت مکالمه معتبر نیست.',array('status'=>422));$stored=class_exists('MPH_Security')?MPH_Security::encrypt($json):$json;global$wpdb;$sql=$wpdb->prepare('INSERT INTO '.self::states_table().' (chat_id,step,data,reminded,updated_at) VALUES (%s,%s,%s,0,%d) ON DUPLICATE KEY UPDATE step=VALUES(step),data=VALUES(data),reminded=0,updated_at=VALUES(updated_at)',$chat,$step,$stored,time());return$wpdb->query($sql)!==false;
    }
    public static function rpc_stateClear($params) {$chat=self::chat($params['chat_id']??'');if(!$chat||!self::actor_matches($params,$chat))return new WP_Error('forbidden','دسترسی وضعیت مجاز نیست.',array('status'=>403));global$wpdb;return$wpdb->delete(self::states_table(),array('chat_id'=>$chat),array('%s'))!==false;}
    public static function rpc_stateAll($params) {global$wpdb;$rows=$wpdb->get_results('SELECT * FROM '.self::states_table().' ORDER BY updated_at ASC',ARRAY_A);$result=array();foreach((array)$rows as$row){$raw=class_exists('MPH_Security')?MPH_Security::decrypt((string)$row['data']):(string)$row['data'];$data=json_decode($raw,true);$result[(string)$row['chat_id']]=array('step'=>$row['step']?:null,'data'=>is_array($data)?$data:array(),'updated_at'=>absint($row['updated_at']),'reminded'=>!empty($row['reminded']));}return$result;}
    public static function rpc_stateMarkReminded($params) {$chat=self::chat($params['chat_id']??'');if(!$chat||!self::actor_matches($params,$chat))return new WP_Error('forbidden','دسترسی وضعیت مجاز نیست.',array('status'=>403));global$wpdb;return$wpdb->update(self::states_table(),array('reminded'=>1),array('chat_id'=>$chat),array('%d'),array('%s'))!==false;}
    public static function rpc_claimUpdate($params) {
        $chat=self::chat($params['chat_id']??'');$update=sanitize_text_field($params['update_id']??'');if(!$chat||!self::actor_matches($params,$chat)||!preg_match('/^\d{1,40}$/',$update))return new WP_Error('invalid_update','شناسه به‌روزرسانی معتبر نیست.',array('status'=>422));
        global$wpdb;$key=hash('sha256',$chat.':'.$update);$inserted=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO '.self::updates_table().' (update_key,created_at) VALUES (%s,%d)',$key,time()));if(random_int(1,100)===1)$wpdb->query($wpdb->prepare('DELETE FROM '.self::updates_table().' WHERE created_at<%d',time()-7*DAY_IN_SECONDS));return$inserted===1;
    }

    // ───── ابزارهای داخلی امنیت و هویت ────────────────────────────
    private static function secret() {
        $secret=defined('MPH_BALE_SYNC_SECRET')?(string)MPH_BALE_SYNC_SECRET:'';
        return strlen($secret)>=32?$secret:'';
    }
    private static function response_error($code,$message,$status,$request_id) {return new WP_REST_Response(array('success'=>false,'error'=>array('code'=>sanitize_key($code),'message'=>sanitize_text_field($message)),'request_id'=>$request_id),absint($status));}
    private static function states_table(){global$wpdb;return$wpdb->prefix.'mph_bale_states';}
    private static function assets_table(){global$wpdb;return$wpdb->prefix.'mph_bale_assets';}
    private static function updates_table(){global$wpdb;return$wpdb->prefix.'mph_bale_updates';}
    private static function tables_ready($refresh=false){static$ready=null;if(!$refresh&&$ready!==null)return$ready;global$wpdb;foreach(array(self::states_table(),self::assets_table(),self::updates_table())as$table)if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table)return$ready=false;return$ready=true;}
    private static function chat($value){$value=MPH_Helpers::normalize_digits(trim((string)$value));return preg_match('/^-?\d{1,32}$/',$value)?$value:'';}
    private static function actor_chat($params){return self::chat($params['_actor_chat_id']??'');}
    private static function actor_matches($params,$chat){$actor=self::actor_chat($params);return$actor!==''&&hash_equals((string)$chat,$actor);}
    private static function phone_users($phone){$phone=MPH_Helpers::phone($phone);if(!$phone)return array();return get_users(array('meta_query'=>array('relation'=>'OR',array('key'=>'mph_phone','value'=>$phone),array('key'=>'billing_phone','value'=>$phone)),'number'=>3,'count_total'=>false));}
    private static function user_by_chat($chat){$chat=self::chat($chat);if(!$chat)return false;$users=get_users(array('meta_key'=>self::CHAT_META,'meta_value'=>$chat,'number'=>1,'count_total'=>false));return$users?$users[0]:false;}
    public static function require_actor($params,$manager=false){$user=self::user_by_chat(self::actor_chat($params));if(!$user)return new WP_Error('account_not_linked','حساب بله به کاربر سایت متصل نیست.',array('status'=>401));if($manager&&!self::is_manager_user($user))return new WP_Error('forbidden','دسترسی مدیریت لازم است.',array('status'=>403));return$user;}
    private static function require_self($params,$chat){$actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;$target=self::user_by_chat($chat);if(!$target||$actor->ID!==$target->ID)return new WP_Error('forbidden','این عملیات فقط برای حساب خودتان مجاز است.',array('status'=>403));return$target;}
    private static function require_self_or_manager($params,$chat){$actor=self::require_actor($params,false);if(is_wp_error($actor))return$actor;$target=self::user_by_chat($chat);if(!$target)return new WP_Error('not_found','کاربر متصل پیدا نشد.',array('status'=>404));if($actor->ID!==$target->ID&&!self::is_manager_user($actor))return new WP_Error('forbidden','دسترسی ندارید.',array('status'=>403));return$target;}
    private static function migrate_bot_admins() {
        if(get_option('mph_bale_admins_migrated_v28'))return;
        $result=MPH_Operation_Lock::run('bale-admin-migration',function(){if(get_option('mph_bale_admins_migrated_v28'))return;foreach(get_users(array('role__in'=>array('administrator','mph_manager'),'number'=>-1)) as $u)if(get_user_meta($u->ID,'_mph_bale_admin_v28',true)==='')update_user_meta($u->ID,'_mph_bale_admin_v28','1');update_option('mph_bale_admins_migrated_v28',1,false);});
    }
    private static function is_bot_admin($user) {self::migrate_bot_admins();return $user && (self::is_owner_user($user)||get_user_meta($user->ID,'_mph_bale_admin_v28',true)==='1');}
    private static function require_bot_admin($params) {$actor=self::require_actor($params,false);if(is_wp_error($actor))return $actor;return self::is_bot_admin($actor)?$actor:new WP_Error('forbidden','اجازه مدیریت ربات ندارید.',array('status'=>403));}
    private static function is_manager_user($user){return$user instanceof WP_User&&(in_array('administrator',(array)$user->roles,true)||in_array('mph_manager',(array)$user->roles,true)||user_can($user,'mph_manage_portal')||self::is_owner_user($user));}
    private static function is_owner_user($user){if(!($user instanceof WP_User))return false;$id=class_exists('MPH_Manager')?absint(MPH_Manager::portal_super_admin_id()):absint(get_option('mph_portal_super_admin_user_id',0));return($id&&$user->ID===$id)||(is_multisite()&&is_super_admin($user->ID));}
    private static function available_mode_ids($user){$modes=array('user');if(MPH_Helpers::has_role('mph_instructor',$user))$modes[]='instructor';if(MPH_Helpers::has_role('mph_therapist',$user))$modes[]='therapist';if(self::is_manager_user($user))$modes[]='manager';return array_values(array_unique($modes));}
    private static function active_mode($user){$mode=sanitize_key(get_user_meta($user->ID,self::MODE_META,true));$available=self::available_mode_ids($user);if(!in_array($mode,$available,true))$mode=in_array('manager',$available,true)?'manager':(in_array('instructor',$available,true)?'instructor':(in_array('therapist',$available,true)?'therapist':'user'));return$mode;}
    private static function mode_title($mode){return array('user'=>'کاربر','instructor'=>'مدرس','therapist'=>'درمانگر','manager'=>'مدیر مجموعه')[$mode]??'کاربر';}

    private static function user_payload($user,$with_menu=false){
        $chat=self::chat(get_user_meta($user->ID,self::CHAT_META,true));$active=self::active_mode($user);$modes=array();foreach(self::available_mode_ids($user)as$mode)$modes[]=array('id'=>$mode,'title'=>self::mode_title($mode),'emoji'=>self::role_emoji($mode));$avatar_id=absint(get_user_meta($user->ID,'mph_avatar_id',true))?:absint(get_user_meta($user->ID,'_tutor_profile_photo',true));$site_avatar=$avatar_id?(string)wp_get_attachment_image_url($avatar_id,'medium_large'):'';$bale_avatar=(string)get_user_meta($user->ID,'_mph_bale_profile_file_id',true);
        $payload=array(
            'id'=>$chat,'chat_id'=>$chat,'wp_user_id'=>$user->ID,'fl_name'=>MPH_Helpers::display_name($user),'first_name'=>(string)$user->first_name,'last_name'=>(string)$user->last_name,
            'name_en'=>trim((string)get_user_meta($user->ID,'mph_first_name_en',true).' '.(string)get_user_meta($user->ID,'mph_last_name_en',true)),'first_name_en'=>(string)get_user_meta($user->ID,'mph_first_name_en',true),'last_name_en'=>(string)get_user_meta($user->ID,'mph_last_name_en',true),
            'phone'=>(string)get_user_meta($user->ID,'mph_phone',true),'birthdate'=>(string)get_user_meta($user->ID,'mph_birth_date',true),'birthday'=>(string)get_user_meta($user->ID,'mph_birth_date',true),'id_card'=>(string)get_user_meta($user->ID,'mph_national_code',true),'field_of_study'=>(string)get_user_meta($user->ID,'mph_major',true),'education_level'=>(string)get_user_meta($user->ID,'mph_education',true),'address'=>(string)get_user_meta($user->ID,'mph_address',true),
            'profile_photo'=>$site_avatar?:$bale_avatar,'bale_profile_file_id'=>$bale_avatar,'avatar_url'=>$site_avatar?:(string)get_avatar_url($user->ID,array('size'=>256)),'is_blocked'=>absint(get_user_meta($user->ID,self::BLOCK_META,true)),'created_at'=>(string)$user->user_registered,
            'roles'=>self::available_mode_ids($user),'modes'=>$modes,'active_mode'=>$active,'active_mode_title'=>self::mode_title($active),
        );
        if($with_menu)$payload['menu_items']=self::menu_items($user,$active);
        return$payload;
    }

    private static function menu_items($user,$mode){
        $settings=(array)get_option(MPH_Helpers::SETTINGS,array());$items=array();
        foreach((array)($settings['items']??array())as$item){if(empty($item['enabled'])||!in_array($mode,(array)($item['roles']??array('user')),true)||in_array($item['id']??'',array('notification_settings','portal_design'),true))continue;$id=sanitize_key($item['id']??'');if(!$id)continue;$image_id=absint($item['sidebar_image_id']??0);$icon_url=$image_id?(string)wp_get_attachment_image_url($image_id,'thumbnail'):'';$icon=sanitize_html_class($item['sidebar_icon']??'dashicons-menu');$items[]=array('id'=>$id,'title'=>sanitize_text_field($item['title']??$id),'hint'=>sanitize_text_field($item['hint']??''),'mode'=>$mode,'sidebar_icon'=>$icon,'card_icon'=>sanitize_html_class($item['card_icon']??$icon),'icon_url'=>$icon_url,'emoji'=>self::dashicon_emoji($icon),'url'=>add_query_arg(array('mph_mode'=>$mode,'mph_open'=>$id),MPH_Helpers::account_page_url()));}
        $top=array('user'=>'dashboard','instructor'=>'teacher_dashboard','therapist'=>'therapist_dashboard','manager'=>'manager_dashboard')[$mode]??'dashboard';$first=array();$rest=array();foreach($items as$item){if($item['id']===$top)$first[]=$item;else$rest[]=$item;}return array_merge($first,$rest);
    }
    private static function role_emoji($mode){return array('user'=>'👤','instructor'=>'👨‍🏫','therapist'=>'🩺','manager'=>'🛡️')[$mode]??'👤';}
    private static function dashicon_emoji($icon){$key=preg_replace('/^dashicons-/','',(string)$icon);$map=array('dashboard'=>'🏠','chart-area'=>'📊','chart-pie'=>'📊','chart-bar'=>'📈','admin-users'=>'👤','groups'=>'👥','businessperson'=>'👨‍🏫','id'=>'🪪','welcome-learn-more'=>'📚','playlist-video'=>'🎬','video-alt3'=>'🎥','awards'=>'🎓','clipboard'=>'📋','editor-help'=>'📝','heart'=>'❤️','cart'=>'🛒','list-view'=>'📜','calendar-alt'=>'📅','clock'=>'🕒','money-alt'=>'💳','admin-generic'=>'⚙️','admin-settings'=>'⚙️','yes-alt'=>'✅','tickets-alt'=>'🎟️','email-alt'=>'✉️','megaphone'=>'📢','sos'=>'🆘','admin-links'=>'🔗','database-export'=>'💾');return$map[$key]??'🔹';}

    // قرارداد ربات همیشه تومان است و فاکتور بله همیشه با IRR ارسال می‌شود؛
    // تبدیل در مرز WooCommerce مانع ده‌برابرشدن مبلغ فروشگاه‌های ریالی می‌شود.
    private static function price_to_toman($value,$currency=''){$currency=strtoupper((string)($currency?: (function_exists('get_woocommerce_currency')?get_woocommerce_currency():'IRT')));$value=max(0,(float)$value);return in_array($currency,array('IRR','RIAL'),true)?$value/10:$value;}
    private static function toman_to_store($value){$currency=strtoupper((string)(function_exists('get_woocommerce_currency')?get_woocommerce_currency():'IRT'));$value=max(0,(float)$value);return in_array($currency,array('IRR','RIAL'),true)?$value*10:$value;}
    private static function store_to_rial($value,$currency=''){$currency=strtoupper((string)($currency?: (function_exists('get_woocommerce_currency')?get_woocommerce_currency():'IRT')));$value=max(0,(float)$value);return(int)round(in_array($currency,array('IRR','RIAL'),true)?$value:$value*10);}

    // ───── ابزارهای داخلی دوره و سفارش ───────────────────────────
    private static function course_type(){if(class_exists('MPH_Tutor')&&MPH_Tutor::active()&&function_exists('tutor')&&!empty(tutor()->course_post_type))return tutor()->course_post_type;return'courses';}
    private static function course_post($id){$post=get_post(absint($id));return$post&&$post->post_type===self::course_type()?$post:false;}
    private static function course_rows($active){$posts=get_posts(array('post_type'=>self::course_type(),'post_status'=>$active?'publish':array('publish','draft','pending','private'),'numberposts'=>-1,'orderby'=>'date','order'=>'DESC'));return array_values(array_map(array(__CLASS__,'course_payload'),$posts));}
    private static function course_products($course_id){$result=array();$map=class_exists('MPH_Courses')?MPH_Courses::product_map($course_id):(array)get_post_meta($course_id,'_mph_delivery_products',true);if(!$map){$legacy=absint(get_post_meta($course_id,'_tutor_course_product_id',true));if($legacy)$map=array('offline'=>$legacy);}foreach((array)$map as$mode=>$id){$product=function_exists('wc_get_product')?wc_get_product(absint($id)):false;if($product)$result[sanitize_key($mode)]=$product;}return$result;}
    private static function primary_course_product($course_id,$create=false){$products=self::course_products($course_id);foreach($products as$product)if($product->get_status()==='publish')return$product;if($products)return reset($products);if(!$create||!class_exists('WC_Product_Simple'))return false;$course=self::course_post($course_id);if(!$course)return false;$product=new WC_Product_Simple();$product->set_name($course->post_title.' — آفلاین');$product->set_status('publish');$product->set_catalog_visibility('hidden');$product->set_virtual(true);$product->set_regular_price('0');$product->set_price('0');$product->update_meta_data('_mph_course_id',$course_id);$product->update_meta_data('_mph_delivery_type','offline');$product->update_meta_data('_mph_delivery_label','آفلاین');$id=$product->save();if(!$id)return false;update_post_meta($course_id,'_mph_delivery_products',array('offline'=>$id));update_post_meta($course_id,'_tutor_course_product_id',$id);return$product;}
    private static function course_payload($course){
        $modes=array();$price=0;$capacity=absint(get_post_meta($course->ID,'_mph_bale_capacity',true));foreach(self::course_products($course->ID)as$mode=>$product){if($product->get_status()!=='publish')continue;$row=array('mode'=>$mode,'label'=>(string)$product->get_meta('_mph_delivery_label'),'product_id'=>$product->get_id(),'price'=>self::price_to_toman((float)$product->get_price()),'full'=>false,'remaining'=>null);if($mode==='inperson'){$row['start']=(string)$product->get_meta('_mph_inperson_start');$row['address']=(string)$product->get_meta('_mph_inperson_address');$row['capacity']=absint($product->get_meta('_mph_inperson_capacity'));$capacity=max($capacity,$row['capacity']);if(class_exists('MPH_Growth')){$status=MPH_Growth::capacity_status($product->get_id());$row['full']=!empty($status['full']);$row['remaining']=isset($status['remaining'])?absint($status['remaining']):null;}}$modes[]=$row;if($price<=0||($row['price']>0&&$row['price']<$price))$price=$row['price'];}
        $start=(string)get_post_meta($course->ID,'_mph_bale_start_date',true);if($start==='')$start=(string)get_post_meta($course->ID,'_mph_course_calendar_date',true);$end=(string)get_post_meta($course->ID,'_mph_bale_end_date',true);
        return array('id'=>$course->ID,'title'=>wp_strip_all_tags(get_the_title($course)),'description'=>wp_strip_all_tags($course->post_content),'capacity'=>$capacity,'price'=>(int)round($price),'price_unit'=>'IRT','start_date'=>$start,'end_date'=>$end,'promo_type'=>(string)get_post_meta($course->ID,'_mph_bale_promo_type',true),'promo_content'=>(string)get_post_meta($course->ID,'_mph_bale_promo_content',true),'promo_caption'=>(string)get_post_meta($course->ID,'_mph_bale_promo_caption',true),'is_active'=>$course->post_status==='publish'?1:0,'created_at'=>$course->post_date,'url'=>(string)get_permalink($course),'image_url'=>(string)get_the_post_thumbnail_url($course->ID,'large'),'delivery_modes'=>$modes);
    }
    private static function enrollment_post($user_id,$course_id){$posts=get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'any','author'=>absint($user_id),'post_parent'=>absint($course_id),'numberposts'=>1,'orderby'=>'ID','order'=>'DESC'));return$posts&&$posts[0]->post_status!=='trash'?$posts[0]:false;}
    private static function grant_enrollment($user,$course){$existing=self::enrollment_post($user->ID,$course->ID);if($existing)return(string)(get_post_meta($existing->ID,'_mph_bale_tracking',true)?:'ENR-'.$existing->ID);$tracking='ENR-'.strtoupper(wp_generate_password(8,false,false));$id=wp_insert_post(array('post_type'=>'tutor_enrolled','post_status'=>'completed','post_author'=>$user->ID,'post_parent'=>$course->ID,'post_title'=>$course->post_title),true);if(is_wp_error($id))return$id;update_post_meta($id,'_mph_bale_tracking',$tracking);return$tracking;}
    private static function course_product($course_id,$product_id){$product_id=absint($product_id);if(!$product_id)return false;$products=self::course_products($course_id);foreach($products as$product)if($product->get_id()===$product_id&&$product->get_status()==='publish')return$product;return false;}
    private static function bale_order_for($user_id,$course_id,$product_id=0){if(!function_exists('wc_get_orders'))return false;foreach(wc_get_orders(array('customer_id'=>absint($user_id),'limit'=>100,'orderby'=>'date','order'=>'DESC','return'=>'objects'))as$order){if($order->get_meta('_mph_bale_enrollment')!=='yes'||absint($order->get_meta('_mph_bale_course_id'))!==absint($course_id)||$order->has_status(array('cancelled','failed','refunded','trash')))continue;if($product_id){$stored=absint($order->get_meta('_mph_bale_product_id'));if($stored&&$stored!==absint($product_id))continue;if(!$stored){$match=false;foreach($order->get_items()as$item)if(absint($item->get_product_id())===absint($product_id)){$match=true;break;}if(!$match)continue;}}return$order;}return false;}
    private static function user_has_product_order($user_id,$product_id){if(!function_exists('wc_get_orders'))return false;foreach(wc_get_orders(array('customer_id'=>absint($user_id),'limit'=>200,'orderby'=>'date','order'=>'DESC','return'=>'objects'))as$order){if($order->has_status(array('cancelled','failed','refunded','trash')))continue;foreach($order->get_items()as$item)if(absint($item->get_product_id())===absint($product_id))return true;}return false;}
    private static function create_bale_order($user,$course,$product){if($product->get_status()!=='publish'||!$product->is_purchasable()||!$product->is_in_stock())return new WP_Error('product_unavailable','این مدل دوره در حال حاضر قابل خرید نیست.',array('status'=>409));if(!function_exists('wc_create_order'))return new WP_Error('woocommerce_required','ووکامرس برای ساخت سفارش فعال نیست.',array('status'=>409));if(class_exists('MPH_Growth')){$capacity=MPH_Growth::capacity_status($product->get_id());if(!empty($capacity['full']))return new WP_Error('capacity_full','ظرفیت این شیوه فروش تکمیل است.',array('status'=>409));}$order=wc_create_order(array('customer_id'=>$user->ID,'created_via'=>'mph-bale'));if(is_wp_error($order))return$order;try{$item_id=$order->add_product($product,1);if(!$item_id)throw new Exception('افزودن دوره به سفارش انجام نشد.');$line=$order->get_item($item_id);if($line&&class_exists('MPH_Courses')&&MPH_Courses::sync_order_item_meta($line,$product))$line->save();$tracking='ENR-'.strtoupper(wp_generate_password(8,false,false));$order->update_meta_data('_mph_bale_enrollment','yes');$order->update_meta_data('_mph_bale_course_id',$course->ID);$order->update_meta_data('_mph_bale_product_id',$product->get_id());$order->update_meta_data('_mph_bale_delivery_mode',sanitize_key($product->get_meta('_mph_delivery_type')));$order->update_meta_data('_mph_bale_tracking',$tracking);$order->set_currency(function_exists('get_woocommerce_currency')?get_woocommerce_currency():'IRR');$order->set_address(array('first_name'=>$user->first_name,'last_name'=>$user->last_name,'phone'=>get_user_meta($user->ID,'mph_phone',true),'email'=>substr((string)$user->user_email,-8)==='.invalid'?'':$user->user_email),'billing');$order->calculate_totals();$order->set_status('pending','سفارش از ربات بله ساخته شد.');$order->save();return$order;}catch(Throwable$error){$order->delete(true);return new WP_Error('order_failed','ساخت سفارش سایت انجام نشد.',array('status'=>500));}}
    private static function set_order_tracking($order){$tracking='ENR-'.strtoupper(wp_generate_password(8,false,false));$order->update_meta_data('_mph_bale_tracking',$tracking);$order->save();return$tracking;}
    private static function order_enrollment_payload($order){$user=get_user_by('id',$order->get_customer_id());$course_id=absint($order->get_meta('_mph_bale_course_id'));$course=self::course_post($course_id);$chat=$user?self::chat(get_user_meta($user->ID,self::CHAT_META,true)):'';$paid=$order->is_paid()||$order->has_status(array('processing','completed'));$product_id=absint($order->get_meta('_mph_bale_product_id'));$mode=sanitize_key($order->get_meta('_mph_bale_delivery_mode'));if(!$product_id||!$mode){foreach($order->get_items()as$item){$product_id=$product_id?:absint($item->get_product_id());$product=$item->get_product();$mode=$mode?:sanitize_key($item->get_meta('_mph_delivery_type')?:($product?$product->get_meta('_mph_delivery_type'):''));break;}}$labels=array('offline'=>'آفلاین','online'=>'آنلاین','inperson'=>'حضوری');$total=(float)$order->get_total();$currency=(string)$order->get_currency();return array('id'=>$order->get_id(),'user_id'=>$chat,'user_chat_id'=>$chat,'course_id'=>$course_id,'product_id'=>$product_id,'delivery_mode'=>$mode,'delivery_label'=>$labels[$mode]??$mode,'fl_name'=>$user?MPH_Helpers::display_name($user):'کاربر حذف‌شده','phone'=>$user?(string)get_user_meta($user->ID,'mph_phone',true):'','course_title'=>$course?get_the_title($course):'دوره حذف‌شده','price'=>(int)round(self::price_to_toman($total,$currency)),'payment_amount_rial'=>self::store_to_rial($total,$currency),'payment_status'=>$paid?'paid':'pending','order_status'=>(string)$order->get_status(),'access_synced'=>$order->get_meta('_mph_bale_access_synced')==='yes','payment_id'=>(string)$order->get_meta('_mph_bale_payment_id'),'tracking_code'=>(string)$order->get_meta('_mph_bale_tracking'),'receipt_file_id'=>(string)$order->get_meta('_mph_bale_receipt_file_id'),'enrolled_at'=>$order->get_date_created()?$order->get_date_created()->date('Y-m-d H:i:s'):'');}
    private static function post_enrollment_payload($post){$user=get_user_by('id',$post->post_author);$course=self::course_post($post->post_parent);$chat=$user?self::chat(get_user_meta($user->ID,self::CHAT_META,true)):'';return array('id'=>$post->ID,'enrollment_id'=>$post->ID,'user_id'=>$chat,'user_chat_id'=>$chat,'chat_id'=>$chat,'course_id'=>$post->post_parent,'fl_name'=>$user?MPH_Helpers::display_name($user):'کاربر حذف‌شده','phone'=>$user?(string)get_user_meta($user->ID,'mph_phone',true):'','course_title'=>$course?get_the_title($course):'دوره حذف‌شده','price'=>$course?absint(self::course_payload($course)['price']):0,'payment_status'=>'paid','payment_id'=>'','tracking_code'=>(string)get_post_meta($post->ID,'_mph_bale_tracking',true),'receipt_file_id'=>'','enrolled_at'=>$post->post_date);}
    private static function confirm_order_enrollment($order,$payment_id){
        $existing_payment=(string)$order->get_meta('_mph_bale_payment_id');
        if($existing_payment!==''&&$payment_id!==''&&!hash_equals($existing_payment,$payment_id))return false;
        if($payment_id!=='')$order->update_meta_data('_mph_bale_payment_id',$payment_id);
        if(class_exists('MPH_Commerce'))$order->update_meta_data(MPH_Commerce::RECEIPT_STATUS,'approved');
        $order->save();
        if(!$order->is_paid())$order->payment_complete($payment_id);
        if(!$order->has_status('completed'))$order->update_status('completed','پرداخت ربات بله تأیید شد.');
        $course=self::course_post(absint($order->get_meta('_mph_bale_course_id')));
        $user=get_user_by('id',$order->get_customer_id());
        if(!$course||!$user)return false;
        if(class_exists('MPH_Courses')){
            $result=MPH_Courses::grant_order_access($order->get_id(),true);
            if(is_wp_error($result))return false;
        }elseif(is_wp_error(self::grant_enrollment($user,$course)))return false;
        $order->update_meta_data('_mph_bale_access_synced','yes');
        $order->save();
        return true;
    }

    // ───── تبدیل رکوردهای سایت به قرارداد پایدار ربات ────────────
    private static function certificate_payload($post){
        $owner_id=absint(get_post_meta($post->ID,'_mph_certificate_user',true));$owner=get_user_by('id',$owner_id);$course_id=absint(get_post_meta($post->ID,'_mph_certificate_course_id',true));$course_title=(string)get_post_meta($post->ID,'_mph_certificate_course_title',true);if($course_title===''&&$course_id)$course_title=(string)get_the_title($course_id);
        $number=(string)get_post_meta($post->ID,'_mph_certificate_number',true);if($number==='')$number='CERT-'.wp_date('Y',strtotime($post->post_date_gmt?:$post->post_date)).'-'.str_pad((string)$post->ID,6,'0',STR_PAD_LEFT);
        $file=(string)get_post_meta($post->ID,'_mph_certificate_bale_file_id',true);$attachment_id=absint(get_post_meta($post->ID,'_mph_certificate_file_id',true));if($file===''&&$attachment_id)$file=(string)wp_get_attachment_url($attachment_id);
        $issuer_id=absint(get_post_meta($post->ID,'_mph_certificate_issued_by',true));$issuer=$issuer_id?get_user_by('id',$issuer_id):get_user_by('id',$post->post_author);
        return array('id'=>$post->ID,'user_id'=>self::chat($owner?get_user_meta($owner->ID,self::CHAT_META,true):''),'user_chat_id'=>self::chat($owner?get_user_meta($owner->ID,self::CHAT_META,true):''),'course_id'=>$course_id,'title'=>$course_title?:wp_strip_all_tags($post->post_title),'course_title'=>$course_title,'cert_number'=>$number,'issue_date'=>(string)get_post_meta($post->ID,'_mph_certificate_issue_date',true),'issued_by'=>$issuer?MPH_Helpers::display_name($issuer):'مدیریت سایت','pdf_file_id'=>$file,'created_at'=>$post->post_date);
    }

    private static function appointment_payload($post){
        $patient_id=absint(get_post_meta($post->ID,'_mph_appointment_patient',true));$patient=get_user_by('id',$patient_id);$therapist_id=absint(get_post_meta($post->ID,'_mph_appointment_therapist',true));$therapist=get_user_by('id',$therapist_id);$status=sanitize_key(get_post_meta($post->ID,'_mph_appointment_status',true));
        if(in_array($status,array('awaiting_payment','pending_receipt'),true))$status='pending';
        return array('id'=>$post->ID,'user_id'=>self::chat($patient?get_user_meta($patient->ID,self::CHAT_META,true):''),'user_chat_id'=>self::chat($patient?get_user_meta($patient->ID,self::CHAT_META,true):''),'wp_user_id'=>$patient_id,'fl_name'=>$patient?MPH_Helpers::display_name($patient):'کاربر حذف‌شده','phone'=>$patient?(string)get_user_meta($patient->ID,'mph_phone',true):'','therapist_id'=>$therapist_id,'therapist_name'=>$therapist?MPH_Helpers::display_name($therapist):'','date'=>(string)get_post_meta($post->ID,'_mph_appointment_date',true),'time_slot'=>(string)get_post_meta($post->ID,'_mph_appointment_time',true),'end_time'=>(string)get_post_meta($post->ID,'_mph_appointment_end',true),'description'=>(string)get_post_meta($post->ID,'_mph_appointment_note',true),'tracking_code'=>(string)get_post_meta($post->ID,'_mph_appointment_tracking',true),'mode'=>(string)get_post_meta($post->ID,'_mph_appointment_mode',true),'status'=>$status?:'pending','order_id'=>absint(get_post_meta($post->ID,'_mph_appointment_order',true)),'created_at'=>$post->post_date);
    }

    private static function appointment_timestamp($appointment_id){
        $date=(string)get_post_meta($appointment_id,'_mph_appointment_date',true);$time=(string)get_post_meta($appointment_id,'_mph_appointment_time',true);if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||!preg_match('/^\d{1,2}:\d{2}$/',$time))return 0;
        $parsed=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$date.' '.$time,wp_timezone());return$parsed?$parsed->getTimestamp():0;
    }

    private static function news_rows($type,$limit,$mode='manager'){
        $limit=max(1,min(100,absint($limit)));$rows=array();
        if($type==='announcement'){
            if(!class_exists('MPH_Notices')||!MPH_Notices::maybe_install())return$rows;global$wpdb;$table=$wpdb->prefix.'mph_announcements';
            if($mode==='manager')$items=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} ORDER BY created_at DESC,id DESC LIMIT %d",$limit));else$items=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE audience IN ('all',%s) ORDER BY created_at DESC,id DESC LIMIT %d",$mode,$limit));
            foreach((array)$items as$item)$rows[]=array('id'=>absint($item->id),'title'=>(string)$item->title,'content'=>self::bot_text($item->message,3000),'admin_id'=>absint($item->author_id),'audience'=>(string)$item->audience,'type'=>'announcement','created_at'=>(string)$item->created_at);
            return$rows;
        }
        $posts=get_posts(array('post_type'=>'post','post_status'=>'publish','numberposts'=>$limit,'orderby'=>'date','order'=>'DESC','no_found_rows'=>true));
        foreach($posts as$post)$rows[]=array('id'=>self::NEWS_POST_OFFSET+$post->ID,'title'=>wp_strip_all_tags(get_the_title($post)),'content'=>self::bot_text($post->post_content,3000),'admin_id'=>absint($post->post_author),'type'=>'news','created_at'=>$post->post_date,'url'=>(string)get_permalink($post));
        return$rows;
    }

    private static function news_by_id($id,$mode='manager'){
        if($id>=self::NEWS_POST_OFFSET){$post=get_post($id-self::NEWS_POST_OFFSET);if(!$post||$post->post_type!=='post'||$post->post_status!=='publish')return null;return array('id'=>$id,'title'=>wp_strip_all_tags(get_the_title($post)),'content'=>self::bot_text($post->post_content,3000),'admin_id'=>absint($post->post_author),'type'=>'news','created_at'=>$post->post_date,'url'=>(string)get_permalink($post));}
        if(!class_exists('MPH_Notices')||!MPH_Notices::maybe_install())return null;global$wpdb;$item=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}mph_announcements WHERE id=%d LIMIT 1",$id));if(!$item||($mode!=='manager'&&!in_array($item->audience,array('all',$mode),true)))return null;
        return array('id'=>absint($item->id),'title'=>(string)$item->title,'content'=>self::bot_text($item->message,3000),'admin_id'=>absint($item->author_id),'audience'=>(string)$item->audience,'type'=>'announcement','created_at'=>(string)$item->created_at);
    }

    private static function bot_text($value,$limit=3000){$text=html_entity_decode(wp_strip_all_tags(strip_shortcodes((string)$value)),ENT_QUOTES,get_bloginfo('charset')?:'UTF-8');$text=trim(preg_replace('/[\t ]+/u',' ',$text));if(function_exists('mb_substr'))return mb_substr($text,0,$limit);return substr($text,0,$limit);}

    private static function save_asset($type,$object_id,$owner_id,$file_id,$file_type){global$wpdb;return(bool)$wpdb->insert(self::assets_table(),array('object_type'=>sanitize_key($type),'object_id'=>absint($object_id),'owner_user_id'=>absint($owner_id),'bale_file_id'=>sanitize_text_field($file_id),'file_type'=>sanitize_key($file_type),'created_at'=>current_time('mysql')),array('%s','%d','%d','%s','%s','%s'));}
    private static function asset_for($type,$object_id){global$wpdb;return$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::assets_table().' WHERE object_type=%s AND object_id=%d ORDER BY id DESC LIMIT 1',sanitize_key($type),absint($object_id)));}
    private static function ticket_by_id($id){if(!$id||!class_exists('MPH_Tickets')||!MPH_Tickets::maybe_install())return null;global$wpdb;return$wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}mph_tickets WHERE id=%d LIMIT 1",absint($id)));}
    private static function latest_ticket_reply($ticket){global$wpdb;return$wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}mph_ticket_messages WHERE ticket_id=%d AND author_role IN ('manager','instructor','therapist') ORDER BY id DESC LIMIT 1",absint($ticket->id)));}

    private static function ticket_payload($ticket){
        if(!empty($ticket->attachment_id))MPH_Private_Files::protect(absint($ticket->attachment_id),'ticket',absint($ticket->id),absint($ticket->user_id));
        $latest=self::latest_ticket_reply($ticket);if($latest && !empty($latest->attachment_id))MPH_Private_Files::protect(absint($latest->attachment_id),'ticket',absint($ticket->id),absint($ticket->user_id));
        $user=get_user_by('id',absint($ticket->user_id));$chat=self::chat($user?get_user_meta($user->ID,self::CHAT_META,true):'');$reply=self::latest_ticket_reply($ticket);$reply_user=$reply?get_user_by('id',absint($reply->author_id)):false;$asset=self::asset_for('ticket',$ticket->id);$file_id=$asset?(string)$asset->bale_file_id:'';$file_type=$asset?(string)$asset->file_type:'';
        if($file_id===''&&absint($ticket->attachment_id)){$file_id=(string)wp_get_attachment_url(absint($ticket->attachment_id));$mime=(string)get_post_mime_type(absint($ticket->attachment_id));$file_type=strpos($mime,'image/')===0?'photo':'document';}
        return array('attachment_id'=>absint($ticket->attachment_id),'reply_attachment_id'=>$reply?absint($reply->attachment_id):0,'id'=>absint($ticket->id),'ticket_number'=>absint($ticket->id),'user_id'=>$chat,'user_chat_id'=>$chat,'wp_user_id'=>absint($ticket->user_id),'fl_name'=>$user?MPH_Helpers::display_name($user):'کاربر حذف‌شده','phone'=>$user?(string)get_user_meta($user->ID,'mph_phone',true):'','subject'=>(string)$ticket->subject,'message'=>(string)$ticket->message,'file_id'=>$file_id,'file_type'=>$file_type,'is_read'=>empty($ticket->manager_unread)?1:0,'reply'=>$reply?(string)$reply->message:'','replied_at'=>$reply?(string)$reply->created_at:'','replied_by'=>$reply_user?MPH_Helpers::display_name($reply_user):($reply?'مدیریت سایت':''),'status'=>(string)$ticket->status,'priority'=>(string)$ticket->priority,'created_at'=>(string)$ticket->created_at,'updated_at'=>(string)$ticket->updated_at);
    }

    private static function ticket_query($where,$limit){
        $allowed=array('manager_unread=1',"status IN ('answered','closed')",'1=1');if(!in_array($where,$allowed,true)||!class_exists('MPH_Tickets')||!MPH_Tickets::maybe_install())return array();global$wpdb;$limit=max(1,min(500,absint($limit)));$tickets=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}mph_tickets WHERE {$where} ORDER BY updated_at DESC,id DESC LIMIT {$limit}");return array_values(array_map(array(__CLASS__,'ticket_payload'),(array)$tickets));
    }
    private static function ticket_rows_for_user($user_id,$limit){if(!class_exists('MPH_Tickets')||!MPH_Tickets::maybe_install())return array();global$wpdb;$tickets=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}mph_tickets WHERE user_id=%d ORDER BY updated_at DESC,id DESC LIMIT %d",absint($user_id),max(1,min(100,absint($limit)))));return array_values(array_map(array(__CLASS__,'ticket_payload'),(array)$tickets));}
}
