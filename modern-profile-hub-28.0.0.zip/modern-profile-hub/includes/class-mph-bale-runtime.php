<?php
defined('ABSPATH') || exit;

/** Durable inbox and operation receipts, stored only in WordPress. */
final class MPH_Bale_Runtime {
    const VERSION = '1';
    const LEASE = 300;
    const MAX_ATTEMPTS = 5;
    private static $ready = false;

    private static function jobs() { global $wpdb; return $wpdb->prefix.'mph_bale_jobs'; }
    private static function ops() { global $wpdb; return $wpdb->prefix.'mph_bale_operations'; }
    private static function key($chat,$update) { return hash('sha256',$chat.':'.$update); }
    private static function error($code,$message,$status=503) { return new WP_Error($code,$message,array('status'=>$status)); }

    public static function install() {
        if (self::$ready) return true;
        if (get_option('mph_bale_runtime_version')===self::VERSION) return self::$ready=true;
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $charset=$wpdb->get_charset_collate(); $jobs=self::jobs(); $ops=self::ops();
        dbDelta("CREATE TABLE {$jobs} (
            job_key varchar(64) NOT NULL,
            chat_id varchar(32) NOT NULL,
            update_id varchar(40) NOT NULL,
            status varchar(16) NOT NULL DEFAULT 'retry',
            token varchar(64) NOT NULL DEFAULT '',
            lease_until bigint(20) unsigned NOT NULL DEFAULT 0,
            attempts int unsigned NOT NULL DEFAULT 0,
            available_at bigint(20) unsigned NOT NULL DEFAULT 0,
            payload longtext NOT NULL,
            snapshot longtext NOT NULL,
            error_code varchar(64) NOT NULL DEFAULT '',
            created_at bigint(20) unsigned NOT NULL,
            updated_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (job_key),
            KEY due (status,available_at),
            KEY chat_status (chat_id,status),
            KEY updated_at (updated_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$ops} (
            op_key varchar(64) NOT NULL,
            job_key varchar(64) NOT NULL,
            status varchar(16) NOT NULL DEFAULT 'running',
            result longtext NOT NULL,
            created_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (op_key),
            KEY job_key (job_key),
            KEY created_at (created_at)
        ) {$charset};");
        foreach(array($jobs,$ops) as $table) if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table) return false;
        update_option('mph_bale_runtime_version',self::VERSION,false);
        return self::$ready=true;
    }
    private static function encode($value) {
        $json=wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) throw new RuntimeException('json_encode');
        $cipher=MPH_Security::encrypt($json);
        if ($cipher===$json) throw new RuntimeException('encryption_unavailable');
        return $cipher;
    }
    private static function decode($value) {
        $decoded=json_decode(MPH_Security::decrypt((string)$value),true);
        if (!is_array($decoded)) throw new RuntimeException('invalid_encrypted_record');
        return $decoded;
    }

    public static function begin($p,$context_callback,$state_callback) {
        if (!self::install()) return self::error('storage_unavailable','جدول پردازش ربات آماده نیست.');
        $chat=(string)($p['_actor_chat_id']??''); $id=(string)($p['update_id']??'');
        $update=$p['update']??null;
        if (!preg_match('/^\d{1,32}$/D',$chat) || !preg_match('/^\d{1,40}$/D',$id) || !is_array($update) || (string)($update['update_id']??'')!==$id) return self::error('invalid_update','درخواست ربات معتبر نیست.',422);
        $from=(string)($update['callback_query']['from']['id']??$update['message']['from']['id']??'');
        if (!hash_equals($chat,$from)) return self::error('invalid_actor','شناسه فرستنده معتبر نیست.',403);
        if (isset($update['pre_checkout_query']) || isset($update['message']['successful_payment'])) return self::error('payment_update','رویداد پرداخت مسیر مستقل دارد.',422);
        $raw=wp_json_encode($update); if (!is_string($raw) || strlen($raw)>524288) return self::error('update_size','پیام بزرگ‌تر از حد مجاز است.',413);
        global $wpdb; $table=self::jobs(); $key=self::key($chat,$id); $now=time();
        $lock='mph_chat_'.substr(hash('sha256',$chat),0,40);
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!=='1') return self::error('update_busy','درخواست دیگری در حال ثبت است.');
        try {
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE job_key=%s",$key),ARRAY_A);
            if ($row && $row['status']==='done') return array('status'=>'done');
            if ($row && $row['status']==='review') return array('status'=>'review');
            if ($row && self::decode($row['payload']) !== $update) return self::error('update_mismatch','محتوای این شناسه درخواست تغییر کرده است.',409);
            if ($row && $row['status']==='processing' && (int)$row['lease_until']>$now) return self::error('update_busy','پردازش همین درخواست ادامه دارد.');
            if ($row && (int)$row['available_at']>$now) return self::error('update_wait','درخواست برای تلاش دوباره ذخیره شده است.');
            if ($row && (int)$row['attempts']>=self::MAX_ATTEMPTS) {
                $wpdb->update($table,array('status'=>'review','error_code'=>'attempt_limit','updated_at'=>$now),array('job_key'=>$key));
                return array('status'=>'review');
            }
            if (!$row) {
                $insert=$wpdb->insert($table,array('job_key'=>$key,'chat_id'=>$chat,'update_id'=>$id,'status'=>'retry','payload'=>self::encode($update),'snapshot'=>self::encode(array()),'created_at'=>$now,'updated_at'=>$now));
                if (!$insert) return self::error('storage_unavailable','ذخیره درخواست ممکن نشد.');
                $row=array('snapshot'=>self::encode(array()),'attempts'=>0,'created_at'=>$now);
            }
            // Serialize each conversation, including retries, to protect multi-step forms.
            $older=$wpdb->get_var($wpdb->prepare("SELECT job_key FROM {$table} WHERE chat_id=%s AND job_key<>%s AND status IN ('processing','retry') AND (created_at<%d OR (created_at=%d AND CAST(update_id AS DECIMAL(40,0))<CAST(%s AS DECIMAL(40,0)))) LIMIT 1",$chat,$key,$row['created_at'],$row['created_at'],$id));
            if ($older) return self::error('conversation_busy','درخواست قبلی این گفت‌وگو هنوز کامل نشده است.');
            $snapshot=self::decode($row['snapshot']);
            if (!$snapshot) {
                $context=call_user_func($context_callback,array('chat_id'=>$chat,'_actor_chat_id'=>$chat));
                $state=call_user_func($state_callback,array('chat_id'=>$chat,'_actor_chat_id'=>$chat));
                if (is_wp_error($context)) return $context;
                if (is_wp_error($state)) return $state;
                $snapshot=array('state'=>$state,'context'=>$context);
            } else {
                // Keep original form state for replay, but permissions always reflect current site roles.
                $context=call_user_func($context_callback,array('chat_id'=>$chat,'_actor_chat_id'=>$chat));
                if (is_wp_error($context)) return $context;
                $snapshot['context']=$context;
            }
            $token=bin2hex(random_bytes(24));
            $ok=$wpdb->update($table,array('status'=>'processing','token'=>$token,'lease_until'=>$now+self::LEASE,'attempts'=>(int)$row['attempts']+1,'snapshot'=>self::encode($snapshot),'updated_at'=>$now),array('job_key'=>$key));
            if ($ok===false) return self::error('storage_unavailable','ثبت وضعیت درخواست ممکن نشد.');
            return array('status'=>'processing','token'=>$token,'context'=>$snapshot['context'],'state'=>$snapshot['state']);
        } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock)); }
    }

    public static function finish($p) {
        if (!self::install()) return self::error('storage_unavailable','جدول پردازش آماده نیست.');
        global $wpdb; $table=self::jobs(); $key=self::key((string)($p['_actor_chat_id']??''),(string)($p['update_id']??''));
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE job_key=%s",$key),ARRAY_A);
        if (!$row || !hash_equals((string)$row['token'],(string)($p['token']??''))) return self::error('lease_lost','مالکیت پردازش معتبر نیست.',409);
        $ok=!empty($p['success']);
        $code=sanitize_key($p['error_code']??'');
        $review=$code==='operation_uncertain' || (int)$row['attempts']>=self::MAX_ATTEMPTS;
        $status=$ok?'done':($review?'review':'retry');
        $data=array('status'=>$status,'lease_until'=>0,'available_at'=>$ok?0:time()+min(600,15*(2**min(5,(int)$row['attempts']))),'error_code'=>$ok?'':substr($code,0,64),'updated_at'=>time());
        if ($ok) { $data['payload']=''; $data['snapshot']=''; }
        if ($wpdb->update($table,$data,array('job_key'=>$key,'token'=>$row['token']))===false) return self::error('storage_unavailable','ثبت نتیجه درخواست ممکن نشد.');
        return array('status'=>$status);
    }

    public static function heartbeat($p) {
        if(!self::install())return self::error('storage_unavailable','جدول پردازش آماده نیست.');
        global $wpdb; $table=self::jobs();$key=self::key((string)($p['_actor_chat_id']??''),(string)($p['update_id']??''));
        $row=$wpdb->get_row($wpdb->prepare("SELECT status,token FROM {$table} WHERE job_key=%s",$key),ARRAY_A);
        if(!$row || $row['status']!=='processing' || !hash_equals((string)$row['token'],(string)($p['token']??'')))return self::error('lease_lost','مالکیت پردازش منقضی شده است.',409);
        if($wpdb->update($table,array('lease_until'=>time()+self::LEASE),array('job_key'=>$key,'token'=>$row['token']))===false)return self::error('storage_unavailable','تمدید پردازش ممکن نشد.');
        return true;
    }

    /** Called by CLI worker through the signed bridge (no browser exposure). */
    public static function pending() {
        if (!self::install()) return self::error('storage_unavailable','جدول پردازش آماده نیست.');
        global $wpdb; $table=self::jobs(); $now=time();
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE (status='retry' AND available_at<=%d) OR (status='processing' AND lease_until<=%d) ORDER BY created_at ASC,CAST(update_id AS DECIMAL(40,0)) ASC LIMIT 1",$now,$now),ARRAY_A);
        $result=array(); foreach((array)$rows as $row) $result[]=self::decode($row['payload']);
        // Completed receipts live seven days. Unresolved jobs remain available for inspection.
        $wpdb->query($wpdb->prepare('DELETE o FROM '.self::ops().' o INNER JOIN '.$table." j ON j.job_key=o.job_key WHERE j.status='done' AND j.updated_at<%d",$now-7*DAY_IN_SECONDS));
        $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE status='done' AND updated_at<%d",$now-7*DAY_IN_SECONDS));
        return $result;
    }

    public static function diagnostics($p) {
        global $wpdb; if(!self::install())return array();
        $rows=$wpdb->get_results('SELECT status,COUNT(*) AS count FROM '.self::jobs().' GROUP BY status',ARRAY_A);
        return array('counts'=>$rows,'review'=>$wpdb->get_results("SELECT update_id,error_code,attempts,updated_at FROM ".self::jobs()." WHERE status='review' ORDER BY updated_at DESC LIMIT 20",ARRAY_A));
    }

    /** Successful mutations have a receipt; unknown in-flight outcomes stop for review. */
    public static function execute($method,$p,$callback) {
        if (empty($p['_job_id'])) return call_user_func($callback,$p);
        if (!self::install()) return self::error('storage_unavailable','جدول پردازش آماده نیست.');
        global $wpdb; $key=self::key((string)($p['_actor_chat_id']??''),(string)$p['_job_id']); $jobs=self::jobs();
        $row=$wpdb->get_row($wpdb->prepare("SELECT status,token,lease_until FROM {$jobs} WHERE job_key=%s",$key),ARRAY_A);
        if (!$row || $row['status']!=='processing' || (int)$row['lease_until']<=time() || !hash_equals((string)$row['token'],(string)($p['_job_token']??''))) return self::error('lease_lost','مالکیت پردازش منقضی شده است.',409);
        $wpdb->update($jobs,array('lease_until'=>time()+self::LEASE),array('job_key'=>$key,'token'=>$row['token']));
        $mutates=preg_match('/^(create|update|sync|block|add|remove|set|save|toggle|delete|enroll|confirm|issue|cancel|cleanup|reply|mark|open|close|link|stateSet|stateClear|stateMark)/',$method);
        if($method==='native' && in_array($p['op']??'',array('cart_add','cart_remove','appointment_add','checkout'),true))$mutates=true;
        if (!$mutates) return call_user_func($callback,$p);
        $identity=$p; unset($identity['_job_id'],$identity['_job_token']); ksort($identity);
        $op=hash('sha256',$key.'|'.$method.'|'.wp_json_encode($identity)); $table=self::ops();
        $lock='mph_op_'.substr($op,0,40);
        if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!=='1')return self::error('operation_busy','عملیات هنوز در حال اجراست.');
        try {
            $stored=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE op_key=%s",$op),ARRAY_A);
            if ($stored) {
                if ($stored['status']!=='done') return self::error('operation_uncertain','نتیجه عملیات قبلی نامشخص است؛ بررسی مدیر لازم است.',409);
                $result=self::decode($stored['result']);
                return isset($result['error']) ? new WP_Error($result['error']['code'],$result['error']['message'],$result['error']['data']) : $result['value'];
            }
            if (!$wpdb->insert($table,array('op_key'=>$op,'job_key'=>$key,'status'=>'running','result'=>'','created_at'=>time()))) return self::error('storage_unavailable','ثبت رسید عملیات ممکن نشد.');
            $value=call_user_func($callback,$p);
            if(!empty($wpdb->last_error))return self::error('operation_uncertain','خطای ذخیره عملیات؛ بررسی مدیر لازم است.',409);
            $result=is_wp_error($value)?array('error'=>array('code'=>$value->get_error_code(),'message'=>$value->get_error_message(),'data'=>$value->get_error_data())):array('value'=>$value);
            if ($wpdb->update($table,array('status'=>'done','result'=>self::encode($result)),array('op_key'=>$op))===false) return self::error('operation_uncertain','ثبت نتیجه عملیات ممکن نشد؛ بررسی مدیر لازم است.',409);
            return $value;
        } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock)); }
    }
}
