<?php
defined('ABSPATH') || exit;

/** بازنشانی مرحله ای و فقط با فرمان صریح سوپرادمین. */
final class MPH_Factory_Reset {
    const STATE_OPTION = 'mph_factory_reset_state';
    const CONFIRM_PHRASE = 'RESET MPH';
    const BATCH_POSTS = 25;
    const BATCH_USERS = 15;

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'), 99);
        add_action('wp_ajax_mph_factory_reset_start', array(__CLASS__, 'ajax_start'));
        add_action('wp_ajax_mph_factory_reset_step', array(__CLASS__, 'ajax_step'));
    }

    public static function menu() {
        if (!self::allowed()) return;
        add_submenu_page('mph', 'بازنشانی کارخانه ای', 'بازنشانی کارخانه ای', 'manage_options', 'mph-factory-reset', array(__CLASS__, 'page'));
    }

    public static function page() {
        if (!self::allowed()) wp_die('این ابزار فقط در اختیار سوپرادمین است.', '', array('response'=>403));
        wp_enqueue_script('mph-factory-reset', MPH_URL . 'assets/js/factory-reset.js', array(), MPH_VERSION, true);
        wp_script_add_data('mph-factory-reset', 'strategy', 'defer');
        wp_localize_script('mph-factory-reset', 'MPH_FACTORY_RESET', array('ajaxUrl'=>admin_url('admin-ajax.php'), 'nonce'=>wp_create_nonce('mph_factory_reset'), 'confirmPhrase'=>self::CONFIRM_PHRASE));
        $counts = self::counts();
        ?>
        <div class="wrap mph-admin mph-reset-admin" dir="rtl">
            <header class="mph-admin-head mph-reset-head"><span class="dashicons dashicons-database-remove"></span><div><h1>بازنشانی کارخانه ای افزونه</h1><p>پاک سازی حساب ها و داده های اختصاصی افزونه، فقط با فرمان مستقیم سوپرادمین</p></div></header>
            <div class="mph-reset-warning"><span class="dashicons dashicons-warning"></span><div><h2>این عملیات قابل بازگشت نیست</h2><p>پیش از اجرا از پایگاه داده و پوشه uploads نسخه پشتیبان بگیرید. نصب یا بروزرسانی افزونه به تنهایی هیچ داده ای را پاک نمی کند.</p></div></div>
            <div class="mph-admin-metrics mph-reset-metrics">
                <article><span class="dashicons dashicons-admin-users"></span><b><?php echo esc_html(number_format_i18n($counts['users'])); ?></b><small>حساب افزونه ای</small></article>
                <article><span class="dashicons dashicons-calendar-alt"></span><b><?php echo esc_html(number_format_i18n($counts['appointments'])); ?></b><small>نوبت و زمان آزاد</small></article>
                <article><span class="dashicons dashicons-feedback"></span><b><?php echo esc_html(number_format_i18n($counts['records'])); ?></b><small>رکورد اختصاصی</small></article>
            </div>
            <div class="mph-admin-split mph-reset-layout">
                <section class="mph-admin-box"><h2>مواردی که پاک می شوند</h2><ul class="mph-reset-list is-delete"><li>حساب های ثبت شده از طریق افزونه و دسترسی دوره آن ها</li><li>نوبت ها، زمان های آزاد، قفل رزرو و رویدادهای تقویم افزونه</li><li>تیکت ها، اطلاعیه ها، درخواست نقش و بازیابی رمز</li><li>گواهی ها، سوابق واریزی، گزارش امنیتی و تنظیمات افزونه</li></ul></section>
                <section class="mph-admin-box"><h2>مواردی که حفظ می شوند</h2><ul class="mph-reset-list is-keep"><li>تمام سوپرادمین ها و دسترسی وردپرس آن ها</li><li>برگه ها، نوشته ها و رسانه های عمومی سایت</li><li>اصل دوره های Tutor LMS و محصولات WooCommerce</li><li>سفارش های WooCommerce برای حفظ سوابق مالی و حسابرسی</li></ul></section>
            </div>
            <?php if (is_multisite()) : ?>
                <div class="notice notice-error inline"><p><b>اجرا در شبکه وردپرس غیرفعال است.</b> حذف کاربر در Multisite روی همه سایت های شبکه اثر می گذارد؛ بازنشانی باید با ابزار مخصوص شبکه انجام شود.</p></div>
            <?php else : ?>
                <section class="mph-admin-box mph-reset-form-card">
                    <div class="mph-builder-head"><div><h2>تأیید اجرای بازنشانی</h2><p>رمز فعلی خود و عبارت انگلیسی زیر را وارد کنید. عملیات به صورت دسته ای اجرا می شود؛ صفحه را نبندید.</p></div><code><?php echo esc_html(self::CONFIRM_PHRASE); ?></code></div>
                    <form data-mph-reset-form autocomplete="off">
                        <div class="mph-admin-grid"><label>رمز عبور فعلی سوپرادمین<input type="password" name="current_password" required autocomplete="current-password"></label><label>عبارت تأیید<input type="text" name="confirm_phrase" required autocomplete="off" dir="ltr" placeholder="<?php echo esc_attr(self::CONFIRM_PHRASE); ?>"></label></div>
                        <label class="mph-reset-check"><input type="checkbox" name="final_confirmation" value="1" required> می دانم داده های پاک شده بدون نسخه پشتیبان قابل بازیابی نیستند.</label>
                        <button type="submit" class="button button-primary button-hero mph-reset-start"><span class="dashicons dashicons-trash"></span> شروع بازنشانی امن</button>
                        <div class="mph-reset-progress" data-mph-reset-progress hidden><div><i></i></div><b>آماده سازی…</b><small>۰٪</small></div>
                        <div class="mph-reset-message" data-mph-reset-message aria-live="polite"></div>
                    </form>
                </section>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function ajax_start() {
        self::verify_request();
        if (is_multisite()) wp_send_json_error(array('message'=>'بازنشانی شبکه ای به دلیل خطر حذف کاربران مشترک غیرفعال است.'), 409);
        $phrase = sanitize_text_field(wp_unslash($_POST['confirm_phrase'] ?? ''));
        $password = (string) wp_unslash($_POST['current_password'] ?? '');
        if ($phrase !== self::CONFIRM_PHRASE || empty($_POST['final_confirmation'])) wp_send_json_error(array('message'=>'عبارت تأیید یا تیک پذیرش پیامدها کامل نیست.'), 400);
        $user = wp_get_current_user();
        if (!$user->exists() || !wp_check_password($password, $user->user_pass, $user->ID)) wp_send_json_error(array('message'=>'رمز عبور فعلی سوپرادمین درست نیست.'), 403);
        $token = wp_generate_password(48, false, false);
        $state = array('owner'=>get_current_user_id(), 'token_hash'=>wp_hash_password($token), 'phase'=>'posts', 'started'=>time(), 'deleted_posts'=>0, 'deleted_users'=>0, 'completed'=>false);
        update_option(self::STATE_OPTION, $state, false);
        MPH_Security::audit('factory_reset_started', 'owner='.get_current_user_id());
        wp_send_json_success(array('token'=>$token, 'message'=>'بازنشانی آغاز شد.', 'progress'=>5));
    }

    public static function ajax_step() {
        self::verify_request();
        $token = sanitize_text_field(wp_unslash($_POST['token'] ?? ''));
        $state = get_option(self::STATE_OPTION, array());
        if (!is_array($state) || absint($state['owner'] ?? 0) !== get_current_user_id() || empty($state['token_hash']) || !wp_check_password($token, $state['token_hash'])) wp_send_json_error(array('message'=>'نشست بازنشانی معتبر نیست؛ عملیات را دوباره آغاز کنید.'), 403);
        if (!empty($state['completed'])) wp_send_json_success(array('done'=>true, 'progress'=>100, 'message'=>'بازنشانی قبلاً کامل شده است.'));
        $result = self::run_step($state);
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()), 500);
        update_option(self::STATE_OPTION, $state, false);
        wp_send_json_success($result);
    }

    private static function run_step(&$state) {
        if ($state['phase'] === 'posts') {
            $ids = get_posts(array('post_type'=>self::post_types(), 'post_status'=>'any', 'numberposts'=>self::BATCH_POSTS, 'fields'=>'ids', 'orderby'=>'ID', 'order'=>'ASC', 'suppress_filters'=>true));
            foreach ($ids as $id) {
                foreach (array('_mph_certificate_file_id','_mph_ticket_attachment_id','_mph_reply_attachment_id') as $key) {$attachment=absint(get_post_meta($id,$key,true));if($attachment)wp_delete_attachment($attachment,true);}
                if (wp_delete_post($id, true)) $state['deleted_posts']++;
            }
            if ($ids) return array('done'=>false, 'progress'=>20, 'message'=>'در حال پاک سازی رکوردهای افزونه…');
            $state['phase'] = 'tables';
        }
        if ($state['phase'] === 'tables') {
            global $wpdb;
            foreach (self::tables() as $table) if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table) $wpdb->query("DELETE FROM `{$table}`");
            $state['phase'] = 'users';
            return array('done'=>false, 'progress'=>45, 'message'=>'جداول اختصاصی پاک شدند؛ در حال حذف حساب های افزونه ای…');
        }
        if ($state['phase'] === 'users') {
            $users=get_users(array('meta_key'=>'mph_phone','number'=>50,'orderby'=>'ID','order'=>'ASC','fields'=>array('ID')));$deletable=array();
            foreach($users as$user)if(!is_super_admin(absint($user->ID)))$deletable[]=absint($user->ID);
            if($deletable){require_once ABSPATH.'wp-admin/includes/user.php';foreach(array_slice($deletable,0,self::BATCH_USERS)as$user_id){$enrollments=get_posts(array('post_type'=>'tutor_enrolled','post_status'=>'any','author'=>$user_id,'numberposts'=>-1,'fields'=>'ids'));foreach($enrollments as$enrollment_id)wp_delete_post($enrollment_id,true);if(wp_delete_user($user_id,absint($state['owner'])))$state['deleted_users']++;}return array('done'=>false,'progress'=>65,'message'=>'حساب های افزونه ای در حال حذف هستند…');}
            $state['phase']='roles';
        }
        if($state['phase']==='roles'){self::clear_remaining_access();$state['phase']='options';return array('done'=>false,'progress'=>82,'message'=>'دسترسی های قدیمی پاک شدند؛ تنظیمات در حال بازسازی است…');}
        if($state['phase']==='options'){self::clear_options();$restored=self::restore_defaults();if(is_wp_error($restored))return$restored;$state['phase']='done';}
        $state['completed']=true;$state['completed_at']=time();$state['phase']='done';$state['token_hash']='';
        return array('done'=>true,'progress'=>100,'message'=>'بازنشانی کامل شد؛ '.number_format_i18n(absint($state['deleted_users'])).' حساب و '.number_format_i18n(absint($state['deleted_posts'])).' رکورد پاک شد. سوپرادمین حفظ شده است.');
    }

    private static function clear_remaining_access() {
        global $wpdb;$protected=array();foreach(get_users(array('role'=>'administrator','fields'=>array('ID')))as$user)if(is_super_admin(absint($user->ID)))$protected[]=absint($user->ID);
        $where="(meta_key LIKE 'mph\\_%' OR meta_key LIKE '\\_mph\\_%')";
        if($protected)$where.=' AND user_id NOT IN ('.implode(',',array_map('absint',$protected)).')';
        $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE {$where}");
        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE 'mph\\_%' OR meta_key LIKE '\\_mph\\_%'");
        foreach(get_users(array('number'=>-1,'fields'=>array('ID')))as$user){$id=absint($user->ID);if(is_super_admin($id))continue;$object=get_user_by('id',$id);if(!$object)continue;foreach(array('mph_instructor','mph_therapist','mph_manager')as$role)if(in_array($role,(array)$object->roles,true))$object->remove_role($role);foreach(array('mph_manage_portal','mph_manage_members','mph_manage_courses','mph_manage_reports','mph_manage_design','mph_manage_support','mph_manage_appointments')as$cap)$object->remove_cap($cap);}
    }

    private static function clear_options() {
        global $wpdb;$state=get_option(self::STATE_OPTION,array());$like=$wpdb->esc_like('mph_').'%';$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name <> %s",$like,self::STATE_OPTION));
        foreach(array('_transient_mph_','_transient_timeout_mph_','_site_transient_mph_','_site_transient_timeout_mph_')as$prefix)$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",$wpdb->esc_like($prefix).'%'));
        update_option(self::STATE_OPTION,$state,false);
    }

    private static function restore_defaults() {
        MPH_Admin::install_defaults();MPH_Security::install();$tickets=MPH_Tickets::maybe_install();$notices=MPH_Notices::maybe_install();if(!$tickets||!$notices)return new WP_Error('schema_restore','بازسازی جدول‌های افزونه کامل نشد؛ دسترسی ساخت جدول پایگاه‌داده را بررسی و همین مرحله را دوباره اجرا کنید.');update_option(MPH_Helpers::DB_VERSION,MPH_VERSION,false);
        if(class_exists('MPH_Plugin')){delete_option(MPH_Plugin::UPGRADE_PENDING);delete_option(MPH_Plugin::UPGRADE_PHASE);}wp_cache_flush();
        return true;
    }

    private static function counts() {
        global$wpdb;$users=absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key=%s",'mph_phone')));$appointments=0;$records=0;
        foreach(self::post_types()as$type){$count=wp_count_posts($type);$total=0;if($count)foreach((array)$count as$status_count)$total+=absint($status_count);if(in_array($type,array('mph_appointment','mph_therapy_slot'),true))$appointments+=$total;else$records+=$total;}return compact('users','appointments','records');
    }
    private static function post_types(){return array('mph_appointment','mph_therapy_slot','mph_password_help','mph_role_request','mph_instructor_notice','mph_staff_payout','mph_certificate','mph_ticket','mph_ticket_reply','mph_edu_event');}
    private static function tables(){global$wpdb;return array($wpdb->prefix.'mph_security_log',$wpdb->prefix.'mph_slot_locks',$wpdb->prefix.'mph_tickets',$wpdb->prefix.'mph_ticket_messages',$wpdb->prefix.'mph_announcements');}
    private static function verify_request(){nocache_headers();if(!self::allowed())wp_send_json_error(array('message'=>'این عملیات فقط برای سوپرادمین مجاز است.'),403);if(!check_ajax_referer('mph_factory_reset','nonce',false))wp_send_json_error(array('message'=>'اعتبار صفحه تمام شده است؛ صفحه را تازه کنید.'),403);}
    private static function allowed(){return is_user_logged_in()&&is_super_admin(get_current_user_id());}
}
