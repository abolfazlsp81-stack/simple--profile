<?php
defined('ABSPATH') || exit;

/** Optimistic revisions plus short, owner-scoped leases for portal writes. */
final class MPH_Edit_Guard {
    private static $lease=null;
    private static $cache_key='';
    private static $action='';
    private static $resource='';
    public static function init() {add_action('admin_init',array(__CLASS__,'begin'),-100);}
    public static function resource($action,$data) {
        if(in_array($action,array('mph_course_admin_save','mph_manager_course_save','mph_course_delete','mph_course_progress_save','mph_course_progress_delete','mph_issue_certificates_bulk'),true))return !empty($data['course_id'])?'course:'.absint($data['course_id']):'';
        if(in_array($action,array('mph_manager_user_roles','mph_manager_public_profile'),true))return !empty($data['user_id'])?'user:'.absint($data['user_id']):'';
        if($action==='mph_receipt_decision')return 'order:'.absint($data['order_id']??0);
        if($action==='mph_delete_certificate')return 'post:'.absint($data['certificate_id']??0);
        if($action==='mph_manager_super_admin')return 'option:mph_portal_super_admin_user_id';
        if($action==='mph_payment_settings')return 'option:mph_online_payment_settings';
        return '';
    }
    public static function revision($resource) {
        list($type,$id)=explode(':',$resource,2);
        if($type==='user'){$user=get_userdata((int)$id);$value=array($user?$user->roles:array(),get_user_meta((int)$id));}
        elseif($type==='order'){$order=wc_get_order((int)$id);$value=$order?array($order->get_status(),$order->get_meta(MPH_Commerce::RECEIPT_STATUS),$order->get_total(),$order->get_date_modified()?(string)$order->get_date_modified():''):array();}
        elseif($type==='option')$value=get_option($id);
        else {$value=array(get_post((int)$id),get_post_meta((int)$id));if($type==='course')$value[]=get_posts(array('post_type'=>'mph_certificate','post_status'=>'any','numberposts'=>-1,'fields'=>'ids','meta_key'=>'_mph_certificate_course_id','meta_value'=>(int)$id));}
        return hash_hmac('sha256',$resource.'|'.serialize($value),wp_salt('nonce'));
    }
    private static function replay_allowed($resource) {
        if(!$resource)return true;
        $type=strtok($resource,':');
        if($type==='course')return current_user_can('manage_options')||current_user_can('mph_manage_courses')||current_user_can('mph_manage_portal');
        return current_user_can('manage_options')||current_user_can('mph_manage_portal');
    }
    public static function markup($html) {
        return preg_replace_callback('/<form\b([^>]*)>(.*?)<\/form>/is',function($m){
            if(strpos($m[2],'name="_mph_revision"')!==false)return $m[0];
            preg_match('/data-mph-action=["\']([^"\']+)/i',$m[1],$a);
            $action=$a[1]??(strpos($m[1],'data-mph-course-admin-save')!==false?'mph_course_admin_save':'');
            $data=array();preg_match_all('/<input\b[^>]*>/i',$m[2],$inputs);
            foreach($inputs[0] as $input){preg_match('/\bname=["\']([^"\']+)/i',$input,$name);preg_match('/\bvalue=["\']([^"\']*)/i',$input,$value);if(isset($name[1],$value[1]))$data[$name[1]]=html_entity_decode($value[1],ENT_QUOTES,'UTF-8');}
            $resource=self::resource($action,$data);if(!$resource)return $m[0];
            return '<form'.$m[1].'><input type="hidden" name="_mph_revision" value="'.esc_attr(self::revision($resource)).'">'.$m[2].'</form>';
        },(string)$html);
    }
    public static function begin() {
        if(!wp_doing_ajax())return;
        $action=sanitize_key($_POST['action']??'');if(strpos($action,'mph_')!==0)return;
        self::$action=$action;
        ob_start(array(__CLASS__,'finish'));
        if(!is_user_logged_in())return;
        $writes=array('mph_ticket_v8_create','mph_ticket_v8_reply','mph_checkout_prepare','mph_receipt_submit','mph_appointment_book','mph_private_upload','mph_issue_certificate','mph_issue_certificates_bulk','mph_course_admin_save','mph_manager_course_save');
        $resource=self::resource($action,$_POST);
        if(!$resource && !in_array($action,$writes,true))return;
        $nonce=sanitize_text_field(wp_unslash($_POST['nonce']??''));
        $valid=$action==='mph_course_admin_save'?wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mph_course_nonce']??'')),'mph_course_admin'):wp_verify_nonce($nonce,strpos($action,'mph_ticket_v8_')===0?'mph_ticket_nonce':'mph_nonce');
        if(!$valid)wp_send_json_error(array('message'=>'نشست منقضی شده است؛ صفحه را تازه کنید.'),403);
        $request=sanitize_text_field($_POST['_mph_request_id']??'');
        if(preg_match('/^[a-zA-Z0-9-]{16,100}$/D',$request)){
            self::$cache_key='mph_operation_'.hash('sha256',get_current_user_id().'|'.$action.'|'.$request);
            $cached=get_transient(self::$cache_key);
            if(is_array($cached) && isset($cached['success'])){if(!self::replay_allowed($resource)){self::$cache_key='';wp_send_json_error(array('message'=>'دسترسی این عملیات دیگر فعال نیست.'),403);}self::$cache_key='';wp_send_json($cached);}
            if($cached==='running'){self::$cache_key='';wp_send_json_error(array('message'=>'درخواست قبلی هنوز در حال بررسی است؛ سوابق را بررسی کنید و کمی بعد دوباره تلاش کنید.'),409);}
        }
        if($resource){
            self::$lease=MPH_Operation_Lock::acquire('edit:'.$resource,180);
            if(!self::$lease){self::$cache_key='';wp_send_json_error(array('message'=>'این رکورد در حال ذخیره است؛ کمی بعد دوباره تلاش کنید.'),409);}
            $expected=(string)($_POST['_mph_revision']??'');
            if(!$expected || !hash_equals(self::revision($resource),$expected)){self::$cache_key='';wp_send_json_error(array('message'=>'نسخه این فرم قدیمی است؛ تغییرات ذخیره نشد. آخرین نسخه را باز کنید و دوباره بررسی کنید.','conflict'=>true),409);}
            self::$resource=$resource;
        }
        if(self::$cache_key){
            $lease=MPH_Operation_Lock::acquire(self::$cache_key,180);
            if(!$lease){self::$cache_key='';wp_send_json_error(array('message'=>'همین درخواست در حال انجام است؛ کمی بعد وضعیت را بررسی کنید.'),409);}
            register_shutdown_function(function()use($lease){MPH_Operation_Lock::release($lease);});
            // Recheck after taking the lease: another request may have just completed.
            $cached=get_transient(self::$cache_key);
            if($cached){self::$cache_key='';if(is_array($cached))wp_send_json($cached);wp_send_json_error(array('message'=>'درخواست قبلی در حال بررسی است.'),409);}
            set_transient(self::$cache_key,'running',DAY_IN_SECONDS);
        }
    }
    public static function finish($buffer,$phase) {
        if(!($phase & PHP_OUTPUT_HANDLER_FINAL))return $buffer;
        $json=json_decode($buffer,true);if(!is_array($json)||!array_key_exists('success',$json)){MPH_Operation_Lock::release(self::$lease);return $buffer;}
        if(empty($json['success'])){
            $trace=bin2hex(random_bytes(6));$json['data']=is_array($json['data']??null)?$json['data']:array('message'=>'درخواست انجام نشد؛ دوباره وضعیت را بررسی کنید.');
            $json['data']['trace_id']=$trace;$json['data']['message']=($json['data']['message']??'درخواست انجام نشد.').' — پیگیری: '.$trace;
            MPH_Security::audit('portal_request_failed','trace='.$trace.';action='.self::$action,get_current_user_id());
            if(self::$cache_key)delete_transient(self::$cache_key);
        }else{
            if(!empty($json['data']['html']))$json['data']['html']=self::markup($json['data']['html']);
            if(self::$resource)MPH_Security::audit('manager_record_saved','action='.self::$action.';target='.self::$resource,get_current_user_id());
            if(self::$cache_key)set_transient(self::$cache_key,$json,DAY_IN_SECONDS);
        }
        MPH_Operation_Lock::release(self::$lease);self::$lease=null;
        return wp_json_encode($json);
    }
}
