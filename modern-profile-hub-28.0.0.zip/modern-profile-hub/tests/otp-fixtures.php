<?php
// Isolated WordPress doubles. No network requests or real credentials.
define('ABSPATH',__DIR__.'/'); define('MINUTE_IN_SECONDS',60); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400); define('ARRAY_A','ARRAY_A');
$options=[]; $transients=[]; $http_queue=[]; $http_calls=[]; $checks=0; $fail_option='';
function verify($condition,$message) { global $checks; $checks++; if(!$condition)throw new RuntimeException($message); }
class WP_Error { private $code,$message,$data; public function __construct($c,$m,$d=null){$this->code=$c;$this->message=$m;$this->data=$d;} public function get_error_code(){return $this->code;} public function get_error_message(){return $this->message;} public function get_error_data(){return $this->data;} }
class WP_User { public $ID=7; }
function is_wp_error($v){return $v instanceof WP_Error;}
function wp_parse_args($a,$b){return array_merge($b,$a);}
function get_option($k,$d=false){return $GLOBALS['options'][$k]??$d;}
function update_option($k,$v,$a=false){if($GLOBALS['fail_option']===$k)return false;if(get_option($k,null)===$v)return false;$GLOBALS['options'][$k]=$v;return true;}
function delete_option($k){unset($GLOBALS['options'][$k]);return true;}
function set_transient($k,$v,$ttl){$GLOBALS['transients'][$k]=['value'=>$v,'until'=>time()+$ttl];return true;}
function get_transient($k){$v=$GLOBALS['transients'][$k]??null;return $v&&$v['until']>time()?$v['value']:false;}
function delete_transient($k){if(!isset($GLOBALS['transients'][$k]))return false;unset($GLOBALS['transients'][$k]);return true;}
function sanitize_key($s){return preg_replace('/[^a-z0-9_-]/','',strtolower((string)$s));}
function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function absint($v){return abs((int)$v);}
function wp_json_encode($v,$flags=0){return json_encode($v,$flags);}
function wp_remote_request($url,$args){$GLOBALS['http_calls'][]=[$url,$args];if(!$GLOBALS['http_queue'])throw new RuntimeException('Unexpected network call');return array_shift($GLOBALS['http_queue']);}
function wp_remote_post($url,$args){return wp_remote_request($url,$args);}
function wp_remote_retrieve_response_code($r){return $r['response']['code'];}
function wp_remote_retrieve_body($r){return $r['body'];}
function response($status,$entries=[],$http=200){return ['response'=>['code'=>$http],'body'=>json_encode(['return'=>['status'=>$status,'message'=>'remote message'],'entries'=>$entries])];}
function get_user_meta($id,$key,$single){return $key==='mph_phone'?'09121234567':'';}
function get_user_by($key,$id){return new WP_User();}
function wp_hash_password($s){return password_hash($s,PASSWORD_DEFAULT);}
function wp_check_password($s,$hash){return password_verify($s,$hash);}
class MPH_Security {
    public static function get_secret_option($k,$d=''){return self::decrypt(get_option($k,$d));}
    public static function update_secret_option($k,$v){return update_option($k,self::encrypt($v),false);}
    public static function encrypt($s){return 'test-cipher:'.base64_encode($s);}
    public static function decrypt($s){return strpos($s,'test-cipher:')===0?base64_decode(substr($s,12)):$s;}
    public static function audit(...$args){}
}
class MPH_Helpers {
    public static function normalize_digits($s){return strtr($s,['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);}
    public static function phone($s){$s=preg_replace('/\D/','',self::normalize_digits($s));if(strpos($s,'0098')===0)$s='0'.substr($s,4);elseif(strpos($s,'98')===0)$s='0'.substr($s,2);return preg_match('/^09\d{9}$/D',$s)?$s:'';}
}
class OtpLockDB { public function prepare($sql,...$args){return $sql;} public function get_var($sql){return '1';} }
$wpdb=new OtpLockDB();
