<?php
/** Appointment cart/hold regression tests; no WordPress, payment or network is used. */
define('ABSPATH',__DIR__.'/');define('MINUTE_IN_SECONDS',60);
$checks=0;$post_meta=array();$posts=array();$reserved=array();$locks=array();$orders=array();$cart=array();$next=200;
function check($ok,$message){global $checks;$checks++;if(!$ok)throw new RuntimeException($message);}
class WP_Error{private $code,$message;function __construct($c,$m){$this->code=$c;$this->message=$m;}function get_error_code(){return $this->code;}function get_error_message(){return $this->message;}}
function is_wp_error($v){return $v instanceof WP_Error;}function absint($v){return abs((int)$v);}
function get_post_meta($id,$key,$single=true){return $GLOBALS['post_meta'][$id][$key]??'';}function update_post_meta($id,$key,$value){$GLOBALS['post_meta'][$id][$key]=$value;return true;}
function wp_insert_post($data,$error=false){$id=++$GLOBALS['next'];$GLOBALS['posts'][$id]=$data;return $id;}function wp_delete_post($id,$force=false){unset($GLOBALS['posts'][$id]);return true;}
function wp_generate_password(){return 'TRACKINGCODE';}function wp_schedule_single_event(...$args){return true;}function wp_cache_delete(...$args){}
function wc_get_order($id){return $GLOBALS['orders'][$id]??false;}
class Order{private $id,$user,$paid=false,$meta=array();function __construct($id,$user){$this->id=$id;$this->user=$user;}function get_id(){return $this->id;}function get_customer_id(){return $this->user;}function get_meta($k){return $this->meta[$k]??'';}function set_meta($k,$v){$this->meta[$k]=$v;}function is_paid(){return $this->paid;}function pay(){$this->paid=true;}}
class MPH_Appointment_Lock{static function acquire($slot,$ttl){if(!empty($GLOBALS['locks'][$slot]))return false;$token='lock-'.$slot;$GLOBALS['locks'][$slot]=$token;return $token;}static function release($slot,$token){if(($GLOBALS['locks'][$slot]??'')===$token)unset($GLOBALS['locks'][$slot]);}}
class MPH_Appointment_Repository{static function reserve_slot($slot,$id){if(!empty($GLOBALS['reserved'][$slot]))return false;$GLOBALS['reserved'][$slot]=$id;return true;}static function release_slot($slot,$id){if(($GLOBALS['reserved'][$slot]??0)==$id)unset($GLOBALS['reserved'][$slot]);}static function slot_state($slot){return array('reserved'=>$GLOBALS['reserved'][$slot]??0,'booked'=>0);}}
class MPH_Appointments{const APPOINTMENT_TYPE='mph_appointment';const ORDER_META='_mph_appointment_id';const HOLD_MINUTES=30;static $price='500000';static function cart_slot($slot,$mode,$own=0){if($slot!==10||$mode!=='online')return new WP_Error('invalid','invalid');$held=$GLOBALS['reserved'][$slot]??0;if($held&&$held!==$own)return new WP_Error('full','full');return array('therapist_id'=>9,'date'=>'2030-01-01','time'=>'10:00','end'=>'11:00','duration'=>60,'mode'=>$mode,'price'=>self::$price,'label'=>'fixture');}static function confirm_paid_order($id){}}
class MPH_Shared_Cart{static function add($uid,$entry){$GLOBALS['cart'][]=$entry;return array('items'=>$GLOBALS['cart']);}}
class MPH_Commerce{const RECEIPT_STATUS='_mph_receipt_status';}
class MPH_Security{static function decrypt($v){return $v;}static function audit(...$args){}}
class MPH_Payment_Attempts{static function event(...$args){}}
require dirname(__DIR__).'/includes/class-mph-appointment-cart.php';

$added=MPH_Appointment_Cart::add(7,10,'online','note');check(!is_wp_error($added)&&count($cart)===1,'Selection must enter the shared cart');check(!$reserved,'Adding to cart must not consume capacity');
$entry=array('slot_id'=>10,'appointment_mode'=>'online','price'=>'500000','note'=>'note');$order=$orders[1]=new Order(1,7);
$appointment=MPH_Appointment_Cart::reserve($entry,$order,'cart-key');check(!is_wp_error($appointment),'Checkout must reserve an available slot');check(($reserved[10]??0)===$appointment,'Reservation must be owned by the created appointment');check(get_post_meta($appointment,'_mph_appointment_status',true)==='awaiting_payment','Reservation starts in awaiting-payment state');check(get_post_meta($appointment,'_mph_appointment_hold_until',true)>time(),'Reservation must have a finite hold');
$second=MPH_Appointment_Cart::reserve($entry,new Order(2,8),'other');check(is_wp_error($second)&&$second->get_error_code()==='full','A second account cannot reserve the held slot');
$order->set_meta('_mph_appointment_ids',array($appointment));update_post_meta($appointment,'_mph_appointment_hold_until',time()-1);MPH_Appointment_Cart::expire($appointment);check(!isset($reserved[10]),'Expired unpaid hold must release capacity');check(get_post_meta($appointment,'_mph_appointment_status',true)==='expired','Expired appointment must be marked');check(count($cart)===1,'Expiring capacity must not remove the cart selection');
$held=MPH_Appointment_Cart::ensure_holds($order);check($held===true&&($reserved[10]??0)===$appointment,'Retry must reacquire capacity for the same appointment');
MPH_Appointments::$price='600000';$changed=MPH_Appointment_Cart::ensure_holds($order);check(is_wp_error($changed)&&$changed->get_error_code()==='mph_price_changed','Changed price must block payment and preserve selection');check(count($cart)===1,'A price conflict must leave the cart intact');
echo "Appointment cart/holds: {$checks} assertions passed.\n";
