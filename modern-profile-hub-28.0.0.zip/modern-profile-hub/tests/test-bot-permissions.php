<?php
define('ABSPATH',__DIR__.'/');$checks=0;$meta=array(1=>array('_mph_bale_chat_id'=>'101','_mph_bale_admin_v28'=>'1'),2=>array('_mph_bale_chat_id'=>'102'),3=>array('_mph_bale_chat_id'=>'103'));$options=array('mph_bale_admins_migrated_v28'=>1);$users=array();
function check($c,$m){global $checks;$checks++;if(!$c)throw new RuntimeException($m);}function absint($v){return abs((int)$v);}function sanitize_key($v){return strtolower((string)$v);}function sanitize_text_field($v){return trim((string)$v);}function is_wp_error($v){return $v instanceof WP_Error;}
class WP_Error{public $code;function __construct($c,$m,$d=null){$this->code=$c;}function get_error_code(){return $this->code;}}
class WP_User{public $ID,$roles;function __construct($id,$roles){$this->ID=$id;$this->roles=$roles;}function add_role($role){$this->roles[]=$role;}function remove_role($role){$this->roles=array_values(array_diff($this->roles,array($role)));}}
$users=array(1=>new WP_User(1,array('subscriber')),2=>new WP_User(2,array('subscriber','mph_therapist')),3=>new WP_User(3,array('subscriber')));
function get_users($args){$rows=array_values($GLOBALS['users']);if(isset($args['meta_key']))$rows=array_values(array_filter($rows,function($u)use($args){return get_user_meta($u->ID,$args['meta_key'],true)===$args['meta_value'];}));return $rows;}
function get_user_meta($id,$key,$single=true){return $GLOBALS['meta'][$id][$key]??'';}function update_user_meta($id,$key,$v){$GLOBALS['meta'][$id][$key]=$v;return true;}function get_option($k,$d=false){return $GLOBALS['options'][$k]??$d;}function update_option($k,$v,$a=false){$GLOBALS['options'][$k]=$v;return true;}function user_can($u,$cap){return false;}function is_multisite(){return false;}function is_super_admin($id=0){return false;}
class MPH_Manager{static function portal_super_admin_id(){return 1;}}class MPH_Security{static function audit(...$args){}}class MPH_Helpers{static function normalize_digits($v){return (string)$v;}static function display_name($u){return 'Test '.$u->ID;}}
require dirname(__DIR__).'/includes/class-mph-bale-sync.php';
$actor=array('_actor_chat_id'=>'101','chat_id'=>'102');$roles=$users[2]->roles;
check(MPH_Bale_Sync::rpc_addAdmin($actor)===true,'Bot owner can add bot admin');check($users[2]->roles===$roles,'Adding bot admin must not grant a WordPress site role');check(get_user_meta(2,'_mph_bale_admin_v28',true)==='1','Bot access must be stored independently');
check(is_wp_error(MPH_Bale_Sync::require_actor(array('_actor_chat_id'=>'102'),true)),'Bot admin must not acquire site business management permissions');
$r=MPH_Bale_Sync::rpc_addAdmin(array('_actor_chat_id'=>'103','chat_id'=>'102'));check(is_wp_error($r)&&$r->get_error_code()==='forbidden','Ordinary user cannot grant bot administration');
$r=MPH_Bale_Sync::rpc_removeAdmin(array('_actor_chat_id'=>'102','chat_id'=>'101'));check(is_wp_error($r),'Bot admin cannot remove protected owner');
check(MPH_Bale_Sync::rpc_removeAdmin($actor)===true,'Owner can revoke bot admin');check($users[2]->roles===$roles,'Revoking bot admin must preserve therapist and user roles');check(get_user_meta(2,'_mph_bale_admin_v28',true)==='0','Bot access must be revoked');
$r=MPH_Bale_Sync::rpc_setSetting(array('_actor_chat_id'=>'102','key'=>'bot_active','value'=>'0'));check(is_wp_error($r),'Revoked bot admin cannot disable bot');
$r=MPH_Bale_Sync::rpc_setSetting(array('_actor_chat_id'=>'101','key'=>'bot_active','value'=>'0'));check($r===true&&get_option('mph_bale_bot_active')==='0','Owner may change bot on/off state');
$r=MPH_Bale_Sync::require_actor(array('_actor_chat_id'=>'101'),true);check(is_wp_error($r)===false,'Protected portal owner keeps site management rights');
echo "Independent bot administration: {$checks} assertions passed.\n";
