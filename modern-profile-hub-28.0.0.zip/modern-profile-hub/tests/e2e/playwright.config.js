const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: __dirname,
  timeout: 45000,
  retries: 1,
  use: {
    baseURL: process.env.MPH_BASE_URL || 'http://127.0.0.1',
    locale: 'fa-IR',
    timezoneId: 'Asia/Tehran',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure'
  },
  reporter: [['list'], ['html', { outputFolder: 'tests/e2e/report', open: 'never' }]]
});
