const { test, expect } = require('@playwright/test');

const accountPath = process.env.MPH_ACCOUNT_PATH || '/my-account/';
const phone = process.env.MPH_TEST_PHONE || '';
const password = process.env.MPH_TEST_PASSWORD || '';

test('clean authentication never exposes personal fields in the URL', async ({ page }) => {
  await page.goto(accountPath);
  await expect(page.locator('.mph-smart-auth')).toBeVisible();
  await page.locator('[data-auth-panel="phone"] input[name="phone"]').fill('09123456789');
  await expect(page).not.toHaveURL(/phone=|mobile=|password=/i);
});

test('management recovery has a one-time-code form inside the plugin', async ({ page }) => {
  await page.goto(accountPath);
  await page.locator('[data-auth-panel="phone"] input[name="phone"]').fill('09123456789');
  await page.locator('[data-auth-panel="phone"] button[type="submit"]').click();
  const recovery = page.locator('[data-auth-recovery]');
  if (await recovery.isVisible()) {
    await recovery.click();
    await page.locator('[data-recovery-option="management"]').click();
    await expect(page.locator('[data-auth-panel="recovery_management"].is-active')).toBeVisible();
  }
});

test('authenticated portal and appointment calendar load without a full-page AJAX refresh', async ({ page }) => {
  test.skip(!phone || !password, 'Set MPH_TEST_PHONE and MPH_TEST_PASSWORD for the authenticated smoke test.');
  await page.goto(accountPath);
  await page.locator('[data-auth-panel="phone"] input[name="phone"]').fill(phone);
  await page.locator('[data-auth-panel="phone"] button[type="submit"]').click();
  await page.locator('[data-auth-panel="password"] input[name="password"]').fill(password);
  await page.locator('[data-auth-panel="password"] button[type="submit"]').click();
  await page.waitForLoadState('networkidle');
  await expect(page.locator('.mph-dashboard')).toBeVisible();
  const appointmentLink = page.locator('[data-panel="book_appointment"], [data-mph-panel="book_appointment"]').first();
  if (await appointmentLink.count()) {
    await appointmentLink.click();
    await expect(page.locator('.mph-booking-calendar,.mph-appointment-booking')).toBeVisible();
  }
  await expect(page).not.toHaveURL(/phone=|address=|billing_email=|patient_note=/i);
});
